<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="<?php echo $detailPageData->metakeyword;?>" />
    <meta name="description" content="<?php echo $detailPageData->metadescription;?>" />

    <title><?php echo $detailPageData->metatitle;?></title>

    <meta name="google-site-varification" content="" />
    <meta name="msvalidate.01" content="" />
    <meta name="alexaVerifyID" content="" />
    <meta name="yandex-varification" content="" />
    <meta name="y_key" content="" />
    <meta name="p:domain_verify" content="" />
    <?=link_tag('assets/css/bootstrap.min.css');?>
    <?=link_tag('assets/css/navbar.css');?>
    <?=link_tag('assets/css/style.css');?>
    <?=link_tag('assets/css/dashbord-body.css');?>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <?=link_tag('assets/css/owl.carousel.css');?>
    <?=link_tag('assets/css/select2.min.css');?>
    <?=link_tag('assets/css/jquery-ui.min.css');?>
    <?=link_tag('assets/css/cms.css');?>

    <script src="<?php echo base_url('assets/js/jquery.js');?>"></script>

    <!--TAWK API HERE-->
    
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-83868955-1');

    </script>
    <meta property="fb:pages" content="339288996194866" />
    <script charset="UTF-8" src="//cdn.sendpulse.com/9dae6d62c816560a842268bde2cd317d/js/push/35d9ae3253fff0739ae593b8860f262d_1.js" async></script>
    <style>
        .about-form {
    margin-top: -40px;
    margin-bottom: 30px;
    color: #fff;
    background: #4c4c4c;
    padding: 30px 0;
    overflow: auto;
}
.document-container {
    background: #4c4c4c;
    color: #fff;
    margin-bottom: -30px;
}
                
.document-container {
    margin-top: -30px;
    background: #4c4c4c;
    color: #fff;
    margin-bottom: -30px;
}    
.partners {
    margin-top: -30px;
    text-align: center;
}        
.about-form {
    margin-top: -40px;
    margin-bottom: 30px;
    color: #0c0c0c;
    background: #fff;
    padding: 30px 0;
    overflow: auto;
}
    h4 strong, h3 strong, h2 strong, h1 strong {
    text-align: center;
    font-weight: 900 !important;
    position: relative;
    margin-bottom: 30px;
    text-transform: uppercase;
    font-size: 23px;
    display: inline-block;
}    
.template-header-02-box {
    padding: 15px;
    border: 1px solid transparent;
    margin-top: 30%;
    text-align: justify;
    box-shadow: 0px 0px 11px rgba(0,0,0,.5);
    opacity: 2.2;
    background-color: #fff;
}
section.about-form p {
    margin-bottom: 40px;
    
    padding-left: 14px;
    padding-right: 14px;
}
.ui-form-01 {
    width: 300px;
    max-width: 300px;
    margin: auto;
    display: block;
    margin-top: 40px;
    overflow: auto;
}
.input-icon {
    width: 272px;
    margin-bottom: 15px;
    position: relative;
    overflow: hidden;
}
    </style>
</head>

<body data-path="">
    <header>
        <?php include_once('includes/header.php'); ?>

<script src='https://www.google.com/recaptcha/api.js'></script>
        <!--CONTAINER-->
        <script type="text/javascript">
        function get_action() {
            var v = grecaptcha.getResponse();
            console.log("Resp" + v);
            if (v == '') {
                document.getElementById('captcha').innerHTML = "You are a Robot..";
                return false;
            }
        }
    </script>
        <script type="text/javascript">  
    var your_site_key = '<%= ConfigurationManager.AppSettings["6LeKeGgUAAAAAAq0m5SlU8yJwKgjmFETYo0y0ngw"]%>';  
    var renderRecaptcha = function () {  
        grecaptcha.render('ReCaptchContainer', {  
            'sitekey': 6LeKeGgUAAAAAAq0m5SlU8yJwKgjmFETYo0y0ngw,  
            'callback': reCaptchaCallback,  
            theme: 'light', //light or dark    
            type: 'image',// image or audio    
            size: 'normal'//normal or compact    
        });  
    };  
  
    var reCaptchaCallback = function (response) {  
        if (response !== '') {  
            jQuery('#lblMessage').css('color', 'green').html('Success');  
        }  
    };  
  
    jQuery('#googlec').click(function(e) {  
        var message = 'Please checck the checkbox';  
       // alert (message);
        if (typeof (grecaptcha) != 'undefined') {  
            var response = grecaptcha.getResponse();  
            (response.length === 0) ? (message = 'Captcha verification failed') : (message = 'Success!');  
        }  
        jQuery('#lblMessage').html(message);  
        jQuery('#lblMessage').css('color', (message.toLowerCase() == 'success!') ? "green" : "red");  
    });  
</script>
    </header>




    <section class="template-header-01" id="home" style="background-image:url('<?php echo $detailPageData->image;?>');background-repeat: no-repeat;background-size: 1349px 448px;">
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <div class="template-header-02-box">
                        <h1><?php echo $detailPageData->small_heading;?></h1>
                        <p class="marginT20"><?php echo $detailPageData->small_description;?></p>
                    </div>

                </div>
                <div class="col-sm-4">
                    <?php if(isset($_POST['HeaderContactForm'])){
                         $client_name=$_POST['client_name'];
                        $client_email_address=$_POST['client_email_address'];
                        $client_mobile_number=$_POST['client_mobile_number'];
                        $to="harshitrastogi615@gmail.com";
                        $subject="Online Enquiry Form submitted by :" .$client_name;
                        $message=" Name -".$client_name. " Email ID -" . $client_email_address." Subject:". $subject." Phone No:".$client_mobile_number;
			            $headers="From:".$client_email_address ."\r\n";

			           mail($to,$subject,$message,$headers) ;

			            echo "<script>alert ('Thank you...We will contact you shortly.'); </script>";
                    } ?>
                </div>
                <div class="col-sm-4">
                    <div class="ui-form-01">
                        <form onsubmit="return get_action();" method="post" name="frmHeaderSection" action="">
                            <div class="ui-form-01-wraper">
                                <p>Query Now<br> Please query for more information.</p>
                                <div class="input-icon">
                                    <input type="hidden" name="position" value="1">
                                    <input type="text" placeholder="Name" name="client_name" maxlength="50">
                                    <i class="icofont icofont-ui-user"></i>
                                </div>
                                <div class="input-icon">
                                    <input type="email" placeholder="Email Address" name="client_email_address" maxlength="50">
                                    <i class="icofont icofont-email"></i>
                                </div>
                                <div class="input-icon">
                                    <input type="tel" placeholder="Mobile No" name="client_mobile_number" maxlength="50">
                                    <i class="icofont icofont-mobile-phone"></i>
                                    
                                </div>
                                <div class="input-icon">
                                    <div class="g-recaptcha" data-sitekey="6LeKeGgUAAAAAAq0m5SlU8yJwKgjmFETYo0y0ngw"></div>
                                    <div id="captcha" style="color:red;font-size:20px;font-weight: bold;"></div>
                                </div>
                                
                            </div>
                            
                            <button type="submit" id="header_contactform" class="btn btn-default" name="HeaderContactForm" value="Header Contact">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Global site tag (gtag.js) - Google AdWords: 877903489 -->
    
    


    <!-- Facebook Pixel Code -->
    <script>
        ! function(f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function() {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '352444285242144');
        fbq('track', 'PageView');
        fbq('track', 'Lead');

    </script>
  
    <!-- End Facebook Pixel Code -->
    <div class="">

        <section class="about-form">
            <div class="col-lg-9 col-sm-7 about-form-gst" >
                <h4><strong><span style="color:#121211"><?php echo $detailPageData->main_heading;?></span></strong></h4>

                <p style="text-align: justify;"><?php echo $detailPageData->main_description;?><a name="_GoBack"></a></p>
            </div>
            <div class="col-lg-3 col-sm-5 about-ui-form" style="background-color: #5fc4e4;height: 364px;padding: 23px;">
                
                    <i class="icofont icofont-email fa-5x"></i>
                    <h4>List Of Recent Services</h4>
                    <?php if(!empty($getServiceNames)){
                            foreach($getServiceNames as $all_small_headings){ ?>
<!--                    <p class="text-center text-uppercase" style="text-align: center;"></p>           -->
                                <li style="list-style: none;">
                                <a href="<?php echo $all_small_headings->url; ?>" style="color: #fff;font-size: 15px;">
                                <i class="fa fa-chevron-right" aria-hidden="true"></i> 
                                <?php echo $all_small_headings->small_heading; ?></a>
                                </li> 
                            <?php } } ?>
                
            </div>
    </div>
    </div>
    </section>
    <div class="" style="padding: 60px 0;margin-top: -30px;background-image: url(<?=base_url('assets/images/bg-5.png');?>);background-repeat: no-repeat;background-size: 1349px 494px;">
        <div class="container">
            <form method="post" name="frmHeaderSection1" action="" class="row">
                <h4 style="color:#fff;"><strong>Still confused! </br>Take Free Advisor Consultation</strong></h4>
                <div class="col-sm-offset-4 col-sm-4">
                    <div class="">
                        <input type="hidden" name="position" value="2">
                        <input type="text" placeholder="First Name" name="client_name" maxlength="50" class="form-control"><br>
                        <input type="email" placeholder="Email Address" name="client_email_address" maxlength="50" class="form-control"><br>
                        <input type="tel" placeholder="Mobile No" name="client_mobile_number" maxlength="50" class="form-control"><br>
                    </div>
                    <div class="g-recaptcha" data-sitekey="6LeKeGgUAAAAAAq0m5SlU8yJwKgjmFETYo0y0ngw"></div>
                                    <div id="captcha" style="color:red;font-size:20px;font-weight: bold;"></div>
                </div>
                <div class="col-sm-12 text-center">
                    <button type="submit" id="header_contactform1" class="btn btn-default" name="HeaderContactForm" value="Header Contact" style="background:#4c4c4c;color:#fff;width:150px">Submit</button>
                </div>
            </form>
        </div>
    </div>

    <section class="steps-container">
        <div class="container" id="process">

        </div>

        <div class="document-container">
            <div class="container">
                <h2 style="text-align:center"><strong>Documents Required</strong></h2>

                <div class="row">
                    <div class="col-sm-3">
                        <div class="document-box"><img src="<?=base_url('assets/images/identity-card.png');?>" />
                            <h4>Identity Proof</h4>

                            <p><?php echo $detailPageData->doc1;?></p>

<!--
                            <p>Driving License</p>

                            <p>Election Id Card</p>

                            <p>Passport</p>
-->
                        </div>
                    </div>

                    <div class="col-sm-3">
                        <div class="document-box"><img src="<?=base_url('assets/images/address-proof.png');?>" />
                            <h4>Address Proof of Business</h4>

                            <p><?php echo $detailPageData->doc2;?></p>
                        </div>
                    </div>

                    <div class="col-sm-3">
                        <div class="document-box"><img src="<?=base_url('assets/images/pancard.png');?>" />
                            <h4><?php echo $detailPageData->doc3;?></h4>
                        </div>
                    </div>

                    <div class="col-sm-3">
                        <div class="document-box"><img src="<?=base_url('assets/images/photograph.png');?>" />
                            <h4><?php echo $detailPageData->doc4;?></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style>
        .card-front button {
            text-transform: capitalize !important;
        }

    </style>

    <script>
        function myFunction() {
            var x = document.getElementById("login_password-2");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
        }

    </script>
    <style>
        .review-rate {
            color: #fcc813;
            text-align: center;
            font-size: 18px;
        }

    </style>



    <section class="strip-line">
        For any Enquiry +91-<?php echo $settings->phone; ?>
    </section>


    <style>
        .olcode {
            background: #eee;
            border: #ccc;
            padding: 30px 20px;
        }

    </style>

    <a href="tel:+919044440777" class="mobile-phone"><i class="fa fa-phone" aria-hidden="true"></i></a>
    <div class="partners">
        <div class="border-box">
            <div class="container">
                <h3 class="custom-text"><span>Why choose MADHUKRIPA CORPORATE CONSULTANT</span></h3>
                <div class="row">
                     <?php if(!empty($testimonial)){
                            foreach($testimonial as $testi){ ?>
                        <div class="col-sm-3">
                        <div class="partners-box">
                            <img src="<?php echo $testi->image; ?>" class="img-responsive" style="height: 70px;">
                            <p><?php echo $testi->description; ?>
                            </p>
                        </div>
                        </div>            
                            <?php }} ?>  
                    
                </div>
            </div>
        </div>
    </div>

    <div class="inmedia">
        <div class="container">
            <h2 class="custom-text"><span>IN THE MEDIA</span></h2>
            <?php if(!empty($clientlogo)){
                    foreach($clientlogo as $cl){ ?>
            <li><img src="<?php echo $cl->image;?>" class="img-responsive"></li>            
            <?php }} ?>
        </div>
    </div>


    <section class="contact-page">
        <div class="container">
            <div class="row">
                <div class="contact-box">
                    <h4>CONNECT WITH US</h4>
                    <ul class="socala-icon">
                        <li><a href="" target="_blank"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="" target="_blank"><i class="fa fa-google-plus"></i></a></li>
                    </ul>
                    <div class="box-border"></div>
                </div>
            </div>
        </div>
    </section>


    <?php include_once('includes/footer.php'); ?>

    



    <script src="<?=base_url('assets/js/bootstrap.min.js');?>"></script>
    <script src="<?=base_url('assets/js/owl.carousel.min.js');?>"></script>
    <script src="<?=base_url('asstes/js/custom-file-input.js');?>"></script>
    <script src="<?=base_url('assts/js/jquery.custom-file-input.js');?>"></script>
    <script src="<?=base_url('assets/js/bootstrap-filestyle.min.js');?>">


    </script>
    <script src="<?=base_url('assets/js/jquery.validate.min.js');?>"></script>
    <script src="<?=base_url('assets/js/cms.js');?>"></script>

    <script>
        $('.owl-carousel').owlCarousel({
            loop: false,
            margin: 20,
            nav: true,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1,
                    nav: true
                },
                600: {
                    items: 2,
                    nav: true
                },
                1000: {
                    items: 3,
                    nav: true,
                    loop: false
                }
            }
        })

    </script>
    <script src="<?=base_url('assets/js/main.js');?>"></script>

    <script>
        $(document).ready(function() {
            //console.log("document ready!");

            var $sticky = $('.sticky');
            var $stickyrStopper = $('.sticky-stopper');
            if (!!$sticky.offset()) { // make sure ".sticky" element exists

                var generalSidebarHeight = $sticky.innerHeight();
                var stickyTop = $sticky.offset().top;
                var stickOffset = 0;
                var stickyStopperPosition = $stickyrStopper.offset().top;
                var stopPoint = stickyStopperPosition - generalSidebarHeight - stickOffset;
                var diff = stopPoint + stickOffset - 150;

                $(window).scroll(function() { // scroll event
                    var windowTop = $(window).scrollTop(); // returns number

                    if (stopPoint < windowTop) {
                        $sticky.css({
                            position: 'absolute',
                            top: diff
                        });
                    } else if (stickyTop < windowTop + stickOffset) {
                        $sticky.css({
                            position: 'fixed',
                            top: stickOffset
                        });
                    } else {
                        $sticky.css({
                            position: 'absolute',
                            top: 'initial'
                        });
                    }
                });

            }
        });

    </script>
    
    <script type="text/javascript">
        $('input[type="file"]').bind('change', function() {
            alert('successfully uploaded');
        });

    </script>
    <script>
        var dyu = 0;
        var timerinter = setInterval(function() {
            if (jQuery('.alert-success:contains("Thanks for showing your ")').is(":visible") && window.location.pathname == "/import-export-code.html") {
                if (dyu == 0) {
                    gtag('event', 'conversion', {
                        'send_to': 'AW-877903489/my7PCL-5kXsQgf3OogM'
                    });
                    dyu = 1;
                }
                clearInterval(timerinter);
            }
        })

    </script>

</body>

</html>

