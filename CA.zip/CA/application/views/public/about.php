<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="MKCconsultant" />
    <meta name="description" content="MKCconsultant" />    

    <title>MKCconsultant</title>
    
    <meta name="google-site-varification" content="" />
    <meta name="msvalidate.01" content="" />
    <meta name="alexaVerifyID" content="" />
    <meta name="yandex-varification" content="" />
    <meta name="y_key" content="" />
    <meta name="p:domain_verify" content="" />
  <?=link_tag('assets/css/bootstrap.min.css');?>
    <?=link_tag('assets/css/navbar.css');?>
    <?=link_tag('assets/css/style.css');?>
    <?=link_tag('assets/css/dashbord-body.css');?>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <?=link_tag('assets/css/owl.carousel.css');?>
    <?=link_tag('assets/css/select2.min.css');?>
    <?=link_tag('assets/css/jquery-ui.min.css');?>
    <?=link_tag('assets/css/cms.css');?>

    
    
    <meta property="fb:pages" content="339288996194866" />
    <script charset="UTF-8" src="//cdn.sendpulse.com/9dae6d62c816560a842268bde2cd317d/js/push/35d9ae3253fff0739ae593b8860f262d_1.js" async></script>
</head>

<body data-path="">
    <header>
       <?php include_once('includes/header.php'); ?>
    </header>

    <div class="about-header text-center" style="background:url()">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <h2></h2>
                    <p></p>
                </div>
            </div>
        </div>
    </div>

    <div class="">
    </div>



    <div class="">



        <style>
            .about-header {
                display: none;
            }

        </style>
         <div class="">
    
        <img src="<?php echo base_url('assets/images/about.png') ?>" alt="img" style="width: 100%;height: 339px;">
        </div>

        <div class="container idea">
            <div class="row" style="margin-top: -31px;">
                <div class="col-sm-8 col-md-9">
                    <h2>WHY WE ARE HERE?</h2>
                    <p><?=$about->description;?></P>
                    <p class="text-right"><strong>MKCConsultant</strong></p>
                </div>

                <div class="col-md-3 col-sm-4">
                    <img src="http://clccharter.org/aa/projects/writers%20workshop/amanda/webseries/images/idea.jpg" class="img-responsive">
                </div>
            </div>
        </div>

        <div class="about-box">
            <div class="col-sm-4 box1">
                <p>Registration under GSTn/Service Tax/Vat , Tax Consultant </p>
            </div>

            <div class="col-sm-4 box2">
                <p>Registration of Trademark/FSSAI/Labor Act/PPF.</p>
            </div>

            <div class="col-sm-4 box3">
                <p>Registraion of ISO /ESIC / TAN /PAN /EPF / Import Export Code / Society.</p>
            </div>
        </div>

        
        <br><br><br><br>
        

    </div>


    <style>
        .olcode {
            background: #eee;
            border: #ccc;
            padding: 30px 20px;
        }

    </style>

    
    <div class="partners">
        <div class="border-box">
            <div class="container">
                <h3 class="custom-text"><span>Why choose MADHUKRIPA CORPORATE CONSULTANT</span></h3>
                <div class="row">
                    <?php if(!empty($testimonial)){
                            foreach($testimonial as $testi){ ?>
                        <div class="col-sm-3">
                        <div class="partners-box">
                            <img src="<?php echo $testi->image; ?>" class="img-responsive" style="height: 70px;">
                            <p><?php echo $testi->description; ?>
                            </p>
                        </div>
                        </div>            
                            <?php }} ?>  
                </div>
            </div>
        </div>
    </div>

    <div class="inmedia">
        <div class="container">
            <h2 class="custom-text"><span>IN THE MEDIA</span></h2>
            <?php if(!empty($clientlogo)){
                    foreach($clientlogo as $cl){ ?>
            <li><img src="<?php echo $cl->image;?>" class="img-responsive"></li>            
            <?php }} ?>
        </div>
    </div>


    <section class="contact-page">
        <div class="container">
            <div class="row">
                <div class="contact-box">
                    <h4>CONNECT WITH US</h4>
                    <ul class="socala-icon">
                        <li><a href="" target="_blank"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="" target="_blank"><i class="fa fa-google-plus"></i></a></li>
                    </ul>
                    <div class="box-border"></div>
                </div>
            </div>
        </div>
    </section>


    <?php include_once('includes/footer.php'); ?>


    <script src="<?=base_url('assets/js/bootstrap.min.js');?>"></script>
    <script src="<?=base_url('assets/js/owl.carousel.min.js');?>"></script>
    <script src="<?=base_url('asstes/js/custom-file-input.js');?>"></script>
    <script src="<?=base_url('assts/js/jquery.custom-file-input.js');?>"></script>
    <script src="<?=base_url('assets/js/bootstrap-filestyle.min.js');?>">


    </script>
    <script src="<?=base_url('assets/js/jquery.validate.min.js');?>"></script>
    <script src="<?=base_url('assets/js/cms.js');?>"></script>

    

    
   
    

</body>

</html>

