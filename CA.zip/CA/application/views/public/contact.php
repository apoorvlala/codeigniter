<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Contact Us" />
    <meta name="description" content="Contact Us" />
    

    <title>Contact Us</title>

    <link rel="canonical" href="https://www.e-startupindia.com/contact-us.html">
    <meta name="google-site-varification" content="" />
    <meta name="msvalidate.01" content="" />
    <meta name="alexaVerifyID" content="" />
    <meta name="yandex-varification" content="" />
    <meta name="y_key" content="" />
    <meta name="p:domain_verify" content="" />
    <?=link_tag('assets/css/bootstrap.min.css');?>
    <?=link_tag('assets/css/navbar.css');?>
    <?=link_tag('assets/css/style.css');?>
    <?=link_tag('assets/css/dashbord-body.css');?>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <?=link_tag('assets/css/owl.carousel.css');?>
    <?=link_tag('assets/css/select2.min.css');?>
    <?=link_tag('assets/css/jquery-ui.min.css');?>
    <?=link_tag('assets/css/cms.css');?>

    <script src="<?php echo base_url('assets/js/jquery.js');?>"></script>
    
    <script charset="UTF-8" src="//cdn.sendpulse.com/9dae6d62c816560a842268bde2cd317d/js/push/35d9ae3253fff0739ae593b8860f262d_1.js" async></script>
    <script src='https://www.google.com/recaptcha/api.js'></script>
        <!--CONTAINER-->
        <script type="text/javascript">
        function get_action() {
            var v = grecaptcha.getResponse();
            console.log("Resp" + v);
            if (v == '') {
                document.getElementById('captcha').innerHTML = "You are a Robot..";
                return false;
            }
        }
    </script>
        <script type="text/javascript">  
    var your_site_key = '<%= ConfigurationManager.AppSettings["6LeKeGgUAAAAAAq0m5SlU8yJwKgjmFETYo0y0ngw"]%>';  
    var renderRecaptcha = function () {  
        grecaptcha.render('ReCaptchContainer', {  
            'sitekey': 6LeKeGgUAAAAAAq0m5SlU8yJwKgjmFETYo0y0ngw,  
            'callback': reCaptchaCallback,  
            theme: 'light', //light or dark    
            type: 'image',// image or audio    
            size: 'normal'//normal or compact    
        });  
    };  
  
    var reCaptchaCallback = function (response) {  
        if (response !== '') {  
            jQuery('#lblMessage').css('color', 'green').html('Success');  
        }  
    };  
  
    jQuery('#googlec').click(function(e) {  
        var message = 'Please checck the checkbox';  
       // alert (message);
        if (typeof (grecaptcha) != 'undefined') {  
            var response = grecaptcha.getResponse();  
            (response.length === 0) ? (message = 'Captcha verification failed') : (message = 'Success!');  
        }  
        jQuery('#lblMessage').html(message);  
        jQuery('#lblMessage').css('color', (message.toLowerCase() == 'success!') ? "green" : "red");  
    });  
</script>
</head>

<body data-path="">
    <header>
        <?php include_once('includes/header.php'); ?>
    </header>


    <img src="https://www.cubber.in/front_end/image/contactus_img.png" style="width:100%;height: 339px;">

 
    <div class="">

        <section class="contact-page">
            <div class="container">

<?php if(isset($_POST['contact_us'])){
                         $form_name=$_POST['form_name'];
                        $form_email=$_POST['form_email'];
                        $form_mobilenumber=$_POST['form_mobilenumber'];
                        $form_message=$_POST['form_message'];
                        $to="harshitrastogi615@gmail.com";
                        $subject="Online Enquiry Form submitted by :" .$form_name;
                        $message=" Name -".$form_name. " Email ID -" . $form_email." Phone No:".$form_mobilenumber." Message: ".$form_message;
			            $headers="From:".$form_email ."\r\n";

			           mail($to,$subject,$message,$headers) ;

			            echo "<script>alert ('Thank you...We will contact you shortly.'); </script>";
                    } ?>

<div class="row">
    <div class="col-lg-4">
        <div class="enquiry-form">
                    <h4>For Any Enquiry</h4>
                    <form action="" method="post" name="contactus" id="contactus" onsubmit="return get_action();">

                        <input type="text" name="form_name" placeholder="Name" value="" />


                        <input type="email" name="form_email" placeholder="Email Address" value="" />


                        <input type="text" name="form_mobilenumber" placeholder="Mobile Number" value="" />

                        <textarea name="form_message" placeholder="Message" rows="5"></textarea>


                        <div class="captcha-code">
                            <div class="g-recaptcha" data-sitekey="6LeKeGgUAAAAAAq0m5SlU8yJwKgjmFETYo0y0ngw"></div>
                                    <div id="captcha" style="color:red;font-size:20px;font-weight: bold;"></div>
                            
                        </div>

                        <button type="sunmit" name="contact_us" id="contactsubmit">Send</button>
                    </form>
                </div>
    </div>
    <div class="enquiry-form col-lg-4">
        <div class="enquiry-form">
        <br>
         <b>Company Name: <?=$settings->companyname;?></b> 
          <br/>
          
           <br />
            Phone: +91 <?=$settings->phone;?><br />
            E-mail: <?=$settings->email;?><br />
            <br /><br />
            <b>Address:</b><br />
            <p><?=$settings->address;?></p>
            <br />
        </div>
    </div>
    <div class="enquiry-form col-lg-4">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.6036173479843!2d80.92138531463549!3d26.884331983139816!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399956210072262f%3A0xe4708b0f3ac6f949!2sMadhuKripa+Corporate+Consultant+(p)+Ltd!5e0!3m2!1sen!2sin!4v1533541542899" width="400" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>
</div>
            </div>
        </section>
    </div>


    <style>
        .olcode {
            background: #eee;
            border: #ccc;
            padding: 30px 20px;
        }

    </style>


    <div class="partners">
        <div class="border-box">
            <div class="container">
                <h3 class="custom-text"><span>Why choose MADHUKRIPA CORPORATE CONSULTANT</span></h3>
                <div class="row">
                     <?php if(!empty($testimonial)){
                            foreach($testimonial as $testi){ ?>
                        <div class="col-sm-3">
                        <div class="partners-box">
                            <img src="<?php echo $testi->image; ?>" class="img-responsive" style="height: 70px;">
                            <p><?php echo $testi->description; ?>
                            </p>
                        </div>
                        </div>            
                            <?php }} ?>  
                </div>
            </div>
        </div>
    </div>

    <div class="inmedia">
        <div class="container">
            <h2 class="custom-text"><span>IN THE MEDIA</span></h2>
            <?php if(!empty($clientlogo)){
                    foreach($clientlogo as $cl){ ?>
            <li><img src="<?php echo $cl->image;?>" class="img-responsive"></li>            
            <?php }} ?>
        </div>
    </div>


    <section class="contact-page">
        <div class="container">
            <div class="row">
                <div class="contact-box">
                    <h4>CONNECT WITH US</h4>
                    <ul class="socala-icon">
                        <li><a href="" target="_blank"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="" target="_blank"><i class="fa fa-google-plus"></i></a></li>
                    </ul>
                    <div class="box-border"></div>
                </div>
            </div>
        </div>
    </section>


    <?php include_once('includes/footer.php'); ?>

    <script src="<?=base_url('assets/js/jquery.js');?>"></script>
    <script src="<?=base_url('assets/js/bootstrap.min.js');?>"></script>
    <script src="<?=base_url('assets/js/main.js');?>"></script>

    <!-- Validation -->
    <script src="<?=base_url('assets/js/validation.js');?>"></script>
    <script src="<?=base_url('assets/js/cms.js');?>"></script>





</body>

</html>
