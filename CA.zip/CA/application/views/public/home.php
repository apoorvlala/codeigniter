<!DOCTYPE html>
<html lang="en">
<?php include_once('includes/functions.php'); ?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <!--    <link rel="shortcut icon" href=""></link>-->

    <title><?php echo $settings->companyname; ?></title>
    <link rel="canonical" href="">
    <meta name="google-site-varification" content="" />
    <meta name="msvalidate.01" content="" />
    <meta name="alexaVerifyID" content="" />
    <meta name="yandex-varification" content="" />
    <meta name="y_key" content="" />
    <meta name="p:domain_verify" content="" />
    <?=link_tag('assets/css/bootstrap.min.css');?>
        <?=link_tag('assets/css/navbar.css');?>
            <?=link_tag('assets/css/style.css');?>

                <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

                <?=link_tag('assets/css/cms.css');?>

                    <style>
                        .home-service-content {
                            min-height: 140px;
                        }

                    </style>
                    <meta property="fb:pages" content="339288996194866" />
                    <!--TAWK API HERE-->
                    
                    <script>
                        window.dataLayer = window.dataLayer || [];

                        function gtag() {
                            dataLayer.push(arguments);
                        }
                        gtag('js', new Date());

                        gtag('config', 'UA-83868955-1');

                    </script>
                    <meta name="google-site-verification" content="Z_WxfkGBCKft2aWkpAZMA5RnUUxBPZGUnU6a5LYwg6I" />
                    <script charset="UTF-8" src="//cdn.sendpulse.com/9dae6d62c816560a842268bde2cd317d/js/push/35d9ae3253fff0739ae593b8860f262d_1.js" async></script>
<style>
    .h-margin {
    margin-top: -84px;
}
</style>
<script src='https://www.google.com/recaptcha/api.js'></script>
    <script type="text/javascript">
        function get_action() {
            var v = grecaptcha.getResponse();
            console.log("Resp" + v);
            if (v == '') {
                document.getElementById('captcha').innerHTML = "You are a Robot..";
                return false;
            }
        }
    </script>
        <script type="text/javascript">  
    var your_site_key = '<%= ConfigurationManager.AppSettings["6LeKeGgUAAAAAAq0m5SlU8yJwKgjmFETYo0y0ngw"]%>';  
    var renderRecaptcha = function () {  
        grecaptcha.render('ReCaptchContainer', {  
            'sitekey': 6LeKeGgUAAAAAAq0m5SlU8yJwKgjmFETYo0y0ngw,  
            'callback': reCaptchaCallback,  
            theme: 'light', //light or dark    
            type: 'image',// image or audio    
            size: 'normal'//normal or compact    
        });  
    };  
  
    var reCaptchaCallback = function (response) {  
        if (response !== '') {  
            jQuery('#lblMessage').css('color', 'green').html('Success');  
        }  
    };  
  
    jQuery('#googlec').click(function(e) {  
        var message = 'Please checck the checkbox';  
       // alert (message);
        if (typeof (grecaptcha) != 'undefined') {  
            var response = grecaptcha.getResponse();  
            (response.length === 0) ? (message = 'Captcha verification failed') : (message = 'Success!');  
        }  
        jQuery('#lblMessage').html(message);  
        jQuery('#lblMessage').css('color', (message.toLowerCase() == 'success!') ? "green" : "red");  
    });  
</script>

</head>

<body>
    <div class="container text-center " id="main_e_popup">
        <div class="modal fade" id="exitpopup">
            <div class="modal-content" style="background-image: url(); display:block;max-width:850px;margin:auto;">
                <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                    <!-- Wrapper for slides -->
                    <div class="carousel-inner">
                        <div style="border:1px solid #fcc813; margin:5px 5px 50px 5px ">
                            <div class="col-md-12 col-sm-12" style=" border:1px solid #fcc813; padding:0px;">


                                <div class="col-md-12 col-sm-12" style="margin:0px 10px 10px 10px; padding:0px 10px 10px 10px">
                                    <div class="modal-header" align="right" style="padding: 5px!important;">
                                        <label style="font-weight:600; font-size:18px; padding:2px 5px; color:#000;" data-dismiss="modal">Close</label>
                                        <button data-dismiss="modal" type="button" id="close" page="" class="close" aria-label="Close" style="border:1px solid #eeeeee">

                                            <span class="fa fa-close" aria-hidden="true" style="color:#000; "></span>
                                         </button>
                                    </div>
                                    <h5 style="padding:4px ; margin:0px; text-align:left"><strong>WHY OPT COSTLY TRADITIONAL CONSULTANT</strong></h5>
                                    <h5 style="padding:4px; margin:0px; text-align:left"><strong><b style="color:#fcc813">EXPERIENCE TAX BUSINESS INDIA ONLINE COMPETITIVE SERVICES…</b> GO DIGITAL!!!!</strong></h5>

                                </div>
                                <div class="col-md-12 col-sm-12">
                                    <div class="col-md-6 col-sm-6">
                                        <img src="<?=base_url('assets/images/^D087C8F039C0B5802FDC0D887905EF604C5CEF12AB959E5420^pimgpsh_fullsize_distr.png');?>" style="max-width:100%;">
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <div>
                                            <ul style="padding:0px">
                                                <li style="font-size:16px; text-align:left"><span class="fa fa-check" style="padding: 0 10px 0 0; color:#fcc813; text-align:left"></span>Consultancy over phone from CA/CS/Lawyers</li>
                                                <li style="font-size:16px; text-align:left"><span class="fa fa-check" style="padding: 0 10px 0 0; color:#fcc813"></span>Serve online while you sitting at home</li>
                                                <li style="font-size:16px; text-align:left"><span class="fa fa-check" style="padding: 0 10px 0 0; color:#fcc813"></span>Happily, Serve 100 plus startups on daily basis</li>
                                                <li style="font-size:16px; text-align:left"><span class="fa fa-check" style="padding: 0 10px 0 0; color:#fcc813"></span>Presence all over India</li>
                                                <li style="font-size:16px; text-align:left"><span class="fa fa-check" style="padding: 0 10px 0 0; color:#fcc813"></span>Online payment &amp; 100% Money back guarantee</li>
                                                <ul>
                                        </div>
                                        <h5 style="color:#333; text-align:centerimportant; font-weight:600;">FILL BELOW FORM, ARRANGE FREE EXPERT CALL NOW!!!</h5>
                                        <form method="post" id="form_hovertext" action="" class="about-contact">
                                            <div class="col-md-12 col-sm-12 about-margin-5">
                                                <input type="text" name="name" id="name" placeholder="Full Name" class="form-control about-form-class" />
                                            </div>
                                            <div class="col-md-12 col-sm-12 about-margin-5">
                                                <input type="text" name="email" id="email" placeholder="Email Address" class="form-control about-form-class" />
                                            </div>
                                            <div class="col-md-12 col-sm-12 about-margin-5">
                                                <input type="text" name="mobile" id="mobile" placeholder="Mobile Number" class="form-control about-form-class" />
                                            </div>

                                            <div class="col-md-12 about-margin-20" style="text-align:center">
                                                <button type="submit" name="hoversubmition" id="hoversubmition exitpopup_bg" class="white-btn btn about-button1 " />Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <header>
        <?php include_once('includes/header.php'); ?>


    </header>
    <div class="home-banner">
        <div class="container">
            <h1>Let's consult & start your business</h1>
            <P>It's free and always will be !!!</P>
            <button class="arngcall" data-toggle="modal" data-target="#bannerpopup">ARRANGE CALL</button>
            <button class="arngcall" data-toggle="modal" data-target="#bannerpopup">QUERY NOW</button>
        </div>
<?php if(isset($_POST['call'])){
                         $name=$_POST['name'];
                        $mobile=$_POST['mobile'];
                        $email=$_POST['email'];
                        $to="harshitrastogi615@gmail.com";
                        $subject="Online Enquiry Form submitted by :" .$name;
                        $message=" Name -".$name. " Phone No:".$mobile." Email-".$email;

			           mail($to,$subject,$message) ;

			            echo "<script>alert ('Thank you...We will contact you shortly.'); </script>";
                    } ?>
        <div id="bannerpopup" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <div class="bannerpopup">
                    <button type="button" class="close" data-dismiss="modal" style="position:absolute;right: 0;width: 32px;opacity:1!important;top: 0;">&times;</button>
                    <h2>Want expert to call you ?</h2>
                    <form onsubmit="return get_action();" method="post" action="" class="enquiry-form">
                        <input type="text" name="name" class="lettersOnly" required placeholder="Name">
                        <input type="text" name="mobile" id="p" onchange="validateMobile(this.value , this.id);" required placeholder="Mobile Number">
                        <input type="email" name="email" id="e" onchange="validateEmail(this.value ,this.id);" required placeholder="Email">
                        <div class="input-group g-recaptcha" data-sitekey="6LeKeGgUAAAAAAq0m5SlU8yJwKgjmFETYo0y0ngw"></div>
                                    <div id="captcha" style="color:red;font-size:20px;font-weight: bold;"></div><br>
                        <button type="submit" name="call">SUBMIT</button>
                    </form>
                    <p>Call Support : +919044440777 ( Mon- Sat , From 10 AM to 8 PM )</p>
                </div>
            </div>
        </div>

    </div>


    <div class="home-service h-margin">
        <h3 class="custom-text"><span>What we do</span></h3>
        <div class="container">
            <div class="row">
<?php if(!empty($service)){
    foreach($service as $ser){ ?>
        
    
                <div class="col-sm-4">
                    <a href="" class="home-service-box">
                        <div class="home-service-icon">
                            <img src="<?php echo $ser->image; ?>" class="img-responsive">
                        </div>
                        <div class="home-service-content">
                            <h4><?php echo $ser->servicename; ?></h4>
                            <p><?php echo shortLength($ser->description,100,100).'..'; ?></p>
                        </div>
                    </a>
                </div>
                
<?php }} ?>

 
            </div>
        </div>
    </div>

    <!-- service END -->
    <hr>


    <div class="partners">
        <div class="border-box">
            <div class="container">
                <h3 class="custom-text"><span>Why choose MADHUKRIPA CORPORATE CONSULTANT</span></h3>
                <div class="row">
                   <?php if(!empty($testimonial)){
                            foreach($testimonial as $testi){ ?>
                        <div class="col-sm-3">
                        <div class="partners-box">
                            <img src="<?php echo $testi->image; ?>" class="img-responsive" style="height: 70px;">
                            <p><?php echo $testi->description; ?>
                            </p>
                        </div>
                        </div>            
                            <?php }} ?>                                  
                </div>
            </div>
        </div>
    </div>

    <div class="inmedia">
        <div class="container">
            <h2 class="custom-text"><span>IN THE MEDIA</span></h2>
            <?php if(!empty($clientlogo)){
                    foreach($clientlogo as $cl){ ?>
            <li><img src="<?php echo $cl->image;?>" class="img-responsive"></li>            
                    <?php }} ?>
      
        </div>
    </div>

    <!-- start recent-news-section -->
    <div class="home-service h-margin">
        <h3 class="custom-text"><span>Recent Posts</span></h3>
        <div class="container">
            <div class="row">

               <?php if(!empty($blog_posts)){
                        foreach($blog_posts as $blog){ ?>
                   <div class="col-sm-4">
                    <a href="<?=base_url('user/blogPage');?>" class="home-service-box">
                        <div class="entry-media"> <img src="<?php echo $blog->image ;?>" alt="" style="height: 200px;width: 277px;"> </div>
                        <div class="home-service-content">
                            <h4><?php echo $blog->blogheading; ?></h4>
                            <p><?php echo shortLength($blog->description,100 , 100).'..'; ?></p>
                        </div>
                    </a>
                </div>            
                        <?php }} ?>
                
            </div>
        </div>
    </div>
    <!-- end recent-news-section -->


    <section class="contact-page">
        <div class="container">
            <div class="row">
                <div class="contact-box">
                    <h4>CONNECT WITH US</h4>
                    <ul class="socala-icon">
                        <li><a href="" target="_blank"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="" target="_blank"><i class="fa fa-google-plus"></i></a></li>
                    </ul>
                    <div class="box-border"></div>
                </div>
            </div>
        </div>
    </section>


    <?php include_once('includes/footer.php'); ?>
    

    <!-- JavaScript plugins -->
    <script src="<?=base_url('assets/js/jquery.js');?>"></script>
    <script src="<?=base_url('assets/js/bootstrap.min.js');?>"></script>
    <script src="<?=base_url('assets/js/main.js');?>"></script>

    <!-- Validation -->
    <script src="<?=base_url('assets/js/validation.js');?>"></script>
    <script src="<?=base_url('assets/js/cms.js');?>"></script>


    <!--<script>
$(window).on('load',function(){
        $('#exitpopup').modal('show');
    });
</script>-->
<script
  src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
    <script>
    
function validateEmail(email ,id)
{
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if(re.test(email)){
        return true;
    }
    else
    {
       alert('Invalid email');
       $('#'+id).val("");
       $('#'+id).focus();
        return false;
    }
}

function validateMobile(number , id)
{
    var str=number;
    if(str.match(/^\d{10}$/))
    {
        return true;
    }
    else
    {
        alert('Invalid mobile no.');
        $('#'+id).val('');
        $('#'+id).focus();
        return false;
    }
}
    </script>
    
    <script>
        $(document).ready(function () {

        jQuery('.numbersOnly').keyup(function () {
        this.value = this.value.replace(/[^0-9\.]/g,'');
        });

        jQuery('.lettersOnly').keyup(function () {
        this.value = this.value.replace(/[^a-zA-Z\s]+$/g,'');
        });

        jQuery('.alphanimericOnly').keyup(function () {
        this.value = this.value.replace(/[^A-Za-z0-9.\/\s]/g,'');
        });

        jQuery('.address').keyup(function () {
        this.value = this.value.replace(/[^A-Za-z0-9//,.\/\s]/g,'');

        });

        jQuery('.email').on('change', function(){
        var valid = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/.test(this.value);
        if(valid){}
        else{
            alert('please enter correct email.');
        }
        });

});

    </script>
</body>

</html>
