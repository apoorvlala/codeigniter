<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="<?=$blog->metakeyword;?>" />
    <meta name="description" content="<?=$blog->metadescription;?>" />    

    <title><?=$blog->metatitle;?></title>

    <link rel="amphtml" href="">
    <meta name="google-site-varification" content="" />
    <meta name="msvalidate.01" content="" />
    <meta name="alexaVerifyID" content="" />
    <meta name="yandex-varification" content="" />
    <meta name="y_key" content="" />
    <meta name="p:domain_verify" content="" />
    <?=link_tag('assets/css/bootstrap.min.css');?>
    <?=link_tag('assets/css/navbar.css');?>
    <?=link_tag('assets/css/style.css');?>
    <?=link_tag('assets/css/dashbord-body.css');?>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <?=link_tag('assets/css/owl.carousel.css');?>
    <?=link_tag('assets/css/select2.min.css');?>
    <?=link_tag('assets/css/jquery-ui.min.css');?>
    <?=link_tag('assets/css/cms.css');?>

    
    <meta property="fb:pages" content="339288996194866" />
    <script charset="UTF-8" src="//cdn.sendpulse.com/9dae6d62c816560a842268bde2cd317d/js/push/35d9ae3253fff0739ae593b8860f262d_1.js" async></script>
    <script src='https://www.google.com/recaptcha/api.js'></script>
    
    <script type="text/javascript">
        function get_action() {
            var v = grecaptcha.getResponse();
            console.log("Resp" + v);
            if (v == '') {
                document.getElementById('captcha').innerHTML = "You are a Robot..";
                return false;
            }
        }
    </script>
        <script type="text/javascript">  
    var your_site_key = '<%= ConfigurationManager.AppSettings["6LeKeGgUAAAAAAq0m5SlU8yJwKgjmFETYo0y0ngw"]%>';  
    var renderRecaptcha = function () {  
        grecaptcha.render('ReCaptchContainer', {  
            'sitekey': 6LeKeGgUAAAAAAq0m5SlU8yJwKgjmFETYo0y0ngw,  
            'callback': reCaptchaCallback,  
            theme: 'light', //light or dark    
            type: 'image',// image or audio    
            size: 'normal'//normal or compact    
        });  
    };  
  
    var reCaptchaCallback = function (response) {  
        if (response !== '') {  
            jQuery('#lblMessage').css('color', 'green').html('Success');  
        }  
    };  
  
    jQuery('#googlec').click(function(e) {  
        var message = 'Please checck the checkbox';  
       // alert (message);
        if (typeof (grecaptcha) != 'undefined') {  
            var response = grecaptcha.getResponse();  
            (response.length === 0) ? (message = 'Captcha verification failed') : (message = 'Success!');  
        }  
        jQuery('#lblMessage').html(message);  
        jQuery('#lblMessage').css('color', (message.toLowerCase() == 'success!') ? "green" : "red");  
    });  
</script>
</head>

    <header>
        <?php include_once('includes/header.php'); ?>
    </header>


    <div class="">

        <section class="blog-listing marginT20 ">
            <div class="container">
                <div class="row">

                    <div class="blog-box col-sm-9 col-sm-push-3">
                        <div class="">
                        
                            <div class="blogs-container shadow-none">

                                <div class="blog-img-header">
                                    <img src="<?= $blog->image; ?>" alt="image" style="height: 350px;">
                                    <p class="col-xs-12"><small><?= $blog->date; ?></small><small class="pull-right">Posted By: MKC Consultant</small></p>
                                </div>
                        
                                <div class="clearfix"></div>
                           
                                <div class="blog-content-body col-xs-12">
                                    <h2 class="text-left"><?=$blog->blogheading;?></h2>
                                    <p>
                                        <p dir="ltr" style="text-align:justify"><span style="font-family:tahoma,geneva,sans-serif"><span style="font-size:16px"><span style="color:#000000"><span style="background-color:transparent"><?=$blog->description;?></span></span>
                                            </span>
                                            </span>
                                        </p>

                                </div>
                                
                            </div>
<?php if(isset($_POST['LeftEnquersubmitBtn'])){
                         $name=$_POST['enquiry_name'];
                        $email_address=$_POST['enquiry_email'];
                        $mobile_number=$_POST['enquiry_phone'];
                        $to="apoorduplex@gmail.com";
                        $subject="Online Enquiry Form submitted by :" .$name;
                        $message=" Name -".$name. " Email ID -" . $email_address." Subject:". $subject." Phone No:".$mobile_number;
			            $headers="From:".$email_address ."\r\n";

			           mail($to,$subject,$message,$headers) ;

			            echo "<script>alert ('Thank you...We will contact you shortly.'); </script>";
                    } ?>

                        </div>
                    </div>
                    <div class=" col-sm-3 sidebar col-sm-pull-9">


                        <div class="gst-form sticky">
                            <form onsubmit="return get_action();" action="" method="post">
                                <h4 class="text-center"><strong style="font-size:20px">Need help ?</strong><br><span style="font-size:16px;text-transform:uppercase">Arrange a call from <br>business advisors</span></h4>
                                <div class="input-group">
                                    <span class="input-group-addon" id="basic-addon1"><i class="fa fa-user" aria-hidden="true"></i></span>
                                    <input type="text" name="enquiry_name" class="lettersOnly form-control" placeholder="Your Name" aria-describedby="basic-addon1">
                                </div>

                                <div class="input-group">
                                    <span class="input-group-addon" id="basic-addon1"><i class="fa fa-envelope-o" aria-hidden="true"></i></span>
                                    <input type="email" id="e" onchange="validateEmail(this.value ,this.id);" name="enquiry_email" class="form-control" placeholder="Your Email" aria-describedby="basic-addon1">
                                </div>

                                <div class="input-group">
                                    <span class="input-group-addon" id="basic-addon1"><i class="fa fa-phone" aria-hidden="true"></i></span>
                                    <input type="text" id="p" name="enquiry_phone" class="numbersOnly form-control" placeholder="Your Mobile No" aria-describedby="basic-addon1" onchange="validateMobile(this.value , this.id);">
                                </div>
                                    <div class="input-group g-recaptcha" data-sitekey="6LeKeGgUAAAAAAq0m5SlU8yJwKgjmFETYo0y0ngw"></div>
                                    <div id="captcha" style="color:red;font-size:20px;font-weight: bold;"></div>
                                <button type="submit" name="LeftEnquersubmitBtn" value="Submit">SUBMIT</button>

                            </form>
                        </div>
                        <style></style>


                    </div>
                </div>
            </div>
            
        </section>

    </div>



    <div class="">

    </div>


    <style>
        .olcode {
            background: #eee;
            border: #ccc;
            padding: 30px 20px;
        }

    </style>

    <a href="tel:+918881069069" class="mobile-phone"><i class="fa fa-phone" aria-hidden="true"></i></a>
    <div class="partners">
        <div class="border-box">
            <div class="container">
                <h3 class="custom-text"><span>Why choose MADHUKRIPA CORPORATE CONSULTANT</span></h3>
                <div class="row">
                   <?php if(!empty($testimonial)){
                            foreach($testimonial as $testi){ ?>
                        <div class="col-sm-3">
                        <div class="partners-box">
                            <img src="<?php echo $testi->image; ?>" class="img-responsive" style="height: 70px;">
                            <p><?php echo $testi->description; ?>
                            </p>
                        </div>
                        </div>            
                            <?php }} ?>  
                </div>
            </div>
        </div>
    </div>

    <div class="inmedia">
        <div class="container">
            <h2 class="custom-text"><span>IN THE MEDIA</span></h2>
            <?php if(!empty($clientlogo)){
                    foreach($clientlogo as $cl){ ?>
            <li><img src="<?php echo $cl->image;?>" class="img-responsive"></li>            
            <?php }} ?>
        </div>
    </div>


    <section class="contact-page">
        <div class="container">
            <div class="row">
                <div class="contact-box">
                    <h4>CONNECT WITH US</h4>
                    <ul class="socala-icon">
                        <li><a href="" target="_blank"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="" target="_blank"><i class="fa fa-google-plus"></i></a></li>
                    </ul>
                    <div class="box-border"></div>
                </div>
            </div>
        </div>
    </section>


    <?php include_once('includes/footer.php'); ?>


 <script src="<?=base_url('assets/js/bootstrap.min.js');?>"></script>
    <script src="<?=base_url('assets/js/owl.carousel.min.js');?>"></script>
    <script src="<?=base_url('asstes/js/custom-file-input.js');?>"></script>
    <script src="<?=base_url('assts/js/jquery.custom-file-input.js');?>"></script>
    <script src="<?=base_url('assets/js/bootstrap-filestyle.min.js');?>">


    </script>
    <script src="<?=base_url('assets/js/jquery.validate.min.js');?>"></script>
    <script src="<?=base_url('assets/js/cms.js');?>"></script>
<script
  src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>

<script>
function validateEmail(email ,id)
{
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if(re.test(email)){
        return true;
    }
    else
    {
       alert('Invalid email');
       $('#'+id).val("");
       $('#'+id).focus();
        return false;
    }
}

function validateMobile(number , id)
{
    var str=number;
    if(str.match(/^\d{10}$/))
    {
        return true;
    }
    else
    {
        alert('Invalid mobile no.');
        $('#'+id).val('');
        $('#'+id).focus();
        return false;
    }
}
    </script>
    
    <script>
        $(document).ready(function () {

        jQuery('.numbersOnly').keyup(function () {
        this.value = this.value.replace(/[^0-9\.]/g,'');
        });

        jQuery('.lettersOnly').keyup(function () {
        this.value = this.value.replace(/[^a-zA-Z\s]+$/g,'');
        });

        jQuery('.alphanimericOnly').keyup(function () {
        this.value = this.value.replace(/[^A-Za-z0-9.\/\s]/g,'');
        });

        jQuery('.address').keyup(function () {
        this.value = this.value.replace(/[^A-Za-z0-9//,.\/\s]/g,'');

        });

        jQuery('.email').on('change', function(){
        var valid = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/.test(this.value);
        if(valid){}
        else{
            alert('please enter correct email.');
        }
        });

});

    </script>


</body>

</html>
