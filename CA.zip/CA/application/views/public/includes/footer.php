<footer>
        <a href="tel:+919044440777" class="mobile-phone"><i class="fa fa-phone" aria-hidden="true"></i></a>
        <section class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-3">
                        <div class="flogo">
                            <img src="<?=base_url('assets/images/logo.png')?>" style="width:244px">
                        </div>
                        <li><a href=""><i class="fa fa-chevron-right" aria-hidden="true"></i> About Us</a></li>
                        <li><a href=""><i class="fa fa-chevron-right" aria-hidden="true"></i> Customer Reviews</a></li>
                        <li><a href=""><i class="fa fa-chevron-right" aria-hidden="true"></i> Career</a></li>
                        <li><a href=""><i class="fa fa-chevron-right" aria-hidden="true"></i> Contact Us</a></li>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <h4>Our Popular Services</h4>
                        <li><a href=""><i class="fa fa-chevron-right" aria-hidden="true"></i> Company Formation</a></li>
                        <li><a href=""><i class="fa fa-chevron-right" aria-hidden="true"></i> Trademark</a></li>
                        <li><a href=""><i class="fa fa-chevron-right" aria-hidden="true"></i> GST Registration</a></li>
                        <li><a href=""><i class="fa fa-chevron-right" aria-hidden="true"></i> ISO Certification</a></li>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <h4>Terms & Policy</h4>
                        <li><a href=""><i class="fa fa-chevron-right" aria-hidden="true"></i> Terms & Conditions</a></li>
                        <li><a href=""><i class="fa fa-chevron-right" aria-hidden="true"></i> Privacy Policy</a></li>
                        <li><a href=""><i class="fa fa-chevron-right" aria-hidden="true"></i> Refund Policy</a></li>
                        <li><a href=""><i class="fa fa-chevron-right" aria-hidden="true"></i> Confidentiality Policy</a></li>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <h4>Connect With Us</h4>
                        <li><a href=""><i class="fa fa-chevron-right" aria-hidden="true"></i> Live Chat</a></li>
                        <li><a href=""><i class="fa fa-chevron-right" aria-hidden="true"></i> Partner with us</a></li>
                        <li><a href=""><i class="fa fa-chevron-right" aria-hidden="true"></i> Sitemap</a></li>
                        <li><a href="#rating" data-toggle="modal"><i class="fa fa-chevron-right" aria-hidden="true"></i> Suggestion and Feedback</a></li>
                    </div>
                </div>

                <div class="copyright">Copyright © 2018 Duplex Technologies Services Private Limited. All Rights Reserved</div>
            </div>
        </section>
    </footer>
