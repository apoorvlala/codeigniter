
           <div class="container">
            <div class="row">
                <div class="col-sm-3 logo">
                    <a href=""><img src="<?=base_url('assets/images/logo.png');?>" alt="" title="" style="width: 217px;"/></a>
                </div>
                <div class="col-sm-2 col-sm-push-7 callus">
                    <a href="tel:+91<?php echo $settings->phone; ?>"><i class="fa fa-phone-volume" aria-hidden="true"></i><?php echo '+91-'.$settings->phone; ?></a>
                </div>
                <div class="col-sm-7 col-sm-pull-2 ">
                    <div class="row">
                        <div id="cssmenu">
                            <ul class="navbar-right">
                                <?php if(!empty($result)){
                                    foreach($result as $key){ ?>


                                <li><a href='<?=base_url("user/{$key->url}")?>' title=""><?=$key->menuname?> </a>
                                    <ul>
                                       <?php if(!empty($submenu)){?>
                                        <?php foreach($submenu as $sub_menu){
                                            if($sub_menu->mainmenuid==$key->id){
                                        ?>
                                        <li><a href="" title="<?=$sub_menu->submenu?>"><?=$sub_menu->submenu?> </a>
                                            <ul><?php if(!empty($sub_sub_menu)){
                                                    foreach($sub_sub_menu as $ssm){
                                                    if($ssm->subcatid==$sub_menu->id){

                                                ?>
                                                <li>
                                                    <a href='<?=base_url("services/{$ssm->url}")?>' title="<?=$ssm->subsubcat?>"><?=$ssm->subsubcat?></a>
                                                </li>
                                                <?php }}} ?>
                                            </ul>
                                        </li>
                                        <?php } } } ?>
                                    </ul>
                                </li>
                                <?php  } } ?>
                                <li><a href="tel:+919044440777">+91-9044440777</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
