<!DOCTYPE HTML>
<html>
<head>
    <title>Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Admin" />
    <?php include_once('includes/alljscss.php'); ?>

    <!--//Metis Menu -->
</head>

<body class="cbp-spmenu-push">
    <div class="main-content">
        <!--left-fixed -navigation-->
        <?php include_once('includes/navigation.php'); ?>
        <!--left-fixed -navigation-->
        <!-- header-starts -->
        <?php include_once('includes/adminheader.php'); ?>
        <!-- //header-ends -->
        <!-- main content start-->
        <div id="page-wrapper">
            <?php if($msg=$this->session->flashdata('msg')): ?>
               <div class="alert alert-dismissible alert-danger">
                   <?=$msg;?>

               </div>
               <?php endif; ?>
            <div class="main-page">
                <div class="forms">
                    <div class=" form-grids row form-grids-right">
                        <div class="widget-shadow " data-example-id="basic-forms">
                            <div class="form-title">
                                <h4>Update Detail Page :</h4>
                            </div>
                            <div class="form-body">
                               <?php echo form_open_multipart('DetailPage/updateDetailPage',['class'=>'form-horizontal']); ?>
                                    <div class="form-group"> <label for="inputEmail3" class="col-sm-2 control-label">Metatitle</label>
                                        <div class="col-sm-9">
                                        <?php
                                            $metatitle=array(
                                                'name'=>'metatitle',
                                                'class'=>'form-control',
                                                'placeholder'=>'Enter metatitle',
                                                'value'=>set_value('metatitle',$result->metatitle),
                                            );
                                            echo form_input($metatitle);
                                            echo form_hidden('id',$result->id);
                                            echo form_error('metatitle','<p class="text-danger">', '</p>');
                                            ?>

                                        </div>
                                    </div>

                                    <div class="form-group"> <label for="inputEmail3" class="col-sm-2 control-label">Metadescription</label>
                                        <div class="col-sm-9">
                                        <?php
                                            $metadescription=array(
                                                'name'=>'metadescription',
                                                'class'=>'form-control',
                                                'placeholder'=>'Enter metadescription',
                                                'value'=>set_value('metadescription',$result->metadescription),
                                            );
                                            echo form_input($metadescription);
                                            echo form_error('metadescription','<p class="text-danger">', '</p>');
                                            ?>

                                        </div>
                                    </div>

                                    <div class="form-group"> <label for="inputEmail3" class="col-sm-2 control-label">Metakeyword</label>
                                        <div class="col-sm-9">
                                        <?php
                                            $metakeyword=array(
                                                'name'=>'metakeyword',
                                                'class'=>'form-control',
                                                'placeholder'=>'Enter metakeyword',
                                                'value'=>set_value('metakeyword',$result->metakeyword),
                                            );
                                            echo form_input($metakeyword);
                                            echo form_error('metakeyword','<p class="text-danger">', '</p>');
                                            ?>

                                        </div>
                                    </div>

                                    <div class="form-group"> <label for="inputEmail3" class="col-sm-2 control-label">Top Small Heading</label>
                                        <div class="col-sm-9">
                                        <?php
                                            $small_heading=array(
                                                'name'=>'small_heading',
                                                'class'=>'form-control',
                                                'placeholder'=>'Enter top small heading',
                                                'value'=>set_value('small_heading',$result->small_heading),
                                            );
                                            echo form_input($small_heading);
                                            echo form_error('small_heading','<p class="text-danger">', '</p>');
                                            ?>

                                        </div>
                                    </div>
                                    <div class="form-group"> <label for="inputEmail3" class="col-sm-2 control-label">Enter Small Description</label>
                                        <div class="col-sm-9">
                                        <?php
                                            $small_description=array(
                                                'name'=>'small_description',
                                                'class'=>'ckeditor',
                                                'value'=>$result->small_description,
                                                'id'=>'servtextarea'

                                            );
                                            echo form_textarea($small_description);
                                            echo form_error('description','<p class="text-danger">', '</p>');
                                            ?>

                                        </div>
                                    </div>
                                    <div class="form-group"> <label for="inputEmail3" class="col-sm-2 control-label">Main Heading</label>
                                        <div class="col-sm-9">
                                        <?php
                                            $main_heading=array(
                                                'name'=>'main_heading',
                                                'class'=>'form-control',
                                                'placeholder'=>'Enter main heading',
                                                'value'=>set_value('main_heading',$result->main_heading),
                                            );
                                            echo form_input($main_heading);
                                            echo form_error('main_heading','<p class="text-danger">', '</p>');
                                            ?>

                                        </div>
                                    </div>
                                    
                                    <div class="form-group"> <label for="inputEmail3" class="col-sm-2 control-label">Enter Main Description</label>
                                        <div class="col-sm-9">
                                        <?php
                                            $main_description=array(
                                                'name'=>'main_description',
                                                'class'=>'ckeditor',
                                                'value'=>$result->main_description,
                                                'id'=>'text_main_description'

                                            );
                                            echo form_textarea($main_description);
                                            echo form_error('main_description','<p class="text-danger">', '</p>');
                                            ?>

                                        </div>
                                    </div>
                                    <div class="form-group"> <label for="inputEmail3" class="col-sm-2 control-label">Create Url</label>
                                        <div class="col-sm-9">
                                        <?php
                                            $url=array(
                                                'name'=>'url',
                                                'class'=>'form-control',
                                                'value'=>set_value('url',$result->url),
                                                'placeholder'=>'Enter url'

                                            );
                                            echo form_input($url);
                                            echo form_error('url','<p class="text-danger">', '</p>');
                                            ?>

                                        </div>
                                    </div>

                                    
                                    <div class="form-group"> <label for="inputEmail3" class="col-sm-2 control-label">Required doc1</label>
                                        <div class="col-sm-9">
                                        <?php
                                            $doc1=array(
                                                'name'=>'doc1',
                                                'class'=>'form-control',
                                                'value'=>set_value('doc1',$result->doc1),
                                                'placeholder'=>'Enter first document required'

                                            );
                                            echo form_input($doc1);
                                            echo form_error('doc1','<p class="text-danger">', '</p>');
                                            ?>

                                        </div>
                                    </div>
                                    <div class="form-group"> <label for="inputEmail3" class="col-sm-2 control-label">Required doc2</label>
                                        <div class="col-sm-9">
                                        <?php
                                            $doc2=array(
                                                'name'=>'doc2',
                                                'class'=>'form-control',
                                                'value'=>set_value('doc2',$result->doc2),
                                                'placeholder'=>'Enter second document required'

                                            );
                                            echo form_input($doc2);
                                            echo form_error('doc2','<p class="text-danger">', '</p>');
                                            ?>

                                        </div>
                                    </div>
                                    <div class="form-group"> <label for="inputEmail3" class="col-sm-2 control-label">Required doc3</label>
                                        <div class="col-sm-9">
                                        <?php
                                            $doc3=array(
                                                'name'=>'doc3',
                                                'class'=>'form-control',
                                                'value'=>set_value('doc3',$result->doc3),
                                                'placeholder'=>'Enter third document required'

                                            );
                                            echo form_input($doc3);
                                            echo form_error('doc3','<p class="text-danger">', '</p>');
                                            ?>

                                        </div>
                                    </div>
                                    <div class="form-group"> <label for="inputEmail3" class="col-sm-2 control-label">Required doc4</label>
                                        <div class="col-sm-9">
                                        <?php
                                            $doc4=array(
                                                'name'=>'doc4',
                                                'class'=>'form-control',
                                                'value'=>set_value('doc4',$result->doc4),
                                                'placeholder'=>'Enter fourth document required'

                                            );
                                            echo form_input($doc4);
                                            echo form_error('doc4','<p class="text-danger">', '</p>');
                                            ?>

                                        </div>
                                    </div>
                                    <div class="col-sm-offset-2">
                                    <?php $submit=array(
                                                'class'=>'btn btn-primary',
                                                'value'=>'UPDATE DETAILS',
                                                'name'=>'updatedetails'
                                    );
                                    echo form_submit($submit);
                                    ?>

                                    </div>
                                <?php echo form_close(); ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--footer-->
        <?php include_once('includes/footer.php'); ?>
        <!--//footer-->
    </div>
    <!-- Classie -->
    <?php include_once('includes/footerjs.php'); ?>
    <script src="<?=base_url('ckeditor/ckeditor.js')?>"></script>
    <script type="text/javascript" src="<?=base_url('ckeditor/adapters/jquery.js');?>"></script>
<script type="text/javascript">
$(function() {
    $('#servtextarea').ckeditor({
        toolbar: 'Full',
        enterMode : CKEDITOR.ENTER_BR,
        shiftEnterMode: CKEDITOR.ENTER_P
    });
});
    $(function() {
    $('#text_main_description').ckeditor({
        toolbar: 'Full',
        enterMode : CKEDITOR.ENTER_BR,
        shiftEnterMode: CKEDITOR.ENTER_P
    });
});
</script>
</body>

</html>
