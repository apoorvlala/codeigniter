<!DOCTYPE HTML>
<html>
<head>
    <title>Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Admin" />
    <?php include_once('includes/alljscss.php'); ?>
    <!--//Metis Menu -->
</head>

<body class="cbp-spmenu-push">
    <div class="main-content">
        <!--left-fixed -navigation-->
        <?php include_once('includes/navigation.php'); ?>
        <!--left-fixed -navigation-->
        <!-- header-starts -->
        <?php include_once('includes/adminheader.php'); ?>
        <!-- //header-ends -->
        <!-- main content start-->
        <div id="page-wrapper">
            <?php if($msg=$this->session->flashdata('msg')): ?>
               <div class="alert alert-dismissible alert-danger">
                   <?=$msg;?>

               </div>
               <?php endif; ?>
            <div class="main-page">
                <div class="forms">
                    <div class=" form-grids row form-grids-right">
                        <div class="widget-shadow " data-example-id="basic-forms">
                            <div class="form-title">
                                <h4>Add Category :</h4>
                            </div>
                            <div class="form-body">
                               <?php echo form_open('admin/add_category',['class'=>'form-horizontal']); ?>                                
                                    <div class="form-group"> <label for="inputEmail3" class="col-sm-2 control-label">Category Name</label>
                                        <div class="col-sm-9"> 
                                        <?php
                                            $category=array(
                                                'name'=>'category',
                                                'class'=>'form-control',
                                                'placeholder'=>'Enter category name',
                                                'value'=>set_value('category'),
                                            );
                                            echo form_input($category); 
                                            echo form_error('category','<p class="text-danger">', '</p>');
                                            ?>
                                            
                                        </div>
                                    </div>
                                    <div class="form-group"> <label for="inputEmail3" class="col-sm-2 control-label">Create Url</label>
                                        <div class="col-sm-9"> 
                                        <?php
                                            $url=array(
                                                'name'=>'url',
                                                'class'=>'form-control',
                                                'placeholder'=>'Enter url',
                                                'value'=>set_value('url'),
                                            );
                                            echo form_input($url); 
                                            echo form_error('url','<p class="text-danger">', '</p>');
                                            ?>
                                            
                                        </div>
                                    </div>                                          
                                    <div class="col-sm-offset-2">
                                    <?php $submit=array(
                                                'class'=>'btn btn-primary',
                                                'value'=>'ADD CATEGORY',
                                                'name'=>'addcategory'
                                    );
                                    echo form_submit($submit);
                                    ?>
                                     
                                    </div>
                                <?php echo form_close(); ?>
                                <div class="col-sm-offset-10">
                                    <?php $button=array(
                                                'class'=>'btn btn-primary',
                                                
                                    );                                    
                                    echo anchor('admin/show_category', 'Show All Main Menus', $button);
                                    ?>
                                     
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--footer-->
        <?php include_once('includes/footer.php'); ?>
        <!--//footer-->
    </div>
    <!-- Classie -->
    <?php include_once('includes/footerjs.php'); ?>
</body>

</html>
