
<!DOCTYPE HTML>
<html>
<head>
<title>Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Admin" />
<?php include_once('includes/alljscss.php'); ?>
<!--//Metis Menu -->
</head>
<body class="">
    <div class="main-content">
        <!--left-fixed -navigation-->
        <!--left-fixed -navigation-->
        <!-- header-starts -->

        <!-- //header-ends -->
        <!-- main content start-->
        <div id="page-wrapper">

            <div class="main-page login-page ">
                <h3 class="title1">SignIn Page</h3>
                <?php if(isset($msg)): ?>
               <div class="alert alert-dismissible alert-danger">
                   <?=$msg;?>

               </div>
               <?php endif; ?>
                <div class="widget-shadow">
                    <div class="login-top">
                        <h4>Welcome back to Novus AdminPanel.</h4>
                    </div>
                    <div class="login-body">
                        <?php echo form_open('admin/login') ?>
                        <?php
                        $username=array(
                            'name'=>'username',
                            'class'=>'user',
                            'placeholder'=>'Enter Username',
                        );
                        echo form_input($username);
                        echo form_error('username','<p class="text-danger">', '</p>');

                        $password=array(
                            'name'=>'password',
                            'class'=>'lock',
                            'placeholder'=>'Enter Password',
                        );
                        echo form_input($password);
                        echo form_error('password','<p class="text-danger">','</p>');
                        $submit=array(
                                'name'=>'login',
                                'value'=>'Login'
                        );
                        echo form_submit($submit);
                        echo form_close();
                        ?>


                    </div>
                </div>
            </div>
        </div>
        <!--footer-->
        <?php include_once('includes/footer.php'); ?>
        <!--//footer-->
    </div>
    <!-- Classie -->
        <?php include_once('includes/footerjs.php'); ?>
</body>
</html>
