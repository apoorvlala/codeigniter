<!DOCTYPE HTML>
<html>
<head>
<title>Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Admin" />
<?php include_once('includes/alljscss.php');?>
<!--//Metis Menu -->
</head> 
<body class="cbp-spmenu-push">
	<div class="main-content">
		<!--left-fixed -navigation-->
		<?php include_once('includes/navigation.php'); ?>
		<!--left-fixed -navigation-->
		<!-- header-starts -->
		<?php include_once('includes/adminheader.php'); ?>
		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">
            <?php if($msg=$this->session->flashdata('msg')): ?>
               <div class="alert alert-dismissible alert-danger">
                   <?=$msg;?>

               </div>
               <?php endif; ?>
        </div>
		<!--footer-->
		<div class="footer">
		   <p>&copy; 2018 Duplex Admin Panel. All Rights Reserved | Design by <a href="https://w3layouts.com/" target="_blank">w3layouts</a></p>
		</div>
        <!--//footer-->
	</div>
	<!-- Classie -->
	<?php include_once('includes/footerjs.php'); ?>
</body>
</html>