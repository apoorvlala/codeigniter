<!DOCTYPE HTML>
<html>

<head>
    <title>Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Admin" />
    <?php include_once('includes/alljscss.php'); ?>
    <!--//Metis Menu -->
</head>

<body class="cbp-spmenu-push">
    <div class="main-content">
        <!--left-fixed -navigation-->
        <?php include_once('includes/navigation.php'); ?>
        <!--left-fixed -navigation-->
        <!-- header-starts -->
        <?php include_once('includes/adminheader.php'); ?>
        <!-- //header-ends -->
        <!-- main content start-->
        <div id="page-wrapper">
            <div class="main-page">
                <div class="tables">
                    <div class="table-responsive bs-example widget-shadow">
                        <h4>Show Sub Sub Menus:</h4>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Sub name</th>
                                    <th>Subsub Menue</th>
                                    <th>URL of Subsubmenu</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php if(!empty($result)){ $i=0;
                                foreach($result as $data){
                                ?>
                                    <tr>
                                    <th scope="row"><?php echo ++$i; ?></th>
                                    <td><?=$data->submenu?></td>
                                    <td><?=$data->subsubcat?></td>
                                    <td><?=$data->url?></td>
                                    <td>
                                        <?php echo anchor("SubSubCategory/loadUpdateSubSubCat/{$data->id}", 'Update', ['class'=>'btn btn-primary btn-sm','target'=>'_blank']); ?>||
                                        <?php echo anchor("SubSubCategory/deleteSubsubCategory/{$data->id}", 'Delete', ['class'=>'btn btn-danger btn-sm']); ?>
                                    </td>
                                </tr>
                                <?php } } ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!--footer-->
        <?php include_once('includes/footer.php'); ?>
        <!--//footer-->
    </div>
    <!-- Classie -->
    <?php include_once('includes/footerjs.php'); ?>
</body>

</html>
