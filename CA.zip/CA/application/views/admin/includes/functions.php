<?php

function shortLength($value,$min,$max){ $company = strip_tags($value); $companyname= strlen($company) >= $max ? substr($company, 0, $min): $company; return $companyname; }

function seoUrl($string) {
    $string = strtolower($string);
    $string = preg_replace("/[^a-z0-9_\s-]/", "", $string);
    $string = preg_replace("/[\s-]+/", " ", $string);
    $string = preg_replace("/[\s_]/", "-", $string);
    return $string;
} 

?>