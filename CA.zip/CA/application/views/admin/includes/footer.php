<div class="footer">
            <p>&copy; 2018 Duplex Admin Panel. All Rights Reserved | Design by <a href="" target="_blank">Duplex Technology Services Pvt. Ltd</a></p>
        </div>