<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<?=link_tag('admin_assets/css/bootstrap.css'); ?>
<!-- Custom CSS -->
<?=link_tag('admin_assets/css/style.css'); ?>
<!-- font CSS -->
<!-- font-awesome icons -->
<?=link_tag('admin_assets/css/font-awesome.css'); ?>
<!-- //font-awesome icons -->
 <!-- js-->
<script src="<?=base_url('admin_assets/js/jquery-1.11.1.min.js');?>"></script>
<script src="<?=base_url('admin_assets/js/modernizr.custom.js');?>"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<?=link_tag("admin_assets/css/animate.css");?>
<script src="<?=base_url('admin_assets/js/wow.min.js');?>"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="<?=base_url('admin_assets/js/metisMenu.min.js');?>"></script>
<script src="<?=base_url('admin_assets/js/custom.js');?>"></script>
<?=link_tag('admin_assets/css/custom.css');?>