<!DOCTYPE HTML>
<html>
<head>
    <title>Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Admin" />
    <?php include_once('includes/alljscss.php'); ?>
    <!--//Metis Menu -->
</head>

<body class="cbp-spmenu-push">
    <div class="main-content">
        <!--left-fixed -navigation-->
        <?php include_once('includes/navigation.php'); ?>
        <!--left-fixed -navigation-->
        <!-- header-starts -->
        <?php include_once('includes/adminheader.php'); ?>
        <!-- //header-ends -->
        <!-- main content start-->
        <div id="page-wrapper">
            <?php if($msg=$this->session->flashdata('msg')): ?>
               <div class="alert alert-dismissible alert-danger">
                   <?=$msg;?>

               </div>
               <?php endif; ?>
            <div class="main-page">
                <div class="forms">
                    <div class=" form-grids row form-grids-right">
                        <div class="widget-shadow " data-example-id="basic-forms">
                            <div class="form-title">
                                <h4>Add Settings :</h4>
                            </div>
                            <div class="form-body">
                               <?php echo form_open('settings/update_settings',['class'=>'form-horizontal']); ?>                                
                                    <div class="form-group"> <label for="inputEmail3" class="col-sm-2 control-label">Company Name</label>
                                        <div class="col-sm-9"> 
                                        <?php
                                            $companyname=array(
                                                'name'=>'companyname',
                                                'class'=>'form-control',
                                                'placeholder'=>'Enter company name',
                                                'value'=>set_value('companyname',$result->companyname),
                                            );
                                            echo form_input($companyname); 
                                            echo form_hidden('id',$result->id);
                                            echo form_error('companyname','<p class="text-danger">', '</p>');
                                            ?>
                                            
                                        </div>
                                    </div>
                                   <div class="form-group"> <label for="inputEmail3" class="col-sm-2 control-label">Company Email</label>
                                        <div class="col-sm-9"> 
                                        <?php
                                            $companyemail=array(
                                                'name'=>'companyemail',
                                                'class'=>'form-control',
                                                'placeholder'=>'Enter company email',
                                                'value'=>set_value('companyemail',$result->email),
                                            );
                                            echo form_input($companyemail); 
                                            echo form_error('companyemail','<p class="text-danger">', '</p>');
                                            ?>
                                            
                                        </div>
                                    </div>
                                      <div class="form-group"> <label for="inputEmail3" class="col-sm-2 control-label">Company Phone</label>
                                        <div class="col-sm-9"> 
                                        <?php
                                            $companyphone=array(
                                                'name'=>'companyphone',
                                                'class'=>'form-control',
                                                'placeholder'=>'Enter company phone',
                                                'value'=>set_value('companyphone',$result->phone),
                                            );
                                            echo form_input($companyphone); 
                                            echo form_error('companyphone','<p class="text-danger">', '</p>');
                                            ?>
                                            
                                        </div>
                                    </div>
                                    <div class="form-group"> <label for="inputEmail3" class="col-sm-2 control-label">Company Address</label>
                                        <div class="col-sm-9"> 
                                        <?php
                                            $companyaddress=array(
                                                'name'=>'companyaddress',
                                                'class'=>'form-control',
                                                'placeholder'=>'Enter company address',
                                                'value'=>set_value('companyaddress',$result->address),
                                            );
                                            echo form_input($companyaddress); 
                                            echo form_error('companyaddress','<p class="text-danger">', '</p>');
                                            ?>
                                            
                                        </div>
                                    </div>
                                    <div class="col-sm-offset-2">
                                    <?php $submit=array(
                                                'class'=>'btn btn-primary',
                                                'value'=>'UPDATE SETTINGS',
                                                'name'=>'updatesettings'
                                    );
                                    echo form_submit($submit);
                                    ?>
                                     
                                    </div>
                                <?php echo form_close(); ?>
                              
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--footer-->
        <?php include_once('includes/footer.php'); ?>
        <!--//footer-->
    </div>
    <!-- Classie -->
    <?php include_once('includes/footerjs.php'); ?>
</body>

</html>
