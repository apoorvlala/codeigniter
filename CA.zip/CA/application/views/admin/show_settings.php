<!DOCTYPE HTML>
<html>
<?php include_once('includes/functions.php'); ?>
<head>
    <title>Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Admin" />
    <?php include_once('includes/alljscss.php'); ?>
    <!--//Metis Menu -->
</head>

<body class="cbp-spmenu-push">
    <div class="main-content">
        <!--left-fixed -navigation-->
        <?php include_once('includes/navigation.php'); ?>
        <!--left-fixed -navigation-->
        <!-- header-starts -->
        <?php include_once('includes/adminheader.php'); ?>
        <!-- //header-ends -->
        <!-- main content start-->
        <div id="page-wrapper">
           <?php if($msg=$this->session->flashdata('msg')): ?>
               <div class="alert alert-dismissible alert-danger">
                   <?=$msg;?>

               </div>
               <?php endif; ?>
            <div class="main-page">
                <div class="tables">
                    <div class="table-responsive bs-example widget-shadow">
                        <h4>Show Settings:</h4>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Company Name</th>
                                    <th>Company Email</th>
                                    <th>Company Phone</th>
                                    <th>Company Address</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php if(!empty($result)){ $i=0;
                                foreach($result as $data){
                                ?>
                                    <tr>
                                    <th scope="row"><?php echo ++$i; ?></th>
                                    <td><?=$data->companyname?></td>
                                    <td><?=shortLength($data->email,50,50).'..';?></td>
                                    <td><?=$data->phone;?></td>
                                    <td><?=shortLength($data->address,50,50).'..';?></td>
                                    <td>
                                        <?php echo anchor("Settings/loadUpdatesettings/{$data->id}", 'Update', ['class'=>'btn btn-primary btn-sm','target'=>'_blank']); ?>||
                                        <?php echo anchor("Blog/deleteBlog/{$data->id}", 'Delete', ['class'=>'btn btn-danger btn-sm']); ?>
                                    </td>
                                </tr>
                                <?php } } ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!--footer-->
        <?php include_once('includes/footer.php'); ?>
        <!--//footer-->
    </div>
    <!-- Classie -->
    <?php include_once('includes/footerjs.php'); ?>
</body>

</html>
