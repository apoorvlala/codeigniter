<?php
class Blog extends MY_Controller{

    public function __construct(){
        parent::__construct();
        if(!$this->session->userdata('user_id')){
            return redirect('Admin');
        }
        $this->load->model('Blogmodel');
    }
    public function index(){
        $this->load->view('admin/addblog');
    }
    public function addblog(){
        $config=[
            'upload_path'=>'./uploads',
            'allowed_types'=>'jpg|jpeg|png|gif'
        ];
        $this->load->library('upload',$config);

        $this->load->library('form_validation');
        if($this->form_validation->run('blog_validation') && $this->upload->do_upload()){

            $data=$this->upload->data();//echo '<pre>';print_r($data);exit;
            $image_path=base_url('uploads/'.$data['raw_name'].$data['file_ext']);

            $status=1;
            $metatitle=$this->input->post('metatitle');
            $metadescription=$this->input->post('metadescription');
            $metakeyword=$this->input->post('metakeyword');
            $blogheading=$this->input->post('blogheading');
            $description=$this->input->post('description');
            $date=date("Y/m/d");
            if($this->Blogmodel->addblog($metatitle , $metadescription , $metakeyword , $blogheading , $description , $image_path , $status,$date)){
                $this->session->set_flashdata('msg','Blog post added successfully...');
                return redirect('Blog');
            }else{
                $this->session->set_flashdata('msg','Blog post not added successfully...');
                return redirect('Blog');
            }

        }else{
            $upload_error=$this->upload->display_errors();
            $this->load->view('admin/addblog',compact('upload_error'));
        }
    }
    public function showBlogs(){
        $result=$this->Blogmodel->showBlogs();
        $this->load->view("admin/show_blogs",['result'=>$result]);
    }
    public function loadUpdateBlog($id){
        $result=$this->Blogmodel->showBlogs_Id($id);
        $this->load->view("admin/update_blogs",['result'=>$result]);
    }
    public function updateBlog(){
        $id=$this->input->post('id');
        $this->load->library('form_validation');
        if($this->form_validation->run('blog_validation')){

            $metatitle=$this->input->post('metatitle');
            $metadescription=$this->input->post('metadescription');
            $metakeyword=$this->input->post('metakeyword');
            $blogheading=$this->input->post('blogheading');
            $description=$this->input->post('description');
            if($this->Blogmodel->updateBlog($metatitle , $metadescription , $metakeyword , $blogheading , $description , $id)){
                $this->session->set_flashdata('msg',"Blog post updated successfully..");
                return redirect("Blog/loadUpdateBlog/{$id}");
            }else{
                $this->session->set_flashdata('msg',"Blog post not updated successfully..");
                return redirect("Blog/loadUpdateBlog/{$id}");
            }

        }else{
            $this->session->set_flashdata('msg','Fields must not be empty...');
            return redirect("Blog/loadUpdateBlog/{$id}");
        }
    }
    public function updateImage(){
        $config=[
            'upload_path'=>'./uploads',
            'allowed_types'=>'jpg|jpeg|png|gif'
        ];
        $id=$this->input->post('id');
        $this->load->library('upload',$config);
        if($this->upload->do_upload()){
            $data=$this->upload->data();//echo '<pre>';print_r($data);exit;
            $image_path=base_url('uploads/'.$data['raw_name'].$data['file_ext']);
            $result=$this->Blogmodel->showBlogs_Id($id);

            $pos=strripos($result->image,"/");
            $image_name=substr($result->image,++$pos);
            unlink("uploads/$image_name");

            if($this->Blogmodel->update_image($id ,$image_path)){
                $this->session->set_flashdata('msg','Image updated successfully...');
                return redirect("Blog/showBlogs");
            }

        }else{
            $upload_error=$this->upload->display_errors();
            $this->session->set_flashdata('msg',$upload_error);
            return redirect("Blog/showBlogs");
        }
    }
    public function deleteBlog($id){
            $result=$this->Blogmodel->showBlogs_Id($id);
            $pos=strripos($result->image,"/");
            $image_name=substr($result->image,++$pos);
            unlink("uploads/$image_name");
            if($this->Blogmodel->deleteBlog($id)){
                $this->session->set_flashdata('msg','Deleted blog post successfully..');
                return redirect("Blog/showBlogs");
            }
    }
}

?>
