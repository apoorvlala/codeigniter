<?php
class SubCategory extends MY_Controller{

    public function __construct(){
        parent::__construct();
        if(!$this->session->userdata('user_id')){
            return redirect('Admin');
        }
        $this->load->model('adminmodel');
    }
    public function index(){
        $allMainCat=$this->adminmodel->show_category();
        $this->load->view('admin/addsubcat',['allMainCat'=>$allMainCat]);
    }
    /*----------------Add Submenu-------------------------*/
    public function addSubCat(){
        $this->load->library('form_validation');
        if($this->form_validation->run('sub_cat_rules')){

            $status=1;
            $mainCat=$this->input->post('sel_cat');
            $subcat=$this->input->post('category');

            $url=$this->input->post('url');
            $url = strtolower($url);
            $url = preg_replace("/[^a-z0-9_\s-]/", "", $url);
            $url = preg_replace("/[\s-]+/", " ", $url);
            $url = preg_replace("/[\s_]/", "-", $url);

            if($this->adminmodel->add_sub_category($subcat , $mainCat , $url , $status)){
                $this->session->set_flashdata('msg','Submenu added successfully...');
                $allMainCat=$this->adminmodel->show_category();
                $this->load->view('admin/addsubcat',['allMainCat'=>$allMainCat]);
            }

        }else{
            $allMainCat=$this->adminmodel->show_category();
            $this->load->view('admin/addsubcat',['allMainCat'=>$allMainCat]);
        }
    }
    /*----------------End Add Submenu-------------------------*/
    /*----------------Show Submenu-------------------------*/
    public function showSubMenu(){

        $result=$this->adminmodel->show_submenu_with_main_menu();
        $this->load->view('admin/show_sub_cat',['result'=>$result]);
    }

    public function loadUpdateSubCat($id){
        $result=$this->adminmodel->show_subcategory_by_id($id);
        $this->load->view('admin/update_sub_cat',['result'=>$result]);
    }

    public function updateSubCat(){
        $id=$this->input->post('id');
        $this->load->library('form_validation');
        if($this->form_validation->run('sub_cat_rules')){
            $category=$this->input->post('category');
            $url=$this->input->post('url');
            $url = strtolower($url);
            $url = preg_replace("/[^a-z0-9_\s-]/", "", $url);
            $url = preg_replace("/[\s-]+/", " ", $url);
            $url = preg_replace("/[\s_]/", "-", $url);
            if($this->adminmodel->updateSubmenu($category , $url , $id)){
                $this->session->set_flashdata('msg','Submenu updated successfully..');
                return redirect("SubCategory/loadUpdateSubCat/{$id}");
            }

        }else{
            $this->session->set_flashdata('msg','Fields must not be empty...');
            return redirect("SubCategory/loadUpdateSubCat/{$id}");
        }
    }

    public function deleteSubCat($id){
        if($this->adminmodel->deletesubCategory($id)){
            $this->session->set_flashdata('msg','Sub menu deleted successfully...');
            return redirect('SubCategory/showSubMenu');
        }else{
            $this->session->set_flashdata('msg','Sub menu not deleted..');
                return redirect('SubCategory/showSubMenu');
        }
    }
}


?>
