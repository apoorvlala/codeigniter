<?php
class DetailPage extends MY_Controller{
    
    public function __construct(){
        parent::__construct();
        if(!$this->session->userdata('user_id')){
            return redirect('Admin');
        }
        $this->load->model('DetailPagemodel');
    }
    
    public function index(){
        $this->load->view('admin/add_detailpage');        
    }
    public function addDetailPage(){
           $config=[
            'upload_path'=>'./uploads',
            'allowed_types'=>'jpg|jpeg|png|gif'
            ];
            $this->load->library('upload',$config);
        
        $this->load->library('form_validation');
        if($this->form_validation->run('detail_page_validation')  && $this->upload->do_upload() ){
                                    
            $status=1;
            $metatitle=$this->input->post('metatitle');
            $metadescription=$this->input->post('metadescription');
            $metakeyword=$this->input->post('metakeyword');
            $small_heading=$this->input->post('small_heading');
            $small_description=$this->input->post('small_description');
            $main_heading=$this->input->post('main_heading');
            $main_description=$this->input->post('main_description');
            $url=$this->input->post('url');
            $url = strtolower($url);
            $url = preg_replace("/[^a-z0-9_\s-]/", "", $url);
            $url = preg_replace("/[\s-]+/", " ", $url);
            $url = preg_replace("/[\s_]/", "-", $url);
            $doc1=$this->input->post('doc1');
            $doc2=$this->input->post('doc2');
            $doc3=$this->input->post('doc3');
            $doc4=$this->input->post('doc4');
            
            $data=$this->upload->data();//echo '<pre>';print_r($data);exit;
            $image_path=base_url('uploads/'.$data['raw_name'].$data['file_ext']);
            
            if($this->DetailPagemodel->add_detail_page($metatitle , $metadescription , $metakeyword , $small_heading , $small_description , $main_heading , $main_description , $url , $doc1 , $doc2 , $doc3 , $doc4 , $status , $image_path)){
                $this->session->set_flashdata('msg','Detail Page Data Added Successfully..');
                return redirect('DetailPage');
            }else{
                $this->session->set_flashdata('msg','Detail Page Data Not Added Successfully..');
                return redirect('DetailPage');
            }
            
        }else{
            $upload_error=$this->upload->display_errors();
            $this->load->view('admin/add_detailpage',compact('upload_error'));
        }
    }
    public function showDetailPages(){
        $result=$this->DetailPagemodel->showDetailPages();
            $this->load->view("admin/show_detail_page_data",['result'=>$result]);
        
    }
    public function loadUpdateDetailPage($id){
        $result=$this->DetailPagemodel->showDetailPagesById($id);
        $this->load->view("admin/update_detail_page",['result'=>$result]);
    }
    public function updateDetailPage(){
        $id=$this->input->post('id');
        $this->load->library('form_validation');
        if($this->form_validation->run('detail_page_validation')){
            
            $metatitle=$this->input->post('metatitle');
            $metadescription=$this->input->post('metadescription');
            $metakeyword=$this->input->post('metakeyword');
            $small_heading=$this->input->post('small_heading');
            $small_description=$this->input->post('small_description');
            $main_heading=$this->input->post('main_heading');
            $main_description=$this->input->post('main_description');
            $url=$this->input->post('url');
            $url = strtolower($url);
            $url = preg_replace("/[^a-z0-9_\s-]/", "", $url);
            $url = preg_replace("/[\s-]+/", " ", $url);
            $url = preg_replace("/[\s_]/", "-", $url);
            $doc1=$this->input->post('doc1');
            $doc2=$this->input->post('doc2');
            $doc3=$this->input->post('doc3');
            $doc4=$this->input->post('doc4');
            if($this->DetailPagemodel->updateDetailPage($metatitle , $metadescription , $metakeyword , $small_heading , $small_description , $main_heading , $main_description , $url , $doc1 , $doc2 , $doc3 , $doc4 ,$id)){
                $this->session->set_flashdata('msg','Details Updated Successfully');
                return redirect("DetailPage/loadUpdateDetailPage/{$id}");
            }
        }else{
            $this->session->set_flashdata('msg','Fields must not be empty..');
            return redirect("DetailPage/loadUpdateDetailPage/{$id}");
        }
    }
    public function updateImage(){
        $config=[
            'upload_path'=>'./uploads',
            'allowed_types'=>'jpg|jpeg|png|gif'
        ];
        $id=$this->input->post('id');
        $this->load->library('upload',$config);
        if($this->upload->do_upload()){
            $data=$this->upload->data();//echo '<pre>';print_r($data);exit;
            $image_path=base_url('uploads/'.$data['raw_name'].$data['file_ext']);
            $result=$this->DetailPagemodel->getImageById($id);

            $pos=strripos($result->image,"/");
            $image_name=substr($result->image,++$pos);
            unlink("uploads/$image_name");

            if($this->DetailPagemodel->update_image($id ,$image_path)){
                $this->session->set_flashdata('msg','Image updated successfully...');
                return redirect("DetailPage/showDetailPages");
            }

        }else{
            $upload_error=$this->upload->display_errors();
            $this->session->set_flashdata('msg',$upload_error);
            return redirect("DetailPage/showDetailPages");
        }

    }
      public function deleteDetailPage($id){
            $result=$this->DetailPagemodel->getImageById($id);
            $pos=strripos($result->image,"/");
            $image_name=substr($result->image,++$pos);
            unlink("uploads/$image_name");
            if($this->DetailPagemodel->deleteDetailsPage($id)){
                $this->session->set_flashdata('msg','Deleted details page successfully..');
                return redirect("DetailPage/showDetailPages");
            }
    }
}

?>