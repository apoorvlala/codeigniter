<?php

class Testimonial extends MY_Controller{

    public function __construct(){
        parent::__construct();
        if(!$this->session->userdata('user_id')){
            return redirect('Admin');
        }
        $this->load->model('testimonialmodel');
    }
    public function index(){
        $this->load->view("admin/addtestimonial");
    }
    public function addtestimonial(){

        $this->load->library('form_validation');
        $config=[
            'upload_path'=>'./uploads',
            'allowed_types'=>'jpg|jpeg|png|gif'
        ];
        $this->load->library('upload',$config);
        if($this->form_validation->run('testimonial_validation') && $this->upload->do_upload()){
            $status=1;
            $description=$this->input->post('description');
            $data=$this->upload->data();//echo '<pre>';print_r($data);exit;
            $image_path=base_url('uploads/'.$data['raw_name'].$data['file_ext']);

            if($this->testimonialmodel->addTestimonial($description , $image_path , $status)){
                $this->session->set_flashdata('msg','Testimonial added successfully');
                return redirect('Testimonial/addtestimonial');
            }else{
                $this->session->set_flashdata('msg','Testimonial not added successfully');
                return redirect('Testimonial/addtestimonial');
            }
        }else{
            $upload_error=$this->upload->display_errors();
            $this->load->view('admin/addtestimonial',compact('upload_error'));
        }
    }
    public function showTestimonials(){
        $result=$this->testimonialmodel->showTestimonials();
        $this->load->view("admin/showtestimonial",['result'=>$result]);
    }
    public function loadUpdateTestimonial($id){
        $result=$this->testimonialmodel->showTestimonialById($id);
        $this->load->view("admin/updatetestimonial",['result'=>$result]);

    }
    public function updateTestimonial(){
        $id=$this->input->post('id');
        $description=$this->input->post('description');
        $this->load->library('form_validation');
        if($this->form_validation->run('testimonial_validation')){
            if($this->testimonialmodel->updateTestimonial($description , $id)){
                $this->session->set_flashdata('msg','Testimonials updated successfully...');
                return redirect("Testimonial/loadUpdateTestimonial/{$id}");
            }
        }else{
            $this->session->set_flashdata('msg','Feilds must not be empty');
            return redirect("Testimonial/loadUpdateTestimonial/{$id}");
        }
    }
    public function updateImage(){
        $config=[
            'upload_path'=>'./uploads',
            'allowed_types'=>'jpg|jpeg|png|gif'
        ];
        $id=$this->input->post('id');
        $this->load->library('upload',$config);
        if($this->upload->do_upload()){
            $data=$this->upload->data();//echo '<pre>';print_r($data);exit;
            $image_path=base_url('uploads/'.$data['raw_name'].$data['file_ext']);
            $result=$this->testimonialmodel->getImageById($id);

            $pos=strripos($result->image,"/");
            $image_name=substr($result->image,++$pos);
            unlink("uploads/$image_name");

            if($this->testimonialmodel->update_image($id ,$image_path)){
                $this->session->set_flashdata('msg','Image updated successfully...');
                return redirect("Testimonial/showTestimonials");
            }

        }else{
            $upload_error=$this->upload->display_errors();
            $this->session->set_flashdata('msg',$upload_error);
            return redirect("Testimonial/showTestimonials");
        }
    }
    public function deleteTestimonial($id){
            $result=$this->testimonialmodel->getImageById($id);
            $pos=strripos($result->image,"/");//finding starting postinion of image
            $image_name=substr($result->image,++$pos);//getting name of the image, increment postion by one to avoid '/'
            unlink("uploads/$image_name");
            if($this->testimonialmodel->deleteTestimonial($id)){
                $this->session->set_flashdata('msg','Deleted testimonial successfully..');
                return redirect("Testimonial/showTestimonials");
            }
    }
}

?>
