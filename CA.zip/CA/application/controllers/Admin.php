<?php

class Admin extends MY_Controller{

    public function __construct(){
        parent::__construct();
        $this->load->model('adminmodel');
    }

    public function index(){
        $this->load->view('admin/login');
    }

    /*-------------login starts----------------------*/
    public function login(){
        $username=$this->input->post('username');
        $password=$this->input->post('password');

        $this->load->library('form_validation');
        if($this->form_validation->run('login_form_rules')){

            $user_id=$this->adminmodel->login_valid($username , $password);
            if($user_id){
                $this->session->set_userdata('user_id',$user_id);
                $this->session->set_flashdata('msg','You are logged in now..');
                return redirect('admin/dashboard');
            }else{
                $msg="Invalid Username/Password.";
                $this->load->view('admin/login',['msg'=>$msg]);
            }

        }else{
            $this->load->view('admin/login');
        }
    }

    /*-------------load dashboard----------------------*/
    public function dashboard(){
        if(!$this->session->userdata('user_id')){
            return redirect('Admin');
        }
        $this->load->view('admin/dashboard');
    }

    /*-------------logout----------------------*/
    public function logout(){
        $this->session->unset_userdata('user_id');
        return redirect('admin');
    }

    /*-------------load category view----------------------*/
    public function load_category(){
        if(!$this->session->userdata('user_id')){
            return redirect('Admin');
        }
        $this->load->view('admin/addcategory');
    }
    /*-------------add category----------------------*/
    public function add_category(){
        if(!$this->session->userdata('user_id')){
            return redirect('Admin');
        }
        $this->load->library('form_validation');
        if($this->form_validation->run('category_rules')){

            $status=1;
            $category=$this->input->post('category');
            $url=$this->input->post('url');
            $url = strtolower($url);
            $url = preg_replace("/[^a-z0-9_\s-]/", "", $url);
            $url = preg_replace("/[\s-]+/", " ", $url);
            $url = preg_replace("/[\s_]/", "-", $url);

            if($this->adminmodel->add_category($category , $url , $status)){
                $this->session->set_flashdata('msg','Category/Main Menu added successfully...');
                return redirect('admin/load_category');
            }else{
                $this->session->set_flashdata('msg','Problem creating category...');
            }

        }else{
            $this->load->view('admin/addcategory');
        }
    }
    /*-------------Show category/main menus----------------------*/
    public function show_category(){
        if(!$this->session->userdata('user_id')){
            return redirect('Admin');
        }
        $result=$this->adminmodel->show_category();
        $this->load->view('admin/show_main_cat',['result'=>$result]);
    }
    /*-------------load Update category page----------------------*/
    public function loadUpdateCat($id)
    {
        if(!$this->session->userdata('user_id')){
            return redirect('Admin');
        }
        $result=$this->adminmodel->show_category_by_id($id);
        $this->load->view('admin/update_main_cat.php',['result'=>$result]);
    }
    /*-------------Update category page----------------------*/
    public function updateCat(){
        if(!$this->session->userdata('user_id')){
            return redirect('Admin');
        }
        $id=$this->input->post('id');
        $category=$this->input->post('category');
        $url=$this->input->post('url');
        $url = strtolower($url);
        $url = preg_replace("/[^a-z0-9_\s-]/", "", $url);
        $url = preg_replace("/[\s-]+/", " ", $url);
        $url = preg_replace("/[\s_]/", "-", $url);

        $this->load->library('form_validation');
        if($this->form_validation->run('category_rules')){
            if($this->adminmodel->update_category($id , $category , $url)){
                $this->session->set_flashdata('msg','Menu updated successfully...');
                return redirect("admin/loadUpdateCat/{$id}");
            }
        }else{
            $this->session->set_flashdata('msg','Fields must not be empty...');
           return redirect("admin/loadUpdateCat/{$id}");
        }
    }
    /*-------------Delete main category----------------------*/
    public function deleteMainCategory($id){
        if(!$this->session->userdata('user_id')){
            return redirect('Admin');
        }
        if($this->adminmodel->deleteMainCategory($id)){
            $this->session->set_flashdata('msg','Menu deleted successfully...');
                return redirect("admin/show_category");
        }
    }

}
