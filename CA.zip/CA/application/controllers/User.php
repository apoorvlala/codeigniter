<?php
class User extends MY_Controller{
    public function __construct(){
        parent::__construct();
        $this->load->model('adminmodel');
        $this->load->model('servicemodel');
        $this->load->model('Testimonialmodel');
        $this->load->model('ClientLogomodel');
        $this->load->model('Settingsmodel');
        $this->load->model('Blogmodel');
        $this->load->model('Aboutmodel');
    }

    public function index(){

        $result=$this->adminmodel->show_category();
        $submenu=$this->adminmodel->show_subcategory();
        $sub_sub_menu=$this->adminmodel->show_sub_sub_cat();
        
        $service=$this->servicemodel->showServices();//echo '<pre>';print_r($service);exit;
        $testimonial=$this->Testimonialmodel->showTestimonials();
        $clientlogo=$this->ClientLogomodel->show_client_logo();
        
        $settings=$this->Settingsmodel->show_latest_settings();
        
        $blog_posts=$this->Blogmodel->getBlogPostForView();
        
        $this->load->view('public/home',['result'=>$result,'submenu'=>$submenu , 'sub_sub_menu'=>$sub_sub_menu , 'service'=>$service ,'testimonial'=>$testimonial,'clientlogo'=>$clientlogo , 'settings'=>$settings , 'blog_posts'=>$blog_posts]);

    }
    public function home(){
        $result=$this->adminmodel->show_category();
        $submenu=$this->adminmodel->show_subcategory();
        $sub_sub_menu=$this->adminmodel->show_sub_sub_cat();
        
        $service=$this->servicemodel->showServices();//echo '<pre>';print_r($service);exit;
        $testimonial=$this->Testimonialmodel->showTestimonials();
        $clientlogo=$this->ClientLogomodel->show_client_logo();
        
        $settings=$this->Settingsmodel->show_latest_settings();
        
        $blog_posts=$this->Blogmodel->getBlogPostForView();
        
        $this->load->view('public/home',['result'=>$result,'submenu'=>$submenu , 'sub_sub_menu'=>$sub_sub_menu , 'service'=>$service,'testimonial'=>$testimonial ,'clientlogo'=>$clientlogo , 'settings'=>$settings ,'blog_posts'=>$blog_posts]);
    }
    public function detail(){

        $result=$this->adminmodel->show_category();
        $submenu=$this->adminmodel->show_subcategory();
        $sub_sub_menu=$this->adminmodel->show_sub_sub_cat();
        
        $this->load->model('DetailPagemodel');
        $urlsegment=$this->uri->segment(2);
        $detailPageData=$this->DetailPagemodel->getDetailPageData($urlsegment);//print_r($detailPageData);exit;
        if(empty($detailPageData)){
            return redirect("user/pageNotFound");
        }
        $getServiceNames=$this->DetailPagemodel->getAllServicesNames();
        $testimonial=$this->Testimonialmodel->showTestimonials();
        $clientlogo=$this->ClientLogomodel->show_client_logo();
        
        $settings=$this->Settingsmodel->show_latest_settings();
        
        $this->load->view('public/detailpage.php',['result'=>$result,'submenu'=>$submenu , 'sub_sub_menu'=>$sub_sub_menu , 'detailPageData'=>$detailPageData , 'getServiceNames'=>$getServiceNames,'testimonial'=>$testimonial , 'clientlogo'=>$clientlogo,'settings'=>$settings]);

    }
    public function pageNotFound(){
        $this->load->view("public/pagenotfound");
    }
    
    public function blogPage(){
        $result=$this->adminmodel->show_category();
        $submenu=$this->adminmodel->show_subcategory();
        $sub_sub_menu=$this->adminmodel->show_sub_sub_cat();
        $settings=$this->Settingsmodel->show_latest_settings();
        $blog=$this->Blogmodel->showBlogs();
        
        $testimonial=$this->Testimonialmodel->showTestimonials();
        $clientlogo=$this->ClientLogomodel->show_client_logo();
        
        $this->load->view("public/blogpage",['result'=>$result,'submenu'=>$submenu , 'sub_sub_menu'=>$sub_sub_menu,'settings'=>$settings , 'blog'=>$blog , 'testimonial'=>$testimonial , 'clientlogo'=>$clientlogo]);
    }
    public function about(){
        $result=$this->adminmodel->show_category();
        $submenu=$this->adminmodel->show_subcategory();
        $sub_sub_menu=$this->adminmodel->show_sub_sub_cat();
        $settings=$this->Settingsmodel->show_latest_settings();        
        
        $testimonial=$this->Testimonialmodel->showTestimonials();
        $clientlogo=$this->ClientLogomodel->show_client_logo();
        $about=$this->Aboutmodel->get_about_content_view();
        
        $this->load->view("public/about",['result'=>$result,'submenu'=>$submenu , 'sub_sub_menu'=>$sub_sub_menu,'settings'=>$settings ,'testimonial'=>$testimonial , 'clientlogo'=>$clientlogo , 'about'=>$about]);
    }
    public function blogdetailPage($id){
        $result=$this->adminmodel->show_category();
        $submenu=$this->adminmodel->show_subcategory();
        $sub_sub_menu=$this->adminmodel->show_sub_sub_cat();
        $settings=$this->Settingsmodel->show_latest_settings();
        $blog=$this->Blogmodel->showBlogs_Id($id);
        
        $testimonial=$this->Testimonialmodel->showTestimonials();
        $clientlogo=$this->ClientLogomodel->show_client_logo();
        
        $this->load->view("public/blogdetailpage",['result'=>$result,'submenu'=>$submenu , 'sub_sub_menu'=>$sub_sub_menu,'settings'=>$settings , 'blog'=>$blog , 'testimonial'=>$testimonial , 'clientlogo'=>$clientlogo]);
    }
    public function contact(){
        $result=$this->adminmodel->show_category();
        $submenu=$this->adminmodel->show_subcategory();
        $sub_sub_menu=$this->adminmodel->show_sub_sub_cat();
        $settings=$this->Settingsmodel->show_latest_settings();
        $blog=$this->Blogmodel->showBlogs();
        
        $testimonial=$this->Testimonialmodel->showTestimonials();
        $clientlogo=$this->ClientLogomodel->show_client_logo();
        
        $this->load->view("public/contact",['result'=>$result,'submenu'=>$submenu , 'sub_sub_menu'=>$sub_sub_menu,'settings'=>$settings , 'blog'=>$blog , 'testimonial'=>$testimonial , 'clientlogo'=>$clientlogo]);
    }
    
    
}
