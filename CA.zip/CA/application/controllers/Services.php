<?php
class Services extends MY_Controller{

    public function __construct(){
        parent::__construct();
        if(!$this->session->userdata('user_id')){
            return redirect('Admin');
        }
        $this->load->model('servicemodel');
    }
    public function index(){
        $this->load->view('admin/addservices');
    }
    public function addServices(){

        $config=[
            'upload_path'=>'./uploads',
            'allowed_types'=>'jpg|jpeg|png|gif'
        ];
        $this->load->library('upload',$config);

        $this->load->library('form_validation');
        if($this->form_validation->run('service_validation') && $this->upload->do_upload()){

            $url=$this->input->post('url');
            $url = strtolower($url);
            $url = preg_replace("/[^a-z0-9_\s-]/", "", $url);
            $url = preg_replace("/[\s-]+/", " ", $url);
            $url = preg_replace("/[\s_]/", "-", $url);

            $metatitle=$this->input->post('metatitle');
            $metadescription=$this->input->post('metadescription');
            $metakeyword=$this->input->post('metakeyword');
            $service=$this->input->post('service');
            $description=$this->input->post('description');
            $status=1;
            $data=$this->upload->data();//echo '<pre>';print_r($data);exit;
            $image_path=base_url('uploads/'.$data['raw_name'].$data['file_ext']);
            if($this->servicemodel->addService($service ,$description,$image_path , $status,$metatitle,$metadescription,$metakeyword,$url )){
                $this->session->set_flashdata('msg','Service added successfully...');
                return redirect('Services');
            }else{
                $this->session->set_flashdata('msg','Service not added...');
                return redirect('Services');
            }

        }else{
            $upload_error=$this->upload->display_errors();
            $this->load->view('admin/addservices',compact('upload_error'));
        }
    }
    public function showService(){
        $result=$this->servicemodel->showServices();
        $this->load->view('admin/show_all_services',['result'=>$result]);
    }
    public function loadUpdateService($id){
        $result=$this->servicemodel->showServices_by_Id($id);
        $this->load->view('admin/updateservices',['result'=>$result]);
    }
    public function updateService(){

$id=$this->input->post('id');
        $this->load->library('form_validation');
        if($this->form_validation->run('service_validation')){

            $url=$this->input->post('url');
            $url = strtolower($url);
            $url = preg_replace("/[^a-z0-9_\s-]/", "", $url);
            $url = preg_replace("/[\s-]+/", " ", $url);
            $url = preg_replace("/[\s_]/", "-", $url);

            $metatitle=$this->input->post('metatitle');
            $metadescription=$this->input->post('metadescription');
            $metakeyword=$this->input->post('metakeyword');
            $service=$this->input->post('service');
            $description=$this->input->post('description');
            $status=1;
            //$data=$this->upload->data();//echo '<pre>';print_r($data);exit;
            //$image_path=base_url('uploads/'.$data['raw_name'].$data['file_ext']);
            if($this->servicemodel->update_services($service ,$description, $metatitle , $metadescription ,$metakeyword,$url , $id)){
                $this->session->set_flashdata('msg','Service updated successfully...');
                return redirect("Services/loadUpdateService/{$id}");
            }else{
                $this->session->set_flashdata('msg','Service not updated...');
                return redirect('Services');
            }

        }else{
                $this->session->set_flashdata('msg','Fields must not be empty');
                return redirect("Services/loadUpdateService/{$id}");
            }
    }

    public function updateImage(){
        $config=[
            'upload_path'=>'./uploads',
            'allowed_types'=>'jpg|jpeg|png|gif'
        ];
        $id=$this->input->post('id');
        $this->load->library('upload',$config);
        if($this->upload->do_upload()){
            $data=$this->upload->data();//echo '<pre>';print_r($data);exit;
            $image_path=base_url('uploads/'.$data['raw_name'].$data['file_ext']);
            $result=$this->servicemodel->getImageById($id);

            $pos=strripos($result->image,"/");
            $image_name=substr($result->image,++$pos);
            unlink("uploads/$image_name");

            if($this->servicemodel->update_image($id ,$image_path)){
                $this->session->set_flashdata('msg','Image updated successfully...');
                return redirect("Services/showService");
            }

        }else{
            $upload_error=$this->upload->display_errors();
            $this->session->set_flashdata('msg',$upload_error);
            return redirect("Services/showService");
        }

    }
    public function deleteServices($id){
            $result=$this->servicemodel->getImageById($id);
            $pos=strripos($result->image,"/");
            $image_name=substr($result->image,++$pos);
            unlink("uploads/$image_name");
            if($this->servicemodel->deleteService($id)){
                $this->session->set_flashdata('msg','Deleted services successfully..');
                return redirect("Services/showService");
            }
    }
}

?>
