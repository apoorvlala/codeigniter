<?php
class Settings extends MY_Controller{
    
    public function __construct(){
        parent::__construct();
        if(!$this->session->userdata('user_id')){
            return redirect('Admin');
        }
        $this->load->model("settingsmodel");
    }
    public function index(){
        $this->load->view("admin/addsettings");
    }
    public function add_settings(){
        $this->load->library('form_validation');
        if($this->form_validation->run('settings_validation')){
            $companyname=$this->input->post('companyname');
            $companyemail=$this->input->post('companyemail');
            $companyphone=$this->input->post('companyphone');
            $companyaddress=$this->input->post('companyaddress');
            
            if($this->settingsmodel->addSettings($companyname , $companyemail , $companyphone , $companyaddress)){
                $this->session->set_flashdata('msg','Settings added successfully..');
                return redirect('settings');
            }
        }else{
            $this->load->view("admin/addsettings");
        }
    }
    public function show_settings(){
        $result=$this->settingsmodel->show_settings();
        $this->load->view('admin/show_settings',['result'=>$result]);
    }
    public function loadUpdatesettings($id){
        $result=$this->settingsmodel->show_settings_by_id($id);
        $this->load->view('admin/update_settings',['result'=>$result]);
    }
    public function update_settings(){
        $id=$this->input->post('id');
        $this->load->library('form_validation');
        if($this->form_validation->run('settings_validation')){
            $companyname=$this->input->post('companyname');
            $companyemail=$this->input->post('companyemail');
            $companyphone=$this->input->post('companyphone');
            $companyaddress=$this->input->post('companyaddress');
            
            if($this->settingsmodel->updateSettings($companyname , $companyemail , $companyphone , $companyaddress , $id)){
                $this->session->set_flashdata('msg','Settings added successfully..');
                return redirect("settings/loadUpdatesettings/{$id}");
            }
            
        }else{
            $this->session->set_flashdata('msg','Fields must contain validated value and must not be empty');
            return redirect("settings/loadUpdatesettings/{$id}");
        }
        
    }
}

?>