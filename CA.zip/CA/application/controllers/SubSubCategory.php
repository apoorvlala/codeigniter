<?php

class SubSubCategory extends MY_Controller{

    public function __construct(){
        parent::__construct();
        if(!$this->session->userdata('user_id')){
            return redirect('Admin');
        }
        $this->load->model('adminmodel');
    }

    public function index(){
        $allSubCat=$this->adminmodel->show_subcategory();
        $this->load->view('admin/add_sub_sub_cat',['allSubCat'=>$allSubCat]);
    }
    public function addSubSubCat(){
        $this->load->library('form_validation');
        if($this->form_validation->run('sub_sub_cat_rules')){
            $status=1;
            $sub_cat_id=$this->input->post('sel_cat');
            $subsub_cat=$this->input->post('category');
            $url=$this->input->post('url');
            $url = strtolower($url);
            $url = preg_replace("/[^a-z0-9_\s-]/", "", $url);
            $url = preg_replace("/[\s-]+/", " ", $url);
            $url = preg_replace("/[\s_]/", "-", $url);
            if($this->adminmodel->insert_sub_sub_menu($subsub_cat ,$sub_cat_id,$url,$status)){
                $this->session->set_flashdata('msg','Sub sub menu added successfully');
                return redirect('SubSubCategory');
            }

        }else{
            $allSubCat=$this->adminmodel->show_subcategory();
            $this->load->view('admin/add_sub_sub_cat',['allSubCat'=>$allSubCat]);
        }
    }
    public function showSubSubMenu(){
        $result=$this->adminmodel->show_sub_sub_cat();
        $this->load->view('admin/show_sub_sub_cat',['result'=>$result]);
    }
    public function loadUpdateSubSubCat($id){
        $result=$this->adminmodel->show_sub_sub_cat_by_id($id);
        $this->load->view('admin/update_sub_sub_cat',['result'=>$result]);
    }
    public function updateSubSubCat(){
        $id=$this->input->post('id');
        $this->load->library('form_validation');
        if($this->form_validation->run('sub_sub_cat_rules')){
            $subsub_cat=$this->input->post('category');
            $url=$this->input->post('url');
            $url = strtolower($url);
            $url = preg_replace("/[^a-z0-9_\s-]/", "", $url);
            $url = preg_replace("/[\s-]+/", " ", $url);
            $url = preg_replace("/[\s_]/", "-", $url);
            if($this->adminmodel->updateSubSubCategory($subsub_cat , $url , $id)){
                $this->session->set_flashdata('msg','Subsub menu updated successfully...');
                return redirect("SubSubCategory/loadUpdateSubSubCat/{$id}");
            }

        }else{
            $this->session->set_flashdata('msg','Fields must not be empty');
            return redirect("SubSubCategory/loadUpdateSubSubCat/{$id}");
        }
    }
    public function deleteSubsubCategory($id){
        if($this->adminmodel->deleteSubSubCat($id)){
            $this->session->set_flashdata('msg','Subsub category deleted succesfully..');
            return redirect("SubSubCategory/showSubSubMenu");
        }else{
            $this->session->set_flashdata('msg','Subsub category not deleted succesfully..');
            return redirect("SubSubCategory/showSubSubMenu");
        }

    }
}

?>
