<?php
class About extends MY_Controller{
    
    public function __construct(){
        parent::__construct();
        if(!$this->session->userdata('user_id')){
            return redirect('Admin');
        }
        $this->load->model('Aboutmodel');
    }
    public function index(){
        $this->load->view("admin/add_about");
    }
    public function add_about(){
        $this->load->library('form_validation');
        if($this->form_validation->run('about_validation')){
            
            $description=$this->input->post('description');
            if($this->Aboutmodel->add_about($description)){
                $this->session->set_flashdata('msg','Content Added Succesfully..');
                return redirect('About');
            }
            
        }else{
            $this->load->view("admin/add_about");
        }
    }
    public function show_about(){
        $result=$this->Aboutmodel->show_about();
        $this->load->view("admin/show_about",['result'=>$result]);
    }
    public function loadAbout($id){
        $result=$this->Aboutmodel->show_about_by_id($id);
        $this->load->view("admin/updateAbout",['result'=>$result]);
    }
    public function update_about(){
        $id=$this->input->post('id');
        $this->load->library('form_validation');
        if($this->form_validation->run('about_validation')){
            $description=$this->input->post('description');             
            if($this->Aboutmodel->update_about($id , $description)){
                $this->session->set_flashdata('msg','Content Updated successfully');
                return redirect("About/loadAbout/{$id}");
            }
        }else{
            $this->session->set_flashdata('msg','Filed must not empty..');
            return redirect("About/loadAbout/{$id}");
        }
        
    }
}

?>