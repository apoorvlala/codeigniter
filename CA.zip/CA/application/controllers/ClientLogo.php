<?php

class ClientLogo extends MY_Controller{

    public function __construct(){
        parent::__construct();
        if(!$this->session->userdata('user_id')){
            return redirect('Admin');
        }
        $this->load->model('ClientLogomodel');
    }
    public function index(){
        $this->load->view('admin/addclientlslogo');
    }
    public function add_client_logo(){
        $config=[
            'upload_path'=>'./uploads',
            'allowed_types'=>'jpg|jpeg|png|gif'
        ];
        $this->load->library('upload',$config);
        if($this->upload->do_upload()){
            $data=$this->upload->data();//echo '<pre>';print_r($data);exit;
            $image_path=base_url('uploads/'.$data['raw_name'].$data['file_ext']);

            if($this->ClientLogomodel->add_clients_logo($image_path)){
                $this->session->set_flashdata('msg','Image added successfully...');
                return redirect("ClientLogo");
            }

        }else{
            $upload_error=$this->upload->display_errors();
            $this->load->view('admin/addclientlslogo',['upload_error'=>$upload_error]);
        }
    }
    public function show_client_logo(){
        $result=$this->ClientLogomodel->show_client_logo();
        $this->load->view("admin/show_clients_logo",['result'=>$result]);
    }
    public function updateImage(){

        $config=[
            'upload_path'=>'./uploads',
            'allowed_types'=>'jpg|jpeg|png|gif'
        ];
        $id=$this->input->post('id');
        $this->load->library('upload',$config);
        if($this->upload->do_upload()){
            $data=$this->upload->data();//echo '<pre>';print_r($data);exit;
            $image_path=base_url('uploads/'.$data['raw_name'].$data['file_ext']);
            $result=$this->ClientLogomodel->get_client_logo_by_id($id);

            $pos=strripos($result->image,"/");
            $image_name=substr($result->image,++$pos);
            unlink("uploads/$image_name");

            if($this->ClientLogomodel->update_image($id ,$image_path)){
                $this->session->set_flashdata('msg','Logo updated successfully...');
                return redirect("ClientLogo/show_client_logo");
            }

        }else{
            $upload_error=$this->upload->display_errors();
            $this->session->set_flashdata('msg',$upload_error);
            return redirect("ClientLogo/show_client_logo");
        }

    }
    public function delete_client_logo($id){

            $result=$this->ClientLogomodel->get_client_logo_by_id($id);
            $pos=strripos($result->image,"/");//finding starting postinion of image
            $image_name=substr($result->image,++$pos);//getting name of the image, increment postion by one to avoid '/'
            unlink("uploads/$image_name");
            if($this->ClientLogomodel->delete_client_logo($id)){
                $this->session->set_flashdata('msg','Deleted client logo successfully..');
                return redirect("ClientLogo/show_client_logo");
            }

    }
}

?>
