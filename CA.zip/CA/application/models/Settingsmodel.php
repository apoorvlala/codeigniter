<?php

class Settingsmodel extends CI_Model{
    
    public function addSettings($companyname , $companyemail , $companyphone , $companyaddress){
        $affected_rows=$this->db->query("INSERT INTO `settings`(`companyname`, `email`, `phone`, `address`) VALUES ('".$companyname."','".$companyemail."','".$companyphone."','".$companyaddress."')");
        return $affected_rows;
    }
    public function show_settings(){
        $q=$this->db->query("SELECT * FROM `settings`");
        return $q->result();
    }
    public function show_settings_by_id($id){
        $q=$this->db->query("SELECT * FROM `settings` WHERE `id`='".$id."'");
        return $q->row();
    }
    public function updateSettings($companyname , $companyemail , $companyphone , $companyaddress , $id){
        $affected_rows=$this->db->query("UPDATE `settings` SET `companyname`='".$companyname."',`email`='".$companyemail."',`phone`='".$companyphone."',`address`='".$companyaddress."' WHERE `id`='".$id."'");
        return $affected_rows;
    }
    public function show_latest_settings(){
        $q=$this->db->query("SELECT * FROM `settings` ORDER BY `id` DESC LIMIT 1");
        return $q->row();
    }
}

?>