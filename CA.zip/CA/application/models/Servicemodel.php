<?php
class Servicemodel extends CI_Model{

    public function addService($servicename ,$description,$image_path , $status,$metatitle ,$metadescription ,$metakeyword,$url ){

        $affected_rows=$this->db->query("INSERT INTO `services`(`servicename`, `description`, `image`, `status`, `metatitle`, `metadescription`, `metakeyword`,`url`) VALUES ('".$servicename."','".$description."','".$image_path."','".$status."','".$metatitle."','".$metadescription."','".$metakeyword."','".$url."')");
        return $affected_rows;
    }

    public function showServices(){
        $q=$this->db->query("SELECT `id`, `servicename`, `description`, `image`, `status`, `metatitle`, `metadescription`, `metakeyword`,`url` FROM `services` ORDER BY `id` DESC");
        return $q->result();
    }

    public function showServices_by_Id($id){
        $q=$this->db->query("SELECT `id`, `servicename`, `description`, `image`, `status`, `metatitle`, `metadescription`, `metakeyword`, `url` FROM `services` WHERE `id`='".$id."'");
        return $q->row();
    }
    public function update_image($id ,$image_path){
        $affected_rows=$this->db->query("UPDATE `services` SET `image`='".$image_path."' WHERE `id`='".$id."'");
        return $affected_rows;
    }
    public function update_services($servicename , $description , $metatitle,$metadescription ,$metakeyword , $url , $id){
        $affected_rows=$this->db->query("UPDATE `services` SET `servicename`='".$servicename."', `description`='".$description."',`metatitle`='".$metatitle."',`metadescription`='".$metadescription."',`metakeyword`='".$metakeyword."',`url`='".$url."' WHERE `id`='".$id."'");
        return $affected_rows;
    }
    public function getImageById($id){
        $q=$this->db->query("SELECT `image` FROM `services` WHERE `id`='".$id."'");
        return $q->row();
    }
    public function deleteService($id){
        $affected_rows=$this->db->query("DELETE FROM `services` WHERE `id`='".$id."' ");
        return $affected_rows;
    }
    

}

?>
