<?php

class Blogmodel extends CI_Model{

    public function addblog($metatitle , $metadescription , $metakeyword , $blogheading , $description , $image_path , $status , $date){

        $affected_rows=$this->db->query("INSERT INTO `blog`(`metatitle`, `metadescription`, `metakeyword`, `blogheading`, `description`, `image`, `status`,`date`) VALUES ('".$metatitle."','".$metadescription."','".$metakeyword."','".$blogheading."','".$description."','".$image_path."','".$status."','".$date."')");
        return $affected_rows;

    }
    public function showBlogs(){
        $q=$this->db->query("SELECT * FROM `blog` ORDER BY `id` DESC");
        return $q->result();
    }
    public function showBlogs_Id($id){
        $q=$this->db->query("SELECT * FROM `blog` WHERE `id`='".$id."'");
        return $q->row();
    }
    public function updateBlog($metatitle , $metadescription , $metakeyword , $blogheading , $description , $id){
        $affected_rows=$this->db->query("UPDATE `blog` SET `metatitle`='".$metatitle."',`metadescription`='".$metadescription."',`metakeyword`='".$metakeyword."',`blogheading`='".$blogheading."',`description`='".$description."' WHERE `id`='".$id."'");
        return $affected_rows;
    }
    public function update_image($id ,$image_path){

        $affected_rows=$this->db->query("UPDATE `blog` SET `image`='".$image_path."' WHERE `id`='".$id."'");
        return $affected_rows;
    }
    public function deleteBlog($id){
        $affected_rows=$this->db->query("DELETE FROM `blog` WHERE `id`='".$id."' ");
        return $affected_rows;
    }
    public function getBlogPostForView(){
        $q=$this->db->query("SELECT * FROM `blog` ORDER BY `id` DESC LIMIT 6");
        return $q->result();
    }
}

?>
