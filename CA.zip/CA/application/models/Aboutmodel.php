<?php
class Aboutmodel extends CI_Model{
    
    public function add_about($description){
        
        $affected_row=$this->db->query("INSERT INTO `about`(`description`) VALUES ('".$description."')");
        return $affected_row;
    }
    public function show_about(){
        $q=$this->db->query("SELECT * FROM `about` ORDER BY `id` DESC");
        return $q->result();
    }
    public function show_about_by_id($id){
        $q=$this->db->query("SELECT * FROM `about` WHERE `id`='".$id."'");
        return $q->row();
    }
    public function update_about($id , $description){
        $affected_row=$this->db->query("UPDATE `about` SET `description`='".$description."' WHERE `id`='".$id."'");
        return $affected_row;
    }
    public function get_about_content_view(){
        $q=$this->db->query("SELECT * FROM `about` ORDER BY `id` DESC LIMIT 1");
        return $q->row();
    }
}
?>