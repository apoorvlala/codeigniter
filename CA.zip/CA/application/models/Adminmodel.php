<?php
class Adminmodel extends CI_Model{

    /*----------checking login------------*/
    public function login_valid($username , $password){

        $q=$this->db->query("SELECT `id`, `username`, `password` FROM `user` WHERE `username`='".$username."' AND `password`='".$password."'");
        if($q->num_rows()){

            return($q->row()->id);
        }
        else{
            return false;
        }
    }

    /*----------Insert Main menu------------*/
    public function add_category($menuname , $url , $status){
        $affected_rows=$this->db->query("INSERT INTO `mainmenu`(`menuname`, `url`, `status`) VALUES ('".$menuname."','".$url."','".$status."')");
        return $affected_rows;
    }
    /*----------Show Main menu------------*/
    public function show_category(){
        $q=$this->db->query("SELECT `id`, `menuname`, `url`, `status` FROM `mainmenu`");
        return $q->result();
    }
    public function show_category_by_id($id){
        $q=$this->db->query("SELECT `id`, `menuname`, `url`, `status` FROM `mainmenu` WHERE `id`='".$id."'");
        return $q->row();
    }
    /*----------Update Main menu / Category------------*/
    public function update_category($id , $mainmenu , $url){
        $affected_rows=$this->db->query("UPDATE `mainmenu` SET `menuname`='".$mainmenu."',`url`='".$url."' WHERE `id`='".$id."'");
        return $affected_rows;
    }
    /*----------Deleted Main menu / Category------------*/
    public function deleteMainCategory($id) {
        $this->db->query("DELETE FROM `submenu` WHERE `mainmenuid`='".$id."'");
        $deleted_rows=$this->db->query("DELETE FROM `mainmenu` WHERE `id`='".$id."'");
        return $deleted_rows;

    }

    /*-----------------------------------------------------------------------*/
    /*-----------------------------------------------------------------------*/

    /*---------------------Insert sub menu----------------------------*/
    public function add_sub_category($submenu , $mainmenuid , $url , $status){
        $affected_rows=$this->db->query("INSERT INTO `submenu`(`submenu`, `mainmenuid`, `url`, `status`) VALUES ('".$submenu."','".$mainmenuid."','".$url."','".$status."')");
        return $affected_rows;

    }

    /*---------------------SELECT sub menu----------------------------*/
    public function show_submenu_with_main_menu(){
        $q=$this->db->query("SELECT mainmenu.menuname,mainmenu.id, submenu.submenu ,submenu.id ,submenu.url FROM submenu INNER JOIN mainmenu ON mainmenu.id = submenu.mainmenuid");
        return $q->result();
    }
    /*---------------------SELECT sub menu only----------------------------*/
    public function show_subcategory(){
        $q=$this->db->query("SELECT * FROM `submenu`");
        return $q->result();
    }
    public function show_subcategory_by_id($id){
        $q=$this->db->query("SELECT mainmenu.menuname, submenu.submenu ,submenu.id,submenu.mainmenuid ,submenu.url FROM submenu INNER JOIN mainmenu ON mainmenu.id = submenu.mainmenuid WHERE submenu.id='".$id."'");
        return $q->row();
    }
    /*---------------------DELETE sub menu----------------------------*/
    public function deletesubCategory($id){
        $this->db->query("DELETE FROM `subsubcat` WHERE `id`='".$id."'");
        $affected_rows=$this->db->query("DELETE FROM `submenu` WHERE `id`='".$id."'");
        return $affected_rows;
    }
    /*------------------Update Submenu-------------------------*/
    public function updateSubmenu($submenu , $url , $id){
        $affected_rows=$this->db->query("UPDATE `submenu` SET `submenu`='".$submenu."',`url`='".$url."' WHERE `id`='".$id."'");
        return $affected_rows;
    }

    /*-------------------Insert Sub sub menu----------------------*/
    /*-------------------Insert Sub sub menu----------------------*/
    public function insert_sub_sub_menu($subsubcat,$subcatid,$url,$status ){
        $affected_rows=$this->db->query("INSERT INTO `subsubcat`(`subsubcat`, `subcatid`, `url`, `status`) VALUES ('".$subsubcat."','".$subcatid."','".$url."','".$status."')");
        return $affected_rows;
    }
    public function show_sub_sub_cat(){
        $q=$this->db->query("SELECT submenu.`submenu`, subsubcat.`subsubcat`,subsubcat.`subcatid` , subsubcat.`url`,subsubcat.`id` from subsubcat Inner join submenu on submenu.`id`=subsubcat.`subcatid`");
        return $q->result();
    }
    public function show_sub_sub_cat_by_id($id){
        $q=$this->db->query("SELECT submenu.`submenu`, subsubcat.`subcatid`, subsubcat.`subsubcat` , subsubcat.`url`,subsubcat.`id` from subsubcat Inner join submenu on submenu.`id`=subsubcat.`subcatid` WHERE subsubcat.`id`='".$id."'");
        return $q->row();
    }
    public function updateSubSubCategory($subsub_cat , $url , $id){
        $affected_rows=$this->db->query("UPDATE `subsubcat` SET `subsubcat`='".$subsub_cat."',`url`='".$url."' WHERE `id`='".$id."'");
        return $affected_rows;
    }
    public function deleteSubSubCat($id){
        $affected_rows=$this->db->query("DELETE FROM `subsubcat` WHERE `id`='".$id."'");
        return $affected_rows;
    }


}


?>
