<?php
class DetailPagemodel extends CI_Model{
    
    public function add_detail_page($metatitle , $metadescription , $metakeyword , $small_heading , $small_description , $main_heading , $main_description , $url , $doc1 , $doc2 , $doc3 , $doc4 , $status , $image_path){
        $affected_rows=$this->db->query("INSERT INTO `detailpage`(`metatitle`, `metadescription`, `metakeyword`, `small_heading`, `small_description`, `main_heading`, `main_description`, `url`, `doc1`, `doc2`, `doc3`, `doc4`, `status`,`image`) VALUES ('".$metatitle."','".$metadescription."','".$metakeyword."','".$small_heading."','".$small_description."','".$main_heading."','".$main_description."','".$url."','".$doc1."','".$doc2."','".$doc3."','".$doc4."','".$status."' , '".$image_path."')");
        return $affected_rows;
    }
    public function showDetailPages(){
        $q=$this->db->query("SELECT * FROM `detailpage` ORDER BY `id` DESC");
        return $q->result();
    }
    public function showDetailPagesById($id){
        $q=$this->db->query("SELECT * FROM `detailpage` WHERE `id`='".$id."' ");
        return $q->row();
    }
    public function updateDetailPage($metatitle , $metadescription , $metakeyword , $small_heading , $small_description , $main_heading , $main_description , $url , $doc1 , $doc2 , $doc3 , $doc4 , $id){
        
        $affected_rows=$this->db->query("
        
        UPDATE `detailpage` SET `metatitle`='".$metatitle."',`metadescription`='".$metadescription."',`metakeyword`='".$metakeyword."',`small_heading`='".$small_heading."',`small_description`='".$small_description."',`main_heading`='".$main_heading."',`main_description`='".$main_description."',`url`='".$url."',`doc1`='".$doc1."',`doc2`='".$doc2."',`doc3`='".$doc3."',`doc4`='".$doc4."' WHERE `id`='".$id."'
        
        ");
        return $affected_rows;
    }
    public function getImageById($id){
        $q=$this->db->query("SELECT `image` FROM `detailpage` WHERE `id`='".$id."' ");
        return $q->row();
    }
    public function update_image($id ,$image_path){
        $affected_rows=$this->db->query("UPDATE `detailpage` SET `image`='".$image_path."' WHERE `id`='".$id."'");
        return $affected_rows;
    }
    public function deleteDetailsPage($id){
        $affected_rows=$this->db->query("DELETE FROM `detailpage` WHERE `id`='".$id."'");
        return $affected_rows;
    }
    public function getDetailPageData($urlsegment){
        $q=$this->db->query("SELECT * FROM `detailpage` WHERE `url`='".$urlsegment."'");
        return $q->row();
    }
    public function getAllServicesNames(){
        $q=$this->db->query("SELECT `small_heading` , `url` FROM `detailpage` ORDER BY `id` DESC LIMIT 8");
        return $q->result();
    }
}

?>