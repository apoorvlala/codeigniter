<?php
class Testimonialmodel extends CI_Model{

    public function addTestimonial($description ,$image_path ,$status ){
        $affected_rows=$this->db->query("INSERT INTO `testimonial`(`description`, `image`, `status`) VALUES ('".$description."','".$image_path."','".$status."')");
        return $affected_rows;
    }
    public function showTestimonials(){
        $q=$this->db->query("SELECT * FROM `testimonial` ORDER BY `id` DESC");
        return $q->result();
    }
    public function showTestimonialById($id){
        $q=$this->db->query("SELECT * FROM `testimonial` WHERE `id`='".$id."'");
        return $q->row();
    }
    public function updateTestimonial($description , $id){
        $affected_rows=$this->db->query("UPDATE `testimonial` SET `description`='".$description."' WHERE `id`='".$id."'");
        return $affected_rows;
    }
    public function getImageById($id){
        $q=$this->db->query("SELECT `image` FROM `testimonial` WHERE `id`='".$id."'");
        return $q->row();
    }
    public function update_image($id ,$image_path){
        $affected_rows=$this->db->query("UPDATE `testimonial` SET `image`='".$image_path."' WHERE `id`='".$id."'");
        return $affected_rows;
    }
    public function deleteTestimonial($id){
        $affected_rows=$this->db->query("DELETE FROM `testimonial` WHERE `id`='".$id."' ");
        return $affected_rows;
    }
}

?>
