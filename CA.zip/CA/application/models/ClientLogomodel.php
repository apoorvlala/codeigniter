<?php
class ClientLogomodel extends CI_Model{
    public function add_clients_logo($image_path){
        $affected_row=$this->db->query("INSERT INTO `clientslogo`(`image`) VALUES ('".$image_path."')");
        return $affected_row;
    }
    public function show_client_logo(){
        $result=$this->db->query("SELECT * FROM `clientslogo` ORDER BY `id` DESC");
        return $result->result();
    }
    public function get_client_logo_by_id($id){
        $q=$this->db->query("SELECT * FROM `clientslogo` WHERE `id`='".$id."'");
        return $q->row();
    }
    public function update_image($id ,$image_path){
        $affected_row=$this->db->query("UPDATE `clientslogo` SET `image`='".$image_path."' WHERE `id`='".$id."'");
        return $affected_row;
    }
    public function delete_client_logo($id){
        $affected_row=$this->db->query("DELETE FROM `clientslogo` WHERE `id`='".$id."'");
        return $affected_row;
    }
}

?>
