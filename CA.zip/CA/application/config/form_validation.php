<?php

$config=[


    'login_form_rules'=>[

        [
            'field'=>'username',
            'label'>'Username',
            'rules'=>'required'
        ],
        [
            'field'=>'password',
            'label'=>'Password',
            'rules'=>'required'
        ]
    ],

    'category_rules'=>[
        [
            'field'=>'category',
            'label'=>'Main Category',
            'rules'=>'required'
        ],
        [
            'field'=>'url',
            'label'=>'URL',
            'rules'=>'required'
        ]

    ],
    'sub_cat_rules'=>[

        [
          'field'=>'sel_cat',
          'label'=>'Main Category',
          'rules'=>'required',
        ],
        [
            'field'=>'category',
            'label'=>'Sub Category',
            'rules'=>'required'
        ],
        [
            'field'=>'url',
            'label'=>'URL',
            'rules'=>'required'
        ]
    ],
    'sub_sub_cat_rules'=>[

        [
          'field'=>'sel_cat',
          'label'=>'Sub Category',
          'rules'=>'required',
        ],
        [
            'field'=>'category',
            'label'=>'Sub sub Category',
            'rules'=>'required'
        ],
        [
            'field'=>'url',
            'label'=>'URL',
            'rules'=>'required'
        ]
    ],
    'service_validation'=>[
        [
            'field'=>'metatitle',
            'label'=>'Metatitle',
            'rules'=>'required'
        ],
        [
            'field'=>'metadescription',
            'label'=>'Metadescription',
            'rules'=>'required'
        ],
        [
            'field'=>'metakeyword',
            'label'=>'Metakeyword',
            'rules'=>'required'
        ],
        [
            'field'=>'service',
            'label'=>'Service',
            'rules'=>'required'
        ],
        [
            'field'=>'description',
            'label'=>'Description',
            'rules'=>'required'
        ],
        [
            'field'=>'url',
            'label'=>'Url',
            'rules'=>'required'
        ]
    ],

    'testimonial_validation'=>[
        [
            'field'=>'description',
            'label'=>'Description',
            'rules'=>'required'
        ]
    ],

    'blog_validation'=>[
        [
            'field'=>'metatitle',
            'label'=>'Metatitle',
            'rules'=>'required'
        ],
        [
            'field'=>'metadescription',
            'label'=>'Metadescription',
            'rules'=>'required'
        ],
        [
            'field'=>'metakeyword',
            'label'=>'Metakeyword',
            'rules'=>'required'
        ],
        [
            'field'=>'blogheading',
            'label'=>'Blog heading',
            'rules'=>'required'
        ],
        [
            'field'=>'description',
            'label'=>'Description',
            'rules'=>'required'
        ],

    ],
    
    'detail_page_validation'=>[
        
        [
            'field'=>'metatitle',
            'label'=>'Metatitle',
            'rules'=>'required',
        ],
        [
            'field'=>'metadescription',
            'label'=>'Metadescription',
            'rules'=>'required',
        ],
        [
            'field'=>'metakeyword',
            'label'=>'Metakeyword',
            'rules'=>'required',
        ],
        [
            'field'=>'small_heading',
            'label'=>'Small heading',
            'rules'=>'required',
        ],
        [
            'field'=>'small_description',
            'label'=>'Small description',
            'rules'=>'required',
        ],
        [
            'field'=>'main_heading',
            'label'=>'Main Heading',
            'rules'=>'required',
        ],
        [
            'field'=>'main_description',
            'label'=>'Main description',
            'rules'=>'required',
        ],
        [
            'field'=>'url',
            'label'=>'URL',
            'rules'=>'required',
        ],
        [
            'field'=>'doc1',
            'label'=>'First Document',
            'rules'=>'required',
        ],
        [
            'field'=>'doc2',
            'label'=>'Second Document',
            'rules'=>'required',
        ],
        [
            'field'=>'doc3',
            'label'=>'Third Document',
            'rules'=>'required',
        ],
        [
            'field'=>'doc4',
            'label'=>'Fourth Document',
            'rules'=>'required',
        ],
        
    ],
    'settings_validation'=>[
        [
            'field'=>'companyname',
            'label'=>'Company name',
            'rules'=>'required'
        ],
        [
            'field'=>'companyemail',
            'label'=>'Company email',
            'rules'=>'required|valid_email'
        ],
        [
            'field'=>'companyphone',
            'label'=>'Company phone',
            'rules'=>'required|integer|exact_length[10]'
        ],
        [
            'field'=>'companyaddress',
            'label'=>'Company address',
            'rules'=>'required'
        ],
        
    ],
    'about_validation'=>[
        
        [
            'field'=>'description',
            'label'=>'Description',
            'rules'=>'required'
        ]
    ]


];

?>
