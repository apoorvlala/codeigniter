-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 09, 2018 at 10:58 AM
-- Server version: 5.7.23
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mkcconsu_mkdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `id` int(11) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `description`) VALUES
(1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.\r\n<p><strong>Our Main Services :</strong></p>\r\n\r\n<ul>\r\n	<li><strong>Incorporation of Companies/LLP/Partnership and its Compliances.</strong></li>\r\n	<li><strong>Tax Consultant .</strong></li>\r\n	<li><strong>Registration under GSTn/Service Tax/Vat.</strong></li>\r\n	<li><strong>Registration of Trademark/FSSAI/Labor Act/PPF.</strong></li>\r\n	<li><strong>Secretarial Audit and Compliances.</strong></li>\r\n	<li><strong>Digital Signature Certificate.</strong></li>\r\n	<li><strong>Registraion of ISO/ESIC/TAN/PAN/EPF/Import Export Code/Society.</strong></li>\r\n	<li><strong>Manage your Business and Returns.</strong></li>\r\n	<li><strong>OR Other Business Related Services and advices.</strong></li>\r\n</ul>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `metatitle` text NOT NULL,
  `metadescription` text NOT NULL,
  `metakeyword` text NOT NULL,
  `blogheading` text NOT NULL,
  `description` text NOT NULL,
  `image` text NOT NULL,
  `status` int(1) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `metatitle`, `metadescription`, `metakeyword`, `blogheading`, `description`, `image`, `status`, `date`) VALUES
(3, 'UI / UX , Web &amp;amp; Mobile Development and Design Services', 'Duplex Android , PHP , website , portal , app , theme , static page , web', 'UPSC CPF AC', 'Company Formation', '<p>If you are going to use a passage of Lorem Ipsum, you need to be sure there isn&#39;t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary</p>\r\n', 'http://mkcconsultant.com/uploads/blog1.png', 1, '2018-08-02'),
(4, 'tax savings', 'tax savings', 'tax savings', 'Tax Savings', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English.', 'http://mkcconsultant.com/uploads/blog3.jpg', 1, '2018-08-02'),
(5, 'Startups', 'Startups', 'Startups', 'Startups', 'Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy.', 'http://mkcconsultant.com/uploads/Digital-Signatures.png', 1, '2018-08-02'),
(6, 'Business Blog meta', 'Business Blog meta', 'Business Blog keyword', 'Business Blog', 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy.', 'http://mkcconsultant.com/uploads/blog2.jpg', 1, '2018-08-02'),
(7, 'Business News title', 'Business News meta description', 'Business News metakeyword', 'Business News', 'If you are going to use a passage of Lorem Ipsum, you need to be sure there isn&#39;t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary.', 'http://mkcconsultant.com/uploads/gstgloval.jpg', 1, '2018-08-02'),
(8, 'Daily updates', 'Daily updates', 'Daily updates', 'Daily updates', 'If you are going to use a passage of Lorem Ipsum, you need to be sure there isn&#39;t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary', 'http://mkcconsultant.com/uploads/blog21.jpg', 1, '2018-08-02'),
(9, 'New blog', 'New blog meta', 'New blog metakey', 'Our New Servcie', '<p>Incorporation of Companies/LLP/Partnership and its Compliances.,Tax Consultant ,Registration under GSTn/Service Tax/Vat, Registration of Trademark/FSSAI/Labor Act/PPF ,Secretarial Audit and Compliances., Digital Signature Certificate , Registraion of ISO/ESIC/TAN/PAN/EPF/Import Export Code/Society., Manage your Business and Returns , Other Business Related Services and advices.</p>\r\n\r\n<p><br />\r\n&nbsp;</p>\r\n', 'http://mkcconsultant.com/uploads/new_serv.jpg', 1, '2018-08-02');

-- --------------------------------------------------------

--
-- Table structure for table `clientslogo`
--

CREATE TABLE `clientslogo` (
  `id` int(11) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clientslogo`
--

INSERT INTO `clientslogo` (`id`, `image`) VALUES
(5, 'http://mkcconsultant.com/uploads/indi.png'),
(6, 'http://mkcconsultant.com/uploads/htds.png'),
(7, 'http://mkcconsultant.com/uploads/out.png'),
(8, 'http://mkcconsultant.com/uploads/buss.png'),
(9, 'http://mkcconsultant.com/uploads/inn.png'),
(10, 'http://mkcconsultant.com/uploads/yahoo.png'),
(11, 'http://mkcconsultant.com/uploads/ani.png'),
(14, 'http://mkcconsultant.com/uploads/buss1.png');

-- --------------------------------------------------------

--
-- Table structure for table `detailpage`
--

CREATE TABLE `detailpage` (
  `id` int(11) NOT NULL,
  `metatitle` text NOT NULL,
  `metadescription` text NOT NULL,
  `metakeyword` text NOT NULL,
  `small_heading` text NOT NULL,
  `small_description` text NOT NULL,
  `main_heading` text NOT NULL,
  `main_description` text NOT NULL,
  `url` text NOT NULL,
  `doc1` varchar(220) NOT NULL,
  `doc2` varchar(220) NOT NULL,
  `doc3` varchar(220) NOT NULL,
  `doc4` varchar(20) NOT NULL,
  `status` int(1) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detailpage`
--

INSERT INTO `detailpage` (`id`, `metatitle`, `metadescription`, `metakeyword`, `small_heading`, `small_description`, `main_heading`, `main_description`, `url`, `doc1`, `doc2`, `doc3`, `doc4`, `status`, `image`) VALUES
(8, 'Company Registration MADHUKRIPA CORPORATE CONSULTANT (P) LTD.', 'Company Registration', 'Company Registration', 'Company Registration', '<p>Let&rsquo;s try and understand the types of business structures available in India. Here is a list of some of them:</p>\r\n\r\n<ul>\r\n	<li>One Person Company (OPC)</li>\r\n	<li>Limited Liability Partnership (LLP)</li>\r\n	<li>Private Limited Company (PLC)</li>\r\n	<li>Public Limited Company (PLC)</li>\r\n</ul>\r\n', 'What are the types of business structures in India?', 'Let&rsquo;s try and understand the types of business structures available in India. Here is a list of some of them:<br />\r\n<br />\r\n1.&nbsp;&nbsp; &nbsp;<strong>One Person Company (OPC):</strong> Recently introduced in the year 2013, an OPC is the best way to start a company if their exists only one promoter or owner. &nbsp;It enables a sole-proprietor to carry on his work and still be part of the corporate framework.<br />\r\n2.&nbsp;&nbsp; &nbsp;<strong>Limited Liability Partnership (LLP):</strong> A separate legal entity, in an LLP the liabilities of partners are only limited only to their agreed contribution. &nbsp;&nbsp;<br />\r\n3.&nbsp;&nbsp; &nbsp;<strong>Private Limited Company (PLC):</strong> &nbsp;A company in the eyes of the law is regarded as a separate legal entity from its founders &nbsp;It has shareholders (stakeholders) and directors (company officers). Each individual is regarded as an employee of the company.<br />\r\n4.&nbsp;&nbsp; &nbsp;<strong>Public Limited Company (PLC) :</strong> A PLC is a voluntary association of members which is incorporated under company law. It has a separate legal existence and the liability of its members are limited to shares they hold.<br />\r\n<br />\r\n<strong>Why is it important to choose the right business structure?</strong><br />\r\n<br />\r\nIt is important to choose your business structure carefully as your Income Tax Returns will depend on it. While registering your enterprise, remember that each business structure has different levels of compliances that need to be met with. For example, a sole proprietor has to file only an income tax return. However, a company has to file an income tax return as well as an annual returns with the registrar of companies. A company&rsquo;s books of accounts are to be mandatorily audited every year. Abiding by these legal compliances requires spending money on auditors, accountants and tax filing experts.Therefore, it is important to select the right business structure when thinking of company registration. An entrepreneur must have a clear idea of the kind of the legal compliances he/she is willing to deal with.<br />\r\n<br />\r\n&nbsp; While, some business structures are relatively investor-friendly than others, investors will always prefer a recognised and legal business structure. For example, an investor may hesitate to give money to a sole proprietor. On the other hand, if a good business idea is backed by a recognised legal structure (like LLP, Company, etc) the investors will be more comfortable making an investment.<br />\r\n<br />\r\n<strong>How to choose a business structure while applying for company registration in India?</strong><br />\r\n<br />\r\nLet&rsquo;s take a look at some important questions every entrepreneur must ask himself before he/she finally decide upon a business structure.<br />\r\n<br />\r\n<strong>How many owners/partners will your business have?</strong><br />\r\n<br />\r\nIf you are single person who owns the entire initial investment required for the business, a &nbsp;One Person Company would be ideal for you. On the other hand, if your business has two or more owners and are actively seeking an investment from other parties a Limited Liability Partnership (LLP) or Private Limited Company would suit you best.<br />\r\n<br />\r\n<strong>Should your initial investment determine your choice of business structure?</strong><br />\r\n<br />\r\nThe answer to that question is &ndash; Yes, if you want to spend less initially, it would be wise to go in for a Sole Proprietor, or a HUF or a Partnership. But, if you are sure that you will be able to recover the setup and compliance costs, you can opt for a One Person Company, LLP or a Private Limited Company<br />\r\n<br />\r\n<strong>Willingness to bear the entire liability of the business.</strong><br />\r\n<br />\r\nBusiness structures like sole proprietor, HUF, and partnership firm have unlimited liability.<br />\r\n<br />\r\n<strong>Income Tax Rates Applicable to businesses</strong><br />\r\n<br />\r\nThe income tax rates applicable to a sole proprietorship and a HUF are &nbsp;the normal slab rates. In case of a sole proprietorship, the business income is clubbed with the individual&rsquo;s other income.But in case of other entities like partnership and company a tax rate of 30% is applicable.<br />\r\n<br />\r\n<strong>Plans of getting money from investors.</strong><br />\r\n<br />\r\nAs mentioned earlier, it is difficult to get investments when your business structure &nbsp;is unregistered.&nbsp;', 'company-registration', 'Pan', 'Adhar Card', 'Permanent Account Number', 'Residential Address', 1, 'http://mkcconsultant.com/uploads/compreg.jpg'),
(14, 'Trademark Registration Process', 'Trademark Registration Process', 'Trademark Registration Process', 'Trademark Registration Process', 'Trademark registration can be obtained for words, logo, numerals, slogan, device and more in India. Trademark registration provides legal right of exclusivity for use of the mark to the owner of the trademark. Trademark registration is however a long process involving multiple steps. In this article we cover the trademark registration process in India', 'Trademark registration research.', 'Before beginning the trademark registration process, the entrepreneur or a trademark professional must conduct a trademark search of the trademark database.<br />\r\n<br />\r\n<strong>Trademark Filing</strong><br />\r\n<br />\r\nOnce a trademark search is completed, the application for trademark registration can be filed with the Trademark Registrar. The application for registration of trademark must be made in the prescribed manner and filed along with the fee for trademark registration. Trademark application can be filed at one of the five Trademark Registrar Office having jurisdiction over the State or online.<br />\r\n<br />\r\nA trademark registration application must contain the following information:\r\n<ul>\r\n	<li>Logo or the Trademark</li>\r\n	<li>Name and address of the trademark owner</li>\r\n	<li>Classification or Trademark Class</li>\r\n	<li>Trademark used since date</li>\r\n	<li>Description of the goods or services</li>\r\n</ul>\r\n<br />\r\n<strong>Trademark Application Allotment</strong><br />\r\n<br />\r\nOnce the Trademark registration application is filed with the Trademark Registrar, a trademark application allotment number is provided within one or two working days.<br />\r\n<br />\r\n<strong>Vienna Codification</strong><br />\r\n<br />\r\nThe Vienna Classification or Vienna Codification, established by the Vienna Agreement (1973), is an international classification of the figurative elements of marks. Once the trademark registration application is filed, the Trademark Registrar will apply the Vienna Classification to the trademark based on the figurative elements of marks. While this work is in progress, the trademark application status usually reflects as &ldquo;Sent for Vienna Codification&rdquo;.<br />\r\n<br />\r\n<strong>Trademark Examination</strong><br />\r\n<br />\r\nOnce Vienna Codification is completed, the trademark registration application will be allotted to a Trademark Officer in the Trademark Registrar Office. The Trademark Officer would then review the trademark application for correctness and issue a trademark examination report. The Trademark Officer has the ability to accept the trademark registration application and allow for trademark journal publication or object the trademark registration application.<br />\r\n<br />\r\n<strong>Trademark Journal Publication</strong><br />\r\n<br />\r\nOnce the trademark registration application is accepted by the Trademark Registrar, the proposed trademark is published in the Trademark Journal. The trademark journal is published weekly and contains all the trademarks that have been accepted by the Trademark Registrar. Once the trademark is published in the trademark journal, the public have an opportunity to object the trademark registration, if they believe they will be damaged by that registration. If there are no objections filed within 90 days of that publication, the mark will typically be registered within 12 weeks &ndash; months time.', 'trademark-registration', 'ID Proof', 'Adhar Card', 'Pan Card', 'Residential Address', 1, 'http://mkcconsultant.com/uploads/trademarks.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `mainmenu`
--

CREATE TABLE `mainmenu` (
  `id` int(11) NOT NULL,
  `menuname` varchar(220) NOT NULL,
  `url` text NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mainmenu`
--

INSERT INTO `mainmenu` (`id`, `menuname`, `url`, `status`) VALUES
(6, 'Home', 'home', 1),
(7, 'About Us', 'about', 1),
(8, 'Our Services', 'home', 1),
(9, 'Blogs', 'blogpage', 1),
(10, 'Contact Us', 'contact', 1);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `servicename` varchar(220) NOT NULL,
  `description` text NOT NULL,
  `image` text NOT NULL,
  `status` int(1) NOT NULL,
  `metatitle` text NOT NULL,
  `metadescription` text NOT NULL,
  `metakeyword` text NOT NULL,
  `url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `servicename`, `description`, `image`, `status`, `metatitle`, `metadescription`, `metakeyword`, `url`) VALUES
(10, 'OR Other Business Related Services and advices.', '<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don&#39;t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn&#39;t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>\r\n', 'http://mkcconsultant.com/uploads/pen.png', 1, 'OR Other Business Related Services and advices.', 'service1 company incorporation', 'company incorporation service1', 'or-other-business-related-services-and-advices'),
(11, 'Registration under GSTn/Service Tax/Vat', '<p>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable.&nbsp;</p>\r\n', 'http://mkcconsultant.com/uploads/money-bag.png', 1, 'Registration under GSTn/Service Tax/Vat', 'dsfs', 'jobs jobs gove jobs jobs gove jobs jobs gove', 'registration-under-gstnservice-taxvat'),
(12, 'Registraion of ISO/ESIC/TAN/PAN/EPF/Import Export Code/Society.', '<p>It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>\r\n', 'http://mkcconsultant.com/uploads/iso1.png', 1, 'iso certifincation', 'iso certifincation , lko', 'iso certifincation , lko', 'registraion-of-isoesictanpanepfimport-export-codesociety'),
(13, 'Registration of Trademark/FSSAI/Labor Act/PPF', '<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don&#39;t look even slightly believable. If you are going to use a passage of Lorem Ipsum.</p>\r\n', 'http://mkcconsultant.com/uploads/trademark.png', 1, 'trademark', 'trademark , lko', 'trademark , gst , lko', 'registration-of-trademarkfssailabor-actppf'),
(14, 'Secretarial Audit and Compliances.', '<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p>\r\n', 'http://mkcconsultant.com/uploads/pat.png', 1, 'Secretarial Audit and Compliances.', 'Patent , tax ,lko', 'Patent , tax ,lko', 'secretarial-audit-and-compliances'),
(15, 'Registration of Trademark/FSSAI/Labor Act/PPF', '<p>When an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.&nbsp;</p>\r\n', 'http://mkcconsultant.com/uploads/copyright.png', 1, 'copyright', 'copyright , gst ,lko', 'copyright , gst ,lko', 'registration-of-trademarkfssailabor-actppf'),
(16, 'Digital Signature Certificate', '<p>When an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.&nbsp;</p>\r\n', 'http://mkcconsultant.com/uploads/code.png', 1, 'Registration under GSTn/Service Tax/Vat', 'IEC Code', 'IEC Code', 'digital-signature-certificate'),
(17, 'Tax Consultant', '<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English.</p>\r\n', 'http://mkcconsultant.com/uploads/tie.png', 1, 'Business Plan And Project', 'Business Plan And Project', 'Business Plan And Project', 'tax-consultant-'),
(18, 'Incorporation of Companies/LLP/Partnership and its Compliances.', '<p>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable.&nbsp;</p>\r\n', 'http://mkcconsultant.com/uploads/notepad_(2).png', 1, 'FSSAI Registration', 'FSSAI Registration', 'FSSAI Registration', 'fssai-registration');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `companyname` varchar(220) NOT NULL,
  `email` varchar(220) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `companyname`, `email`, `phone`, `address`) VALUES
(1, 'MADHUKRIPA CORPORATE CONSULTANT (P) LTD.', 'harshitrastogi615@gmail.com', '9506464444', '536 /2/628, Near Bada Durga Mandir Triveni Nagar 3 Rd Lucknow, Uttar Pradesh 226020 India.');

-- --------------------------------------------------------

--
-- Table structure for table `submenu`
--

CREATE TABLE `submenu` (
  `id` int(11) NOT NULL,
  `submenu` varchar(220) NOT NULL,
  `mainmenuid` int(11) NOT NULL,
  `url` text NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `submenu`
--

INSERT INTO `submenu` (`id`, `submenu`, `mainmenuid`, `url`, `status`) VALUES
(5, 'Registrations', 8, 'registrations', 1);

-- --------------------------------------------------------

--
-- Table structure for table `subsubcat`
--

CREATE TABLE `subsubcat` (
  `id` int(11) NOT NULL,
  `subsubcat` varchar(220) NOT NULL,
  `subcatid` int(11) NOT NULL,
  `url` text NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subsubcat`
--

INSERT INTO `subsubcat` (`id`, `subsubcat`, `subcatid`, `url`, `status`) VALUES
(12, 'Company Registration', 5, 'company-registration', 1),
(13, 'Trademark Registration', 5, 'trademark-registration', 1),
(14, 'IEC Registration', 5, 'iec-registration', 1),
(15, 'ISO Registration', 5, 'iso-registration', 1),
(16, 'GST Registration', 5, 'gst-registration', 1);

-- --------------------------------------------------------

--
-- Table structure for table `testimonial`
--

CREATE TABLE `testimonial` (
  `id` int(11) NOT NULL,
  `description` text NOT NULL,
  `image` text NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testimonial`
--

INSERT INTO `testimonial` (`id`, `description`, `image`, `status`) VALUES
(4, '<p>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>\r\n', 'http://mkcconsultant.com/uploads/HP-partner-logo.png', 1),
(5, 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour.', 'http://mkcconsultant.com/uploads/ci.png', 1),
(6, 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.', 'http://mkcconsultant.com/uploads/gpartner.png', 1),
(7, 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.', 'http://mkcconsultant.com/uploads/Zoho-Alliance-Partner.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(220) NOT NULL,
  `password` varchar(220) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'admin123@gmail.com', 'admin123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clientslogo`
--
ALTER TABLE `clientslogo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `detailpage`
--
ALTER TABLE `detailpage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mainmenu`
--
ALTER TABLE `mainmenu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `submenu`
--
ALTER TABLE `submenu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subsubcat`
--
ALTER TABLE `subsubcat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonial`
--
ALTER TABLE `testimonial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about`
--
ALTER TABLE `about`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `clientslogo`
--
ALTER TABLE `clientslogo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `detailpage`
--
ALTER TABLE `detailpage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `mainmenu`
--
ALTER TABLE `mainmenu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `submenu`
--
ALTER TABLE `submenu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `subsubcat`
--
ALTER TABLE `subsubcat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `testimonial`
--
ALTER TABLE `testimonial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
