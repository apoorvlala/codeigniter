! function(n) {
    n.fn.menumaker = function(s) {
        var e = n(this),
            i = n.extend({
                title: "Menu",
                format: "dropdown",
                sticky: !1
            }, s);
        return this.each(function() {
            return e.prepend('<div id="menu-button">' + i.title + "</div>"), n(this).find("#menu-button").on("click", function() {
                n(this).toggleClass("menu-opened");
                var s = n(this).next("ul");
                s.hasClass("open") ? s.hide().removeClass("open") : (s.show().addClass("open"), "dropdown" === i.format && s.find("ul").show())
            }), e.find("li ul").parent().addClass("has-sub"), multiTg = function() {
                e.find(".has-sub").prepend('<span class="submenu-button"></span>'), e.find(".submenu-button").on("click", function() {
                    n(this).toggleClass("submenu-opened"), n(this).siblings("ul").hasClass("open") ? n(this).siblings("ul").removeClass("open").hide() : n(this).siblings("ul").addClass("open").show()
                })
            }, "multitoggle" === i.format ? multiTg() : e.addClass("dropdown"), i.sticky === !0 && e.css("position", "fixed")
                
                /*, resizeFix = function() {
                n(window).width() > 768 && e.find("ul").show(), n(window).width() <= 768 && e.find("ul").hide().removeClass("open")
            }, resizeFix(), n(window).on("resize", resizeFix)*/
        })
    }
}(jQuery),
function(n) {
    n(document).ready(function() {
        n("#cssmenu").menumaker({
            title: "Menu",
            format: "multitoggle"
        })
    })
}(jQuery);
var TxtType = function(el, toRotate, period) {
    this.toRotate = toRotate;
    this.el = el;
    this.loopNum = 0;
    this.period = parseInt(period, 10) || 2000;
    this.txt = '';
    this.tick();
    this.isDeleting = false;
};
TxtType.prototype.tick = function() {
    var i = this.loopNum % this.toRotate.length;
    var fullTxt = this.toRotate[i];
    if (this.isDeleting) {
        this.txt = fullTxt.substring(0, this.txt.length - 1);
    } else {
        this.txt = fullTxt.substring(0, this.txt.length + 1);
    }
    this.el.innerHTML = '<span class="wrap">' + this.txt + '</span>';
    var that = this;
    var delta = 200 - Math.random() * 100;
    if (this.isDeleting) {
        delta /= 2;
    }
    if (!this.isDeleting && this.txt === fullTxt) {
        delta = this.period;
        this.isDeleting = true;
    } else if (this.isDeleting && this.txt === '') {
        this.isDeleting = false;
        this.loopNum++;
        delta = 500;
    }
    setTimeout(function() {
        that.tick();
    }, delta);
};
window.onload = function() {
    var elements = document.getElementsByClassName('typewrite');
    for (var i = 0; i < elements.length; i++) {
        var toRotate = elements[i].getAttribute('data-type');
        var period = elements[i].getAttribute('data-period');
        if (toRotate) {
            new TxtType(elements[i], JSON.parse(toRotate), period);
        }
    }
    var css = document.createElement("style");
    css.type = "text/css";
    css.innerHTML = ".typewrite > .wrap { border-right: 1px solid #222}";
    document.body.appendChild(css);
};

$(function() {
    $(".publish, .select-input, .auth2").slideUp();
    $(".photo").slideUp();
    $('.chkn').click(function() {
        $('.photo').slideUp();
    });
    $('.chky').click(function() {
        $('.photo').slideDown();
    });
    $(".otselect").on('change', function() {
        if (this.value == 'other') {
            $(".select-input").slideDown();
        } else {
            $(".select-input").slideUp();
        }
    });
    $("#auth").on('change', function() {
        if (this.value == 'individual') {
            $(".auth").slideUp();
        } else {
            $(".auth").slideDown();
        }
    });
    $("#publish").on('change', function() {
        if (this.value == 'publish') {
            $(".publish").slideDown();
        } else {
            $(".publish").slideUp();
        }
    });
    $(".others").slideUp();
    $("input[name='others']").on('change', function() {
        if ($(".otherchk").is(":checked")) {
            $(".others").slideDown();
        } else {
            $(".others").slideUp();
        }
    });
    $('.term').on('change', function() {
        $('.btn-submit').toggleClass('btn-disabeld');
    });
    $(".optnal").slideUp();
    $("input[name='invention']").click(function() {
        if ($("#chkyes").is(":checked")) {
            $(".optnal").slideDown();
        } else {
            $(".optnal").slideUp();
        }
    });
    $(".datepicker").datepicker({
        dateFormat: 'dd-mm-yy'
    });
});

function termschk() {
    var term = document.getElementById('term').checked;
    var disa = document.getElementById('btn-disabeld');
    if (term = 'true') {
        disa.classList.toggle('btn-disabeld');
    }
}