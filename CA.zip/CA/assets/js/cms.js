$(document).ready(function () {


    $("body").click(function () {
        if ($(".alert").length) {
            $(".alert").hide();
        }
    });

    $(document).delegate('.order-details-payment', 'click', function (e) {
        e.preventDefault();
        //alert("AAAAAAAAAA")
        var data_list = $(this);
        var data_order = data_list.attr("data-order");
        if (data_order !="")
        {
            //alert(data_order);
            //data_list.html("Please wait ....");
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_forms.php", type: "POST", data: {data_type: 'order-details-payment', data_order: data_order}, cache: false, dataType: "JSON", beforeSend: function () {
                    data_list.html("<i class=\"fa fa-spinner fa-spin fa-fw\" aria-hidden=\"true\"></i>");
                }, success: function (jsonStr) {
                    //alert(jsonStr);
                    if (jsonStr.message_status == 'success') {
                        if(jsonStr.custom == 0){
                            location.href = jsonStr.message;
                        }else{
                            $('#amount_pay_model').modal('show');
                            //data_list.html('<img src="'.$("body").attr('data-path').'images/paynow.gif" width="85"/>');
                        }
                    }
                }});            
        }
    }); 
    
    
    
    $(document).delegate('.delete-pending-order', 'click', function (e) {
        e.preventDefault();
        //alert("AAAAAAAAAA")
        var data_list = $(this);
        var data_order = data_list.attr("data-order");
        if (data_order !="")
        {
            var confirmres = confirm("Are you sure you want to delete this Order?"); 
            if(confirmres == true){            
            //alert(data_order);
            //data_list.html("Please wait ....");
                $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'delete-pending-order', data_order: data_order}, cache: false, dataType: "JSON", beforeSend: function () {
                    data_list.html("Detete <i class=\"fa fa-spinner fa-spin fa-fw\" aria-hidden=\"true\"></i>");
                }, success: function (jsonStr) {
                    //alert(jsonStr);
                    if (jsonStr.message_status == 'success') {
                            location.href = location.href;
                    }
                }}); 
            }
        }
    });    
    
    $('form[name="frmCustomOrderPayment"]').validate({
        rules: {payment_amount: {required: true, number: true, maxlength: 8}},
        messages: {payment_amount: {required: "Please enter amount", number: "Please enter a valid amount"}},
        submitHandler: function (form) {
            var formData = new FormData(form);
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_forms.php", type: "POST", data: formData, async: false, contentType: false, processData: false, cache: false, dataType: "JSON", beforeSend: function () {
                    $("#CustomOrderPayment").append(" <i class=\"fa fa-spinner fa-spin fa-x fa-fw\" aria-hidden=\"true\"></i>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    }
                }});
            return false;
        }          
    }); 
    
    $(document).delegate('.package_amount_cancel1', 'click', function (e) {
        $("#CustomOrderPayment").html("Pay");
        $('.order-details-payment').html('<img src="'+$("body").attr('data-path')+'images/paynow.gif" width="85"/>');
    });    
    
    
    $('.package-order-now').click(function (e) {
        e.preventDefault();
        var data_action = $(this);
        var order_package = data_action.val();
        var login_error = data_action.parent('form').find('.package-login-error')
        //alert(order_package);
        if (order_package != "") {
            var data_set = {data_type: 'package-order-now', order_package: order_package};
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: data_set, cache: false, dataType: "JSON", beforeSend: function () {
                    data_action.html("Wait.....");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == "success")
                    {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        data_action.html("Order now");
                    }
                }});

        }

    });
    
    $('form[name="frmDownloadFreeGuide"]').validate({
        rules: {email_address: {required: true, email: true, maxlength: 100}},
        messages: {email_address: {required: "Please enter email address", email: "Please enter a valid email address"}},
        errorPlacement: function (error, element) {
            error.insertAfter($(element).parent('div'));
        },
        submitHandler: function (form) {
            var formData = new FormData(form);
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: formData, async: false, contentType: false, processData: false, cache: false, dataType: "JSON", beforeSend: function () {
                    $("#DownloadFreeGuide").html("<i class=\"fa fa-spinner\" aria-hidden=\"true\"></i>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        //location.href = jsonStr.message;
                        var insert_before = $("#DownloadFreeGuide").parent('div');
                        $(jsonStr.message).insertBefore(insert_before);
                        $("#DownloadFreeGuide").html("Send");
                    }
                }});
            return false;
        }          
    });    
    

    $('form[name="frmPackageSignin1"]').validate({
        rules: {login_email_address: {required: true, email: true, maxlength: 100}, login_password: {required: true, maxlength: 50}},
        messages: {login_email_address: {required: "Please enter email address", email: "Please enter a valid email address"}, login_password: {required: "Please enter password"}},
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-login-error');
            var login_email_address = form.find('input[name="login_email_address"]').val();
            var login_password = form.find('input[name="login_password"]').val();
            var login_package = form.find('input[name="login_package"]').val();
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-login', login_email_address: login_email_address, login_password: login_password, login_package: login_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    //data_action.html("Wait.....")
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    });
    $('form[name="frmPackageSignin2"]').validate({
        rules: {login_email_address: {required: true, email: true, maxlength: 100}, login_password: {required: true, maxlength: 50}},
        messages: {login_email_address: {required: "Please enter email address", email: "Please enter a valid email address"}, login_password: {required: "Please enter password"}},
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-login-error');
            var login_email_address = form.find('input[name="login_email_address"]').val();
            var login_password = form.find('input[name="login_password"]').val();
            var login_package = form.find('input[name="login_package"]').val();
            //alert(login_password);
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-login', login_email_address: login_email_address, login_password: login_password, login_package: login_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    });
    $('form[name="frmPackageSignin3"]').validate({
        rules: {login_email_address: {required: true, email: true, maxlength: 100}, login_password: {required: true, maxlength: 50}},
        messages: {login_email_address: {required: "Please enter email address", email: "Please enter a valid email address"}, login_password: {required: "Please enter password"}},
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-login-error');
            var login_email_address = form.find('input[name="login_email_address"]').val();
            var login_password = form.find('input[name="login_password"]').val();
            var login_package = form.find('input[name="login_package"]').val();
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-login', login_email_address: login_email_address, login_password: login_password, login_package: login_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    });
    $('form[name="frmPackageSignin4"]').validate({
        rules: {login_email_address: {required: true, email: true, maxlength: 100}, login_password: {required: true, maxlength: 50}},
        messages: {login_email_address: {required: "Please enter email address", email: "Please enter a valid email address"}, login_password: {required: "Please enter password"}},
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-login-error');
            var login_email_address = form.find('input[name="login_email_address"]').val();
            var login_password = form.find('input[name="login_password"]').val();
            var login_package = form.find('input[name="login_package"]').val();
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-login', login_email_address: login_email_address, login_password: login_password, login_package: login_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    });
    $('form[name="frmPackageSignin5"]').validate({
        rules: {login_email_address: {required: true, email: true, maxlength: 100}, login_password: {required: true, maxlength: 50}},
        messages: {login_email_address: {required: "Please enter email address", email: "Please enter a valid email address"}, login_password: {required: "Please enter password"}},
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-login-error');
            var login_email_address = form.find('input[name="login_email_address"]').val();
            var login_password = form.find('input[name="login_password"]').val();
            var login_package = form.find('input[name="login_package"]').val();
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-login', login_email_address: login_email_address, login_password: login_password, login_package: login_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    });
    $('form[name="frmPackageSignin6"]').validate({
        rules: {login_email_address: {required: true, email: true, maxlength: 100}, login_password: {required: true, maxlength: 50}},
        messages: {login_email_address: {required: "Please enter email address", email: "Please enter a valid email address"}, login_password: {required: "Please enter password"}},
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-login-error');
            var login_email_address = form.find('input[name="login_email_address"]').val();
            var login_password = form.find('input[name="login_password"]').val();
            var login_package = form.find('input[name="login_package"]').val();
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-login', login_email_address: login_email_address, login_password: login_password, login_package: login_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    });
    $('form[name="frmPackageSignin7"]').validate({
        rules: {login_email_address: {required: true, email: true, maxlength: 100}, login_password: {required: true, maxlength: 50}},
        messages: {login_email_address: {required: "Please enter email address", email: "Please enter a valid email address"}, login_password: {required: "Please enter password"}},
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-login-error');
            var login_email_address = form.find('input[name="login_email_address"]').val();
            var login_password = form.find('input[name="login_password"]').val();
            var login_package = form.find('input[name="login_package"]').val();
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-login', login_email_address: login_email_address, login_password: login_password, login_package: login_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    }); 
    $('form[name="frmPackageSignin8"]').validate({
        rules: {login_email_address: {required: true, email: true, maxlength: 100}, login_password: {required: true, maxlength: 50}},
        messages: {login_email_address: {required: "Please enter email address", email: "Please enter a valid email address"}, login_password: {required: "Please enter password"}},
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-login-error');
            var login_email_address = form.find('input[name="login_email_address"]').val();
            var login_password = form.find('input[name="login_password"]').val();
            var login_package = form.find('input[name="login_package"]').val();
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-login', login_email_address: login_email_address, login_password: login_password, login_package: login_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    });  
    $('form[name="frmPackageSignin9"]').validate({
        rules: {login_email_address: {required: true, email: true, maxlength: 100}, login_password: {required: true, maxlength: 50}},
        messages: {login_email_address: {required: "Please enter email address", email: "Please enter a valid email address"}, login_password: {required: "Please enter password"}},
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-login-error');
            var login_email_address = form.find('input[name="login_email_address"]').val();
            var login_password = form.find('input[name="login_password"]').val();
            var login_package = form.find('input[name="login_package"]').val();
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-login', login_email_address: login_email_address, login_password: login_password, login_package: login_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    });   
    $('form[name="frmPackageSignin10"]').validate({
        rules: {login_email_address: {required: true, email: true, maxlength: 100}, login_password: {required: true, maxlength: 50}},
        messages: {login_email_address: {required: "Please enter email address", email: "Please enter a valid email address"}, login_password: {required: "Please enter password"}},
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-login-error');
            var login_email_address = form.find('input[name="login_email_address"]').val();
            var login_password = form.find('input[name="login_password"]').val();
            var login_package = form.find('input[name="login_package"]').val();
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-login', login_email_address: login_email_address, login_password: login_password, login_package: login_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    });    
    $('form[name="frmPackageSignup1"]').validate({
        rules: {
            signup_fullname: {required: true, maxlength: 100},
            signup_email_address: {required: true, email: true, maxlength: 100},
            signup_mobile_no: {required: true, number: true, minlength: 10, maxlength: 10}
        },
        messages: {
            signup_fullname: {
                required: "Please enter name"
            },
            signup_mobile_no: {
                required: 'Please enter mobile number',
                minlength: 'Mobile number must be at least 10 characters',
                maxlength: "Please enter no more than 10 characters"
            }
        },
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-signup-error');
            var signup_fullname = form.find('input[name="signup_fullname"]').val();
            var signup_email_address = form.find('input[name="signup_email_address"]').val();
            var signup_mobile_no = form.find('input[name="signup_mobile_no"]').val();
            var signup_package = form.find('input[name="signup_package"]').val();
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-signup', signup_fullname: signup_fullname, signup_email_address: signup_email_address, signup_mobile_no: signup_mobile_no, signup_package: signup_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    });
    $('form[name="frmPackageSignup2"]').validate({
        rules: {
            signup_fullname: {required: true, maxlength: 100},
            signup_email_address: {required: true, email: true, maxlength: 100},
            signup_mobile_no: {required: true, number: true, minlength: 10, maxlength: 10}
        },
        messages: {
            signup_fullname: {
                required: "Please enter name"
            },
            signup_mobile_no: {
                required: 'Please enter mobile number',
                minlength: 'Mobile number must be at least 10 characters',
                maxlength: "Please enter no more than 10 characters"
            }
        },
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-signup-error');
            var signup_fullname = form.find('input[name="signup_fullname"]').val();
            var signup_email_address = form.find('input[name="signup_email_address"]').val();
            var signup_mobile_no = form.find('input[name="signup_mobile_no"]').val();
            var signup_package = form.find('input[name="signup_package"]').val();
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-signup', signup_fullname: signup_fullname, signup_email_address: signup_email_address, signup_mobile_no: signup_mobile_no, signup_package: signup_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    });
    $('form[name="frmPackageSignup3"]').validate({
        rules: {
            signup_fullname: {required: true, maxlength: 100},
            signup_email_address: {required: true, email: true, maxlength: 100},
            signup_mobile_no: {required: true, number: true, minlength: 10, maxlength: 10}
        },
        messages: {
            signup_fullname: {
                required: "Please enter name"
            },
            signup_mobile_no: {
                required: 'Please enter mobile number',
                minlength: 'Mobile number must be at least 10 characters',
                maxlength: "Please enter no more than 10 characters"
            }
        },
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-signup-error');
            var signup_fullname = form.find('input[name="signup_fullname"]').val();
            var signup_email_address = form.find('input[name="signup_email_address"]').val();
            var signup_mobile_no = form.find('input[name="signup_mobile_no"]').val();
            var signup_package = form.find('input[name="signup_package"]').val();
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-signup', signup_fullname: signup_fullname, signup_email_address: signup_email_address, signup_mobile_no: signup_mobile_no, signup_package: signup_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    });
    $('form[name="frmPackageSignup4"]').validate({
        rules: {
            signup_fullname: {required: true, maxlength: 100},
            signup_email_address: {required: true, email: true, maxlength: 100},
            signup_mobile_no: {required: true, number: true, minlength: 10, maxlength: 10}
        },
        messages: {
            signup_fullname: {
                required: "Please enter name"
            },
            signup_mobile_no: {
                required: 'Please enter mobile number',
                minlength: 'Mobile number must be at least 10 characters',
                maxlength: "Please enter no more than 10 characters"
            }
        },
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-signup-error');
            var signup_fullname = form.find('input[name="signup_fullname"]').val();
            var signup_email_address = form.find('input[name="signup_email_address"]').val();
            var signup_mobile_no = form.find('input[name="signup_mobile_no"]').val();
            var signup_package = form.find('input[name="signup_package"]').val();
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-signup', signup_fullname: signup_fullname, signup_email_address: signup_email_address, signup_mobile_no: signup_mobile_no, signup_package: signup_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    });
    $('form[name="frmPackageSignup5"]').validate({
        rules: {
            signup_fullname: {required: true, maxlength: 100},
            signup_email_address: {required: true, email: true, maxlength: 100},
            signup_mobile_no: {required: true, number: true, minlength: 10, maxlength: 10}
        },
        messages: {
            signup_fullname: {
                required: "Please enter name"
            },
            signup_mobile_no: {
                required: 'Please enter mobile number',
                minlength: 'Mobile number must be at least 10 characters',
                maxlength: "Please enter no more than 10 characters"
            }
        },
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-signup-error');
            var signup_fullname = form.find('input[name="signup_fullname"]').val();
            var signup_email_address = form.find('input[name="signup_email_address"]').val();
            var signup_mobile_no = form.find('input[name="signup_mobile_no"]').val();
            var signup_package = form.find('input[name="signup_package"]').val();
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-signup', signup_fullname: signup_fullname, signup_email_address: signup_email_address, signup_mobile_no: signup_mobile_no, signup_package: signup_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    }); 
    $('form[name="frmPackageSignup6"]').validate({
        rules: {
            signup_fullname: {required: true, maxlength: 100},
            signup_email_address: {required: true, email: true, maxlength: 100},
            signup_mobile_no: {required: true, number: true, minlength: 10, maxlength: 10}
        },
        messages: {
            signup_fullname: {
                required: "Please enter name"
            },
            signup_mobile_no: {
                required: 'Please enter mobile number',
                minlength: 'Mobile number must be at least 10 characters',
                maxlength: "Please enter no more than 10 characters"
            }
        },
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-signup-error');
            var signup_fullname = form.find('input[name="signup_fullname"]').val();
            var signup_email_address = form.find('input[name="signup_email_address"]').val();
            var signup_mobile_no = form.find('input[name="signup_mobile_no"]').val();
            var signup_package = form.find('input[name="signup_package"]').val();
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-signup', signup_fullname: signup_fullname, signup_email_address: signup_email_address, signup_mobile_no: signup_mobile_no, signup_package: signup_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    });  
    $('form[name="frmPackageSignup7"]').validate({
        rules: {
            signup_fullname: {required: true, maxlength: 100},
            signup_email_address: {required: true, email: true, maxlength: 100},
            signup_mobile_no: {required: true, number: true, minlength: 10, maxlength: 10}
        },
        messages: {
            signup_fullname: {
                required: "Please enter name"
            },
            signup_mobile_no: {
                required: 'Please enter mobile number',
                minlength: 'Mobile number must be at least 10 characters',
                maxlength: "Please enter no more than 10 characters"
            }
        },
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-signup-error');
            var signup_fullname = form.find('input[name="signup_fullname"]').val();
            var signup_email_address = form.find('input[name="signup_email_address"]').val();
            var signup_mobile_no = form.find('input[name="signup_mobile_no"]').val();
            var signup_package = form.find('input[name="signup_package"]').val();
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-signup', signup_fullname: signup_fullname, signup_email_address: signup_email_address, signup_mobile_no: signup_mobile_no, signup_package: signup_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    }); 
    $('form[name="frmPackageSignup8"]').validate({
        rules: {
            signup_fullname: {required: true, maxlength: 100},
            signup_email_address: {required: true, email: true, maxlength: 100},
            signup_mobile_no: {required: true, number: true, minlength: 10, maxlength: 10}
        },
        messages: {
            signup_fullname: {
                required: "Please enter name"
            },
            signup_mobile_no: {
                required: 'Please enter mobile number',
                minlength: 'Mobile number must be at least 10 characters',
                maxlength: "Please enter no more than 10 characters"
            }
        },
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-signup-error');
            var signup_fullname = form.find('input[name="signup_fullname"]').val();
            var signup_email_address = form.find('input[name="signup_email_address"]').val();
            var signup_mobile_no = form.find('input[name="signup_mobile_no"]').val();
            var signup_package = form.find('input[name="signup_package"]').val();
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-signup', signup_fullname: signup_fullname, signup_email_address: signup_email_address, signup_mobile_no: signup_mobile_no, signup_package: signup_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    }); 
    $('form[name="frmPackageSignup9"]').validate({
        rules: {
            signup_fullname: {required: true, maxlength: 100},
            signup_email_address: {required: true, email: true, maxlength: 100},
            signup_mobile_no: {required: true, number: true, minlength: 10, maxlength: 10}
        },
        messages: {
            signup_fullname: {
                required: "Please enter name"
            },
            signup_mobile_no: {
                required: 'Please enter mobile number',
                minlength: 'Mobile number must be at least 10 characters',
                maxlength: "Please enter no more than 10 characters"
            }
        },
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-signup-error');
            var signup_fullname = form.find('input[name="signup_fullname"]').val();
            var signup_email_address = form.find('input[name="signup_email_address"]').val();
            var signup_mobile_no = form.find('input[name="signup_mobile_no"]').val();
            var signup_package = form.find('input[name="signup_package"]').val();
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-signup', signup_fullname: signup_fullname, signup_email_address: signup_email_address, signup_mobile_no: signup_mobile_no, signup_package: signup_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    }); 
    $('form[name="frmPackageSignup10"]').validate({
        rules: {
            signup_fullname: {required: true, maxlength: 100},
            signup_email_address: {required: true, email: true, maxlength: 100},
            signup_mobile_no: {required: true, number: true, minlength: 10, maxlength: 10}
        },
        messages: {
            signup_fullname: {
                required: "Please enter name"
            },
            signup_mobile_no: {
                required: 'Please enter mobile number',
                minlength: 'Mobile number must be at least 10 characters',
                maxlength: "Please enter no more than 10 characters"
            }
        },
        submitHandler: function (form) {
            var form = $(form);
            var package_processing = form.find('.package-processing');
            var login_error = form.find('.package-signup-error');
            var signup_fullname = form.find('input[name="signup_fullname"]').val();
            var signup_email_address = form.find('input[name="signup_email_address"]').val();
            var signup_mobile_no = form.find('input[name="signup_mobile_no"]').val();
            var signup_package = form.find('input[name="signup_package"]').val();
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'package-signup', signup_fullname: signup_fullname, signup_email_address: signup_email_address, signup_mobile_no: signup_mobile_no, signup_package: signup_package}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(package_processing).html("<p style=\"text-align:center;\"><i class=\"fa fa-spinner fa-spin fa-2x fa-fw\" aria-hidden=\"true\"></i></p>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(login_error).html(jsonStr.message);
                        $(package_processing).html("");
                    }
                }});
            return false;
        }
    });    

    $('form[name="frmUpdateProfile"]').validate({
        rules: {comapny_name: {maxlength: 100}, company_phone: {number: true, minlength: 10, maxlength: 10}, company_email: {email: true, maxlength: 100}, user_name: {required: true, maxlength: 50}, user_mobile: {required: true, minlength: 10, maxlength: 10}},
        messages: {company_email: {email: "Please enter a valid email address"}}
    });

    $('form[name="frmHeaderSection"]').validate({
        rules: {
            client_name: {required: true, maxlength: 100}, client_mobile_number: {required: true, number: true, minlength: 10, maxlength: 10}, client_email_address: {required: true, email: true, maxlength: 100}},
        messages: {client_name: {required: "Please enter name"}, client_mobile_number: {required: "Please enter mobile number", number: "Please enter a valid mobile number"}, client_email_address: {required: "Please enter email address", email: "Please enter a valid email address"}},
        submitHandler: function (form) {
            //alert("AAAA");
            //var form = $(form);
            $("#header_contactform").append(" <i class=\"fa fa-spinner fa-spin fa-x fa-fw\" aria-hidden=\"true\"></i>");
            form.submit();
            //return false;
        }        
    });
    
     $('form[name="frmHeaderSection1"]').validate({
        rules: {
            client_name: {required: true, maxlength: 100}, client_mobile_number: {required: true, number: true, minlength: 10, maxlength: 10}, client_email_address: {required: true, email: true, maxlength: 100}},
        messages: {client_name: {required: "Please enter name"}, client_mobile_number: {required: "Please enter mobile number", number: "Please enter a valid mobile number"}, client_email_address: {required: "Please enter email address", email: "Please enter a valid email address"}},
        submitHandler: function (form) {
            //alert("AAAA");
            //var form = $(form);
            $("#header_contactform1").append(" <i class=\"fa fa-spinner fa-spin fa-x fa-fw\" aria-hidden=\"true\"></i>");
            form.submit();
            //return false;
        }        
    });
    
    $('form[name="frmHeaderSection2"]').validate({
        rules: {
            client_name: {required: true, maxlength: 100}, client_mobile_number: {required: true, number: true, minlength: 10, maxlength: 10}, client_email_address: {required: true, email: true, maxlength: 100}},
        messages: {client_name: {required: "Please enter name"}, client_mobile_number: {required: "Please enter mobile number", number: "Please enter a valid mobile number"}, client_email_address: {required: "Please enter email address", email: "Please enter a valid email address"}},
        submitHandler: function (form) {
            //alert("AAAA");
            //var form = $(form);
            $("#header_contactform2").append(" <i class=\"fa fa-spinner fa-spin fa-x fa-fw\" aria-hidden=\"true\"></i>");
            form.submit();
            //return false;
        }        
    });

$('form[name="frmHeaderSection3"]').validate({
        rules: {
            client_name: {required: true, maxlength: 100}, client_mobile_number: {required: true, number: true, minlength: 10, maxlength: 10}, client_email_address: {required: true, email: true, maxlength: 100}},
        messages: {client_name: {required: "Please enter name"}, client_mobile_number: {required: "Please enter mobile number", number: "Please enter a valid mobile number"}, client_email_address: {required: "Please enter email address", email: "Please enter a valid email address"}},
        submitHandler: function (form) {
            //alert("AAAA");
            //var form = $(form);
            $("#header_contactform3").append(" <i class=\"fa fa-spinner fa-spin fa-x fa-fw\" aria-hidden=\"true\"></i>");
            form.submit();
            //return false;
        }        
    });

    $('form[name="frmChangePassword"]').validate({
        rules: {
            current_password: {required: true, minlength: 4, maxlength: 20},
            new_password: {required: true, minlength: 4, maxlength: 20},
            confirm_new_password: {required: true, minlength: 4, maxlength: 20, equalTo: "#update_new_password"}
        },
        messages: {
            current_password: {
                required: "Please enter current password"
            },
            new_password: {
                required: "Please enter password"
            },
            confirm_new_password: {
                required: "Please re-enter your password",
                equalTo: "Please enter the same password as above"
            }
        }
    });


    $('form[name="loginForm"]').validate({
        rules: {login_email_address: {required: true, email: true, maxlength: 100}, login_password: {required: true, minlength: 4, maxlength: 50}, },
        messages: {login_email_address: {required: "Please enter email address", email: "Please enter a valid email address"}, login_password: {required: "Please enter password"}},
        submitHandler: function (form) {
            var form = $(form);
            var login_email_address = form.find('input[name="login_email_address"]').val();
            var login_password = form.find('input[name="login_password"]').val();
            var query_string = form.find('input[name="query_string"]').val();
            if($(".amp-package-login-signup").length)
			{
				var login_package = $(".amp-package-login-signup").attr("data-package");
				var data_set = {data_type: 'package-login', login_email_address: login_email_address, login_password: login_password, login_package: login_package};			    
			}else{
			    var data_set = {data_type: 'user-signin', login_email_address: login_email_address, login_password: login_password, query_string: query_string };
			}
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: data_set, cache: false, dataType: "JSON", beforeSend: function () {
                    $(".user-signin-message").html("<img src=\"" + $("body").attr('data-path') + "theme/default/images/loader.gif\" style=\"margin:auto;\"/>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(".user-signin-message").html(jsonStr.message);
                    }
                }});
            return false;
        }
    });

    $('form[name="frmRegister"]').validate({
        rules: { signup_fullname: {required: true, maxlength: 100}, signup_email_address: {required: true, email: true, maxlength: 100}, signup_mobile_no: {required: true, number: true, minlength: 10, maxlength: 10}, signup_password: {required: true, minlength: 4, maxlength: 20}, signup_confirm_password: {required: true, minlength: 4, maxlength: 20, equalTo: "#signup_password"} },
        messages: { signup_fullname: { required: "Please enter name" }, signup_mobile_no: { required: 'Please enter mobile number' }, signup_email_address: { required: "Please enter email address", email: "Please enter a valid email address" }, signup_password: { required: "Please enter password" }, signup_confirm_password: { required: "Please re-enter your password", equalTo: "Please enter the same password as above" } },
        submitHandler: function (form) {
            var form = $(form);
            var signup_fullname = form.find('input[name="signup_fullname"]').val();
            var signup_email_address = form.find('input[name="signup_email_address"]').val();
            var signup_mobile_no = form.find('input[name="signup_mobile_no"]').val();
            var signup_password = form.find('input[name="signup_password"]').val();
            var signup_confirm_password = form.find('input[name="signup_confirm_password"]').val();
			if ($(".amp-package-login-signup").length)
			{
				var signup_package = $(".amp-package-login-signup").attr("data-package");
				var data_set = {data_type: 'package-signup', signup_fullname: signup_fullname, signup_email_address: signup_email_address, signup_mobile_no: signup_mobile_no, signup_package: signup_package};
			}else{
				var data_set = {data_type: 'user-signup', signup_fullname: signup_fullname, signup_email_address: signup_email_address, signup_mobile_no : signup_mobile_no, signup_password : signup_password, signup_confirm_password : signup_confirm_password};
			}            
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: data_set, cache: false, dataType: "JSON", beforeSend: function () {
                    $(".user-signup-message").html("<img src=\"" + $("body").attr('data-path') + "theme/default/images/loader.gif\" style=\"margin:auto;\"/>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    } else {
                        $(".user-signup-message").html(jsonStr.message);
                    }
                }});
            return false;
        }        
    });
    
/**   
    $('form[name="frmSendTeskMessage"]').validate({
        rules: {user_task_message: {required: true,maxlength: 1000}},
        messages: {user_task_message: {required: "Please enter message"}},
        submitHandler: function (form) {
            var form = $(form);
            var task_message = form.find('textarea[name="user_task_message"]').val();
            var task_details = $("#user_task_message").attr("data-task");
            //alert(task_message);
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'user-task-message', task_message: task_message, task_details : task_details}, cache: false, dataType: "JSON", beforeSend: function () {
                    $(".send-tesk-message").html("<img src=\"" + $("body").attr('data-path') + "theme/default/images/loader.gif\" style=\"margin:auto;\"/>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = jsonStr.message;
                    }
                }});
            return false;
        }
    });  
    **/
   
        $('.upload_task_document').change(function(e){
            var fileName = e.target.files[0].name;
            $("#file_name").html(fileName);
        });
   
    $('form[name="frmSendTeskMessage"]').validate({
        rules: {
            user_task_message: {
                required: {
                depends: function(element) {
                    var task_document = $(".upload_task_document").val();
                    if(task_document == ""){
                        return true;
                    }else{
                       return false; 
                    }
                }
            },
                maxlength: 1000
            }
        },
        messages: {user_task_message: {required: "Please enter message"}},
        submitHandler: function (form) {
            var formData = new FormData(form);
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: formData, async: false, contentType: false, processData: false, cache: false, dataType: "JSON", beforeSend: function () {
                    $(".send-tesk-message").html('<i class="fa fa-spinner fa-spin fa-fw" aria-hidden="true"></i>');
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = location.href;
                    }else{
                        $(".send-tesk-message").html('<i class="fa fa-paper-plane" aria-hidden="true"></i>');
                    }
                }});
            return false;
        }
    });    
    
        $('.upload_task_document1').change(function(e){
            var fileName = e.target.files[0].name;
            $("#file_name1").html(fileName);
        });
        
    $('form[name="frmSendTeskMessage1"]').validate({
        rules: {
            user_task_message: {
                required: {
                depends: function(element) {
                    var task_document = $(".upload_task_document1").val();
                    if(task_document == ""){
                        return true;
                    }else{
                       return false; 
                    }
                }
            },
                maxlength: 1000
            }
        },
        messages: {user_task_message: {required: "Please enter message"}},
        submitHandler: function (form) {
            var formData = new FormData(form);
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: formData, async: false, contentType: false, processData: false, cache: false, beforeSend: function () {
                    $(".send-tesk-message1").html('<i class="fa fa-spinner fa-spin fa-fw" aria-hidden="true"></i>');
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') { 
                        alert(jsonStr);
                        if(jsonStr.message != ""){
                            $('#user_task_message1').val("");
                            $('.upload_task_document1').val("");
                            $("#file_name1").html("");
                            //$("#user_task_message1").attr('data-message', jsonStr.data_message);
                            $("#data_messagetaskdoc").val(jsonStr.data_message);
                            $("#display_message_block").append(jsonStr.message);
                            $(".send-tesk-message1").html("<i class=\"fa fa-paper-plane\" aria-hidden=\"true\"></i>");
                            $("#display_message_block").animate({
                              scrollTop: $('#display_message_block')[0].scrollHeight - $('#display_message_block')[0].clientHeight
                            }, 1000); 
                           
                        }
                    }
                }});
            return false;
        }
    }); 
    
    /**
        $("#user_task_message1").keypress(function( event ){
		var keycode = (event.keyCode ? event.keyCode : event.which);
                if(keycode == '13'){
                    var form = $('form[name="frmSendTeskMessage1"]');
                    form.submit();
                }
	}); 
        
        
    $("#frmSendTeskDocument").validate({
        rules: {
            upload_task_document: {
               required: true
            }
        },
        messages: {
            upload_task_document: {
                required:"Please select profile picture"
            }
        },
        submitHandler: function (form) {
            var formData = new FormData(form);
            
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: formData, async: false, contentType: false, processData: false, cache: false, dataType: "JSON", beforeSend: function () {
                    //$(".CopyrightChecklist").html("<i class=\"fa fa-spinner\" aria-hidden=\"true\"></i>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = location.href;
                    }
                }});
            return false;
        }         

    }); 
    $(document).delegate('.upload_task_document1', 'change', function () {
        var form = $('#frmSendTeskDocument');
        form.submit();
     });        
        
        
    
    
    
    $("#frmSendTeskDocument1").validate({
        rules: {
            upload_task_document: {
               required: true
            }
        },
        messages: {
            upload_task_document: {
                required:"Please select profile picture"
            }
        },
        submitHandler: function (form) {
            var formData = new FormData(form);
            
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: formData, async: false, contentType: false, processData: false, cache: false, dataType: "JSON", beforeSend: function () {
                    //$(".CopyrightChecklist").html("<i class=\"fa fa-spinner\" aria-hidden=\"true\"></i>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        if(jsonStr.message != ""){
                            //form.find('textarea[name="user_task_message"]').val("");
                            $("#user_task_message1").attr('data-message', jsonStr.data_message);
                            $("#data_messagetaskdoc").val(jsonStr.data_message);
                            $("#display_message_block").append(jsonStr.message);
                            //$(".send-tesk-message1").html("<i class=\"fa fa-paper-plane\" aria-hidden=\"true\"></i>");
                            $("#display_message_block").animate({
                              scrollTop: $('#display_message_block')[0].scrollHeight - $('#display_message_block')[0].clientHeight
                            }, 1000);  
                        }
                    }
                }});
            return false;
        }         

    }); 
    $(document).delegate('.upload_task_document', 'change', function () {
        var form = $('#frmSendTeskDocument1');
        form.submit();
     });    
    **/
    
    
    
    
    $("#frmUpdateProfilePic").validate({
        rules: {
            update_profile_picture: {
               required: true
            }
        },
        messages: {
            update_profile_picture: {
                required:"Please select profile picture"
            }
        },
        submitHandler: function (form) {
            //alert("AAAAAAAAAAAAA");
            var formData = new FormData(form);
            
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_forms.php", type: "POST", data: formData, async: false, contentType: false, processData: false, cache: false, dataType: "JSON", beforeSend: function () {
                    //$(".CopyrightChecklist").html("<i class=\"fa fa-spinner\" aria-hidden=\"true\"></i>");
                }, success: function (jsonStr) {
                    //alert(jsonStr)
                    if (jsonStr.message_status == 'success') {
                        location.href = location.href;
                    }
                }});
            return false;
        }         

    }); 
    
    
    $(document).delegate('.update-profile-picture', 'change', function () {
        
        var form = $('#frmUpdateProfilePic');
        //alert("aaaa");
        form.submit();
        
     });
     
     
    $('form[name="frmTaskArrangeCall"]').validate({
        rules: {
            mobile_number: {required: true, number: true, minlength: 10, maxlength: 10}
        },
        messages: {
            mobile_number: {
                required: 'Please enter mobile number',
                minlength: 'Mobile number must be at least 10 characters',
                maxlength: "Please enter no more than 10 characters"
            }
        }
    }); 
    
    $('form[name="frmLeadArrangeCall"]').validate({
        rules: {
            mobile_number: {required: true, number: true, minlength: 10, maxlength: 10}
        },
        messages: {
            mobile_number: {
                required: 'Please enter mobile number',
                minlength: 'Mobile number must be at least 10 characters',
                maxlength: "Please enter no more than 10 characters"
            }
        }
    });  
    
    
    
    
        $(".ad-rating span").mouseover(function (event) {
        var data_rate = $(this).attr('data-rate');
        var index_val = parseInt(data_rate);
        $(".ad-rating span").each(function (i) {
            if (index_val > i)
            {
                $(this).removeClass("fa-star-o");
                $(this).removeClass("no_rated");
                $(this).addClass("fa-star");
                $(this).addClass("ad_rated");
            }
        });

    });

    $(".ad-rating span").mouseout(function (event) {
        var data_rate = $(this).attr('data-rate');
        var rate_value = $("#list_comment_rating").val();
        var index_rate = parseInt(rate_value);

        var index_val = parseInt(data_rate);
        $(".ad-rating span").each(function (i) {
            if (index_val > i)
            {
                if (index_rate > i)
                {
                    //alert(index_rate);
                    $(this).addClass("fa-star");
                    $(this).addClass("ad_rated");
                    //$(this).addClass("fa-star-o");
                    //$(this).addClass("no_rated");
                } else {
                    $(this).removeClass("fa-star");
                    $(this).removeClass("ad_rated");
                    $(this).addClass("fa-star-o");
                    $(this).addClass("no_rated");
                }
            }
        });
    });

    $(".ad-rating span").click(function (event) {

        var data_rate = $(this).attr('data-rate');
        var data_order = $('.list-ad-rating').attr('data-order');
        //alert(data_rate);
        var index_val = parseInt(data_rate);
        $(".ad-rating span").each(function (i) {
            if (index_val > i)
            {
                $(this).removeClass("fa-star-o");
                $(this).removeClass("no_rated");
                $(this).addClass("fa-star");
                $(this).addClass("ad_rated");
            } else {
                $(this).removeClass("fa-star");
                $(this).removeClass("ad_rated");
                $(this).addClass("fa-star-o");
                $(this).addClass("no_rated");
            }
        });
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: {data_type: 'rate-order-details', data_order: data_order, data_rate : data_rate}, cache: false, dataType: "JSON", beforeSend: function () {
                   // $(".send-tesk-message1").html("<img src=\"" + $("body").attr('data-path') + "theme/default/images/loader.gif\" style=\"margin:auto;\"/>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == 'success') {
                        location.href = location.href;
                    }
                }});

    });
    
    
    
    $('form[name="frmFeedbackSuggestion"]').validate({
        rules: {
            fullname: {required: true, maxlength: 100},
            emailid: {required: true, email: true, maxlength: 100},
            mobilenumber: {required: true, number: true, minlength: 10, maxlength: 10},
            subject: {required: true, maxlength: 100},
            message: {required: true, maxlength: 500}
        },
        messages: {
            fullname: {
                required: "Please enter name"
            },
            emailid: {
             required: "Please enter email address",
             email: "Please enter a valid email address"
            },            
            mobilenumber: {
                required: 'Please enter mobile number',
                minlength: 'Mobile number must be at least 10 characters',
                maxlength: "Please enter no more than 10 characters"
            },
            subject: {
                required: 'Please enter subject'
            },
            message: {
                required: 'Please enter message'
            }            
        }
    }); 
    

    
    
    
    if ($(".js-example-basic-multiple").length){
      var service_type = "";
      $('.js-example-basic-multiple').select2({
        placeholder: 'Select',
        ajax: {
          url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php",
          dataType: 'json',
          delay: 250,
            data: function (params) {
                if($('#pvt_company_services').is(':checked')){ service_type = "service"; }else{ service_type = "goods"; } 
                return {
                    q: params.term, // search term
                    page: service_type
                };
            },          
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      }); 
  }
      
      
    if ($(".js-example-basic-multiple1").length){
      var service_type = "";
      $('.js-example-basic-multiple1').select2({
        placeholder: 'Select',
        ajax: {
          url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php",
          dataType: 'json',
          delay: 250,
            data: function (params) {
                if($('#pvt_company_services1').is(':checked')){ service_type = "service"; }else{ service_type = "goods"; } 
                return {
                    q: params.term, // search term
                    page: service_type
                };
            },          
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      }); 
  }
      
    if ($(".js-example-basic-multiple2").length){
      var service_type = "";
      $('.js-example-basic-multiple2').select2({
        placeholder: 'Select',
        ajax: {
          url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php",
          dataType: 'json',
          delay: 250,
            data: function (params) {
                if($('#pvt_company_services2').is(':checked')){ service_type = "service"; }else{ service_type = "goods"; } 
                return {
                    q: params.term, // search term
                    page: service_type
                };
            },          
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      }); 
  }
      
    if ($(".js-example-basic-multiple3").length){
      var service_type = "";
      $('.js-example-basic-multiple3').select2({
        placeholder: 'Select',
        ajax: {
          url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php",
          dataType: 'json',
          delay: 250,
            data: function (params) {
                if($('#pvt_company_services3').is(':checked')){ service_type = "service"; }else{ service_type = "goods"; } 
                return {
                    q: params.term, // search term
                    page: service_type
                };
            },          
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });
  }
      
    if ($(".js-example-basic-multiple4").length){
      var service_type = "";
      $('.js-example-basic-multiple4').select2({
        placeholder: 'Select',
        ajax: {
          url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php",
          dataType: 'json',
          delay: 250,
            data: function (params) {
                if($('#pvt_company_services4').is(':checked')){ service_type = "service"; }else{ service_type = "goods"; } 
                return {
                    q: params.term, // search term
                    page: service_type
                };
            },          
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      }); 
  }
      
    if ($(".js-example-basic-multiple5").length){
      var service_type = "";
      $('.js-example-basic-multiple5').select2({
        placeholder: 'Select',
        ajax: {
          url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php",
          dataType: 'json',
          delay: 250,
            data: function (params) {
                if($('#pvt_company_services5').is(':checked')){ service_type = "service"; }else{ service_type = "goods"; } 
                return {
                    q: params.term, // search term
                    page: service_type
                };
            },          
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      }); 
      
    }
    if ($(".js-example-basic-multiple6").length){
      var service_type = "";
      $('.js-example-basic-multiple6').select2({
        placeholder: 'Select',
        ajax: {
          url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php",
          dataType: 'json',
          delay: 250,
            data: function (params) {
                if($('#pvt_company_services6').is(':checked')){ service_type = "service"; }else{ service_type = "goods"; } 
                return {
                    q: params.term, // search term
                    page: service_type
                };
            },          
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      }); 
  }
      /**
        $(".js-example-basic-multiple").select2({
            placeholder: "Select Services",
            minimumInputLength: 2,
            ajax: {// instead of writing the function to execute the request we use Select2's convenient helper
                url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php",
                dataType: 'json',
                delay: 250,
                data: function (term, page) {
                    return {
                        data_type: "select-search-city",
                        code_data: term, // search term
                    };
                },
                results: function (data, page) { // parse the results into the format expected by Select2.
                    // since we are using custom formatting functions we do not need to alter the remote JSON data
                    //alert(data[0].name);
                    return {results: data};
                },
                cache: true
            }
        });
       
    }
    
     **/
       // if ($(".field_wrapper").length) { $(":file").filestyle(); }
        var maxField = 5; //Input fields increment limitation
        var addButton = $('.add_button'); //Add button selector
        var wrapper = $('.field_wrapper'); //Input field wrapper
        var fieldHTML = '<div class="col-md-12"><div class="col-sm-7 marginT10"><span style="background: #fcc813;display: inline-block;width: auto;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;height: 40px;line-height: 40px;padding: 2px 9px;border-radius: 3px;position: relative;margin:auto;"><input style="position:relative;left:00px;" type="file" name="user_document[]" data-placeholder="" data-input="true" class="" data-icon="false" data-buttonName="btn-css" data-buttonText="Upload" data-badge="false"></span></div><div class="col-sm-5 marginT10"><a href="javascript:void(0);" class="remove_button btn btn-default" title="Remove field"><i class="fa fa-times"></i></a></div></div>'; //New input field html 
       //var fieldHTML = '<div class="label-select"><input type="file" name="user_document[]" id="file-dd1" data-placeholder="" data-input="true" data-icon="false" data-buttonName="btn-css" data-buttonText="Upload" data-badge="false"  class="inputfile inputfile-1" style="display:none;"><label for="file-dd1" class="label-up" style="margin:auto !important"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17"><path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"></path></svg> <span>Choose a fileâ€¦</span></label></div>';
        var x = 1; //Initial field counter is 1
        $(addButton).click(function(){ //Once add button is clicked
       // alert('AAA');
            if(x < maxField){ //Check maximum number of input fields
                x++; //Increment field counter
                $(wrapper).append(fieldHTML); // Add field html
                $(":file").filestyle();
            }
        });
        $(wrapper).on('click', '.remove_button', function(e){ //Once remove button is clicked
            e.preventDefault();
            $(this).parent('div').parent('div').remove(); //Remove field html
            x--; //Decrement field counter
        }); 
        
        
        

    /**
     
     if ($("#user_create_job").length) {
     var data_status = $("#user_create_job").attr("data-status");
     if (data_status == 1) {
     $('#createajob').modal("show");
     }
     }
     if ($(".accordion_example2").length) {
     $(".accordion_example2").smk_Accordion({
     closeAble: true, //boolean
     });
     }
     
     $('.section-hide-block').click(function () {
     if ($(this).is(':checked')) {
     var data_hide = $(this).attr("data-hide");
     $("#" + data_hide).addClass("hide");
     }
     });
     
     $(".live-search-box").on("keyup", function () {
     var searchTerm = $(this).val();
     $(".packages-search-sections").each(function () {
     if ($(this).filter("[data-search *=" + searchTerm + "]").length > 0 || searchTerm.length < 1) {
     $(this).show();
     } else {
     $(this).hide();
     }
     });
     });
     
     
     $('.section-show-block').click(function () {
     if ($(this).is(':checked')) {
     var data_show = $(this).attr("data-show");
     $("#" + data_show).removeClass("hide");
     }
     });
     
     $('.consultantconfirmdisputenotresolved').click(function (event) {
     event.preventDefault();
     $('form[name="frmConsultantConfirmDisputeNotResolved"]').submit()
     });
     $('.consultantconfirmdisputedesolved').click(function (event) {
     event.preventDefault();
     $('form[name="frmConsultantConfirmDisputeResolved"]').submit()
     });
     $('.userconfirmdisputenotresolved').click(function (event) {
     event.preventDefault();
     $('form[name="frmUserConfirmDisputeNotResolved"]').submit()
     });
     $('.userconfirmdisputedesolved').click(function (event) {
     event.preventDefault();
     $('form[name="frmUserConfirmDisputeResolved"]').submit()
     });
     $(document).delegate('#dispute_jobid_listing_search', 'change', function () {
     var data_value = $(this).val();
     if (data_value != "") {
     var path = $("body").attr('data-path') + "dispute-resolution.html?jobid=" + data_value;
     location.href = path;
     }
     });
     
     $('.consultant-reply-review').click(function () {
     var data_review = $(this).attr("data-review");
     $("#consultant_reply_review").val(data_review);
     });
     
     $(document).delegate('.input-select-file', 'change', function () {
     var data_source = $(this).attr("data-source");
     $("#" + data_source).val($(this).val());
     });
     $(document).delegate('.select-state-city', 'change', function () {
     var data_list = $(this);
     var data_state = data_list.val();
     var data_show = data_list.attr("data-show");
     var data_name = data_list.attr("data-name");
     if (data_state != "")
     {
     $.ajax({url: $("body").attr('data-path') + "lib/plugins/listing/view/listing_actions.php", type: "POST", data: {data_type: 'select-state-city', data_state: data_state, data_name: data_name}, cache: false, success: function (jsonStr) {
     if (jsonStr != "") {
     $("#" + data_show).html(jsonStr);
     }
     }});
     }
     });
     
     $("#consultant_reviews").click(function (event) {
     event.preventDefault();
     var hash = this.hash;
     $('html, body').animate({
     scrollTop: $(hash).offset().top - 130
     }, 1000);
     });
     
     
     $("#newslettersb").click(function (event) {
     event.preventDefault();
     var newsletter = $('#newsletterval').val();
     var path = $("body").attr('data-path') + "newsletter.php";
     if (newsletter != "")
     {
     $.ajax({
     url: path,
     type: "POST",
     data: {
     newsletter: newsletter
     },
     cache: false,
     dataType: "JSON",
     success: function (jsonStr) {
     if (jsonStr.action == 'success')
     {
     $('#newslettererr').hide();
     $('#newslettersuc').show();
     $('#newslettersuc').html(jsonStr.message);
     }
     if (jsonStr.action == 'error')
     {
     $('#newslettersuc').hide();
     $('#newslettererr').show();
     $('#newslettererr').html(jsonStr.message);
     }
     }
     });
     }
     });
     
     
     $(document).delegate('#filter_sort_by', 'change', function () {
     var data_list = $(this);
     var data_path = $("body").attr("data-path");
     var filter_practice_as = $("#filter_practice_as").val();
     var filter_professional_experience = $("#filter_professional_experience").val();
     var filter_qualifications = $("#filter_qualifications").val();
     var filter_skill_sets = $("#filter_skill_sets").val();
     var filter_sort_by = data_list.val();
     var search_url = "";
     if (typeof data_path != "undefined")
     {
     if (filter_practice_as != "") {
     search_url += "practice_as=" + filter_practice_as;
     }
     if (filter_professional_experience != "") {
     if (search_url != "")
     search_url += "&experience=" + filter_professional_experience;
     else
     search_url += "?experience=" + filter_professional_experience;
     }
     if (filter_qualifications != "") {
     if (search_url != "")
     search_url += "&qualification=" + filter_qualifications;
     else
     search_url += "?qualification=" + filter_qualifications;
     }
     if (filter_skill_sets != "") {
     if (search_url != "")
     search_url += "&skill_set=" + filter_skill_sets;
     else
     search_url += "?skill_set=" + filter_skill_sets;
     }
     if (filter_sort_by != "") {
     if (search_url != "")
     search_url += "&sort_by=" + filter_sort_by;
     else
     search_url += "?sort_by=" + filter_sort_by;
     }
     
     if (search_url != "") {
     location.href = data_path + "consultant.html" + search_url;
     }
     
     }
     });
     
     $(document).delegate('#filter_consultants', 'click', function (e) {
     e.preventDefault();
     var data_path = $("body").attr("data-path");
     var filter_practice_as = $("#filter_practice_as").val();
     var filter_professional_experience = $("#filter_professional_experience").val();
     var filter_qualifications = $("#filter_qualifications").val();
     var filter_skill_sets = $("#filter_skill_sets").val();
     var filter_sort_by = $("#filter_sort_by").val();
     var search_url = "";
     if (typeof data_path != "undefined")
     {
     if (filter_practice_as != "") {
     search_url += "?practice_as=" + filter_practice_as;
     }
     if (filter_professional_experience != "") {
     if (search_url != "")
     search_url += "&experience=" + filter_professional_experience;
     else
     search_url += "?experience=" + filter_professional_experience;
     }
     if (filter_qualifications != "") {
     if (search_url != "")
     search_url += "&qualification=" + filter_qualifications;
     else
     search_url += "?qualification=" + filter_qualifications;
     }
     if (filter_skill_sets != "") {
     if (search_url != "")
     search_url += "&skill_set=" + filter_skill_sets;
     else
     search_url += "?skill_set=" + filter_skill_sets;
     }
     if (filter_sort_by != "") {
     if (search_url != "")
     search_url += "&sort_by=" + filter_sort_by;
     else
     search_url += "?sort_by=" + filter_sort_by;
     }
     
     if (search_url != "") {
     location.href = data_path + "consultant.html" + search_url;
     }
     
     }
     });
     
     
     
     $(document).delegate('#consultant_search_transaction_details', 'click', function (e) {
     e.preventDefault();
     var data_path = $("body").attr("data-path");
     var search_title = $("#transcation_search_title").val();
     var search_date = $("#transcation_search_date").val();
     var payment_status = $("#transcation_search_payment_status").val();
     var search_url = "";
     if (typeof data_path != "undefined")
     {
     if (search_title != "") {
     search_url += "?title=" + search_title;
     }
     if (search_date != "") {
     if (search_url != "")
     search_url += "&date=" + search_date;
     else
     search_url += "?date=" + search_date;
     }
     if (payment_status != "") {
     if (search_url != "")
     search_url += "&payment_status=" + payment_status;
     else
     search_url += "?payment_status=" + payment_status;
     }
     if (search_url != "") {
     location.href = data_path + "transaction-details.html" + search_url;
     }
     
     }
     });
     $(document).delegate('#user_search_transaction_details', 'click', function (e) {
     e.preventDefault();
     var data_path = $("body").attr("data-path");
     var search_title = $("#transcation_search_title").val();
     var search_date = $("#transcation_search_date").val();
     var project_status = $("#transcation_search_project_status").val();
     var search_url = "";
     if (typeof data_path != "undefined")
     {
     if (search_title != "") {
     search_url += "?title=" + search_title;
     }
     if (search_date != "") {
     if (search_url != "")
     search_url += "&date=" + search_date;
     else
     search_url += "?date=" + search_date;
     }
     if (project_status != "") {
     if (search_url != "")
     search_url += "&project_status=" + project_status;
     else
     search_url += "?project_status=" + project_status;
     }
     if (search_url != "") {
     location.href = data_path + "transaction-details.html" + search_url;
     }
     
     }
     });
     
     
     $('#startjob_payment_user').click(function (e) {
     e.preventDefault();
     var data_action = $(this);
     var jobdetails = data_action.attr("data-jobdetails");
     if (typeof jobdetails != "undefined") {
     var data_set = {data_type: 'proceed-topay-job_funded', jobdetails: jobdetails};
     $.ajax({url: $("body").attr("data-path") + "lib/plugins/listing/view/listing_actions.php", type: "POST", data: data_set, cache: false, dataType: "JSON", beforeSend: function () {
     data_action.html("Please wait.....");
     }, success: function (jsonStr) {
     //alert("AAAAAAAAAAAAA");
     if (jsonStr.message_status == "success")
     {
     //alert("AAAAAAAAAAAAA");
     $(jsonStr.message).insertBefore('#payuform_container');
     //this_action.html('Proceed to pay');
     $('form[name="payuForm"]').submit();
     }
     }});
     
     }
     
     });
     
     
     $(document).delegate('.upload-listing-image', 'change', function (event) {
     var tmppath = URL.createObjectURL(event.target.files[0]);
     var outer = $(this).closest('.upload-image-box');
     outer.css("background-image", "url(" + tmppath + ")");
     $(outer).append("<div class=\"delete-upload-image\"><a class=\"close-upload-image\"><span class=\"fa fa-times\"></span></a></div>");
     });
     $(document).delegate('.delete-upload-image', 'click', function (e) {
     e.preventDefault();
     var outer = $(this).closest('.upload-image-box');
     outer.css("background-image", "");
     $(this).val("");
     $(outer).children(".delete-upload-image").remove();
     });
     $(".ad-rating span").mouseover(function (event) {
     var data_rate = $(this).attr('data-rate');
     var index_val = parseInt(data_rate);
     $(".ad-rating span").each(function (i) {
     if (index_val > i)
     {
     $(this).removeClass("fa-star-o");
     $(this).removeClass("no_rated");
     $(this).addClass("fa-star");
     $(this).addClass("ad_rated");
     }
     });
     
     });
     
     $(".ad-rating span").mouseout(function (event) {
     var data_rate = $(this).attr('data-rate');
     var rate_value = $("#list_comment_rating").val();
     var index_rate = parseInt(rate_value);
     
     var index_val = parseInt(data_rate);
     $(".ad-rating span").each(function (i) {
     if (index_val > i)
     {
     if (index_rate > i)
     {
     //alert(index_rate);
     $(this).addClass("fa-star");
     $(this).addClass("ad_rated");
     //$(this).addClass("fa-star-o");
     //$(this).addClass("no_rated");
     } else {
     $(this).removeClass("fa-star");
     $(this).removeClass("ad_rated");
     $(this).addClass("fa-star-o");
     $(this).addClass("no_rated");
     }
     }
     });
     });
     
     
     $(".ad-rating span").click(function (event) {
     
     var data_rate = $(this).attr('data-rate');
     //alert(data_rate);
     var index_val = parseInt(data_rate);
     $(".ad-rating span").each(function (i) {
     if (index_val > i)
     {
     $(this).removeClass("fa-star-o");
     $(this).removeClass("no_rated");
     $(this).addClass("fa-star");
     $(this).addClass("ad_rated");
     } else {
     $(this).removeClass("fa-star");
     $(this).removeClass("ad_rated");
     $(this).addClass("fa-star-o");
     $(this).addClass("no_rated");
     }
     });
     $("#list_comment_rating").val(index_val);
     
     });
     
     if ($('#consultant_qualification').length) {
     $("#consultant_qualification").select2({placeholder: "Select Qualification"});
     }
     if ($('#consultant_skill_set').length) {
     $("#consultant_skill_set").select2({placeholder: "Select Skill Set", maximumSelectionLength: 2});
     }
     if ($('#job_skill_sets').length) {
     $("#job_skill_sets").select2({placeholder: "Choose Services", maximumSelectionLength: 2});
     }
     
     if ($('#city_search_box').length) {
     $("#city_search_box").select2({
     placeholder: "Select City",
     minimumInputLength: 2,
     ajax: {// instead of writing the function to execute the request we use Select2's convenient helper
     url: "lib/plugins/listing/view/listing_actions.php",
     dataType: 'json',
     quietMillis: 250,
     data: function (term, page) {
     return {
     data_type: "select-search-city",
     city_data: term, // search term
     };
     },
     results: function (data, page) { // parse the results into the format expected by Select2.
     // since we are using custom formatting functions we do not need to alter the remote JSON data
     //alert(data[0].name);
     return {results: data};
     },
     cache: true
     }
     });
     
     //$("#city_search_box").select2({placeholder: "Select State / City"});  
     }
     
     
     if ($('#filter_city').length) {
     $("#filter_city").select2({
     placeholder: "Select City",
     minimumInputLength: 2,
     ajax: {// instead of writing the function to execute the request we use Select2's convenient helper
     url: $("body").attr("data-path") + "lib/plugins/listing/view/listing_actions.php",
     dataType: 'json',
     quietMillis: 250,
     data: function (term, page) {
     return {
     data_type: "select-search-city",
     city_data: term, // search term
     };
     },
     results: function (data, page) { // parse the results into the format expected by Select2.
     // since we are using custom formatting functions we do not need to alter the remote JSON data
     //alert(data[0].name);
     return {results: data};
     },
     cache: true
     }
     });
     
     //$("#city_search_box").select2({placeholder: "Select State / City"});  
     }
     
     jQuery.validator.addMethod(
     "validDate",
     function (value, element) {
     return value.match(/^(0[1-9]|1[012])[\/|-](0[1-9]|[12][0-9]|3[01])[\/|-](19\d\d|2\d\d\d)$/);
     },
     "Please enter a date in the format mm/dd/yyyy"
     );
     $('form[name="service_filter_form"]').validate({
     rules: {
     filter_city: {required: true}
     },
     messages: {
     filter_city: {
     required: 'Please select city'
     }
     },
     submitHandler: function (form) {
     
     var dataString = "";
     var filter_city = $('input#filter_city').val();
     dataString += "city=" + filter_city;
     var data_page = $("#filter_heading_name").attr("data-page");
     var search_url = $("body").attr('data-path') + data_page + ".html?" + dataString;
     location.href = search_url;
     return false;
     },
     });
     $('form[name="frmForgotPassword"]').validate({
     rules: {
     forgot_email_address: {required: true, email: true, maxlength: 100}
     },
     messages: {
     forgot_email_address: {
     required: "Please enter email address",
     email: "Please enter a valid email address"
     }
     }
     });
     $('form[name="write_product_review"]').validate({
     rules: {
     product_review: {required: true, minlength: 50, maxlength: 1000}
     },
     messages: {
     product_review: {
     required: 'Enter your review'
     }
     },
     submitHandler: function (form) {
     var product_rating = $('input#list_comment_rating').val();
     if (product_rating == "") {
     if ($("#list1_ad_rating").children("label.error").length) {
     $("#list1_ad_rating").children("label.error").remove();
     }
     $("#list1_ad_rating").append("<label  class=\"error\">Please rate this product</label>");
     } else {
     if ($("#list1_ad_rating").children("label.error").length) {
     $("#list1_ad_rating").children("label.error").remove();
     }
     form.submit();
     }
     return false;
     }
     });
     $('form[name="write_consultant_review"]').validate({
     rules: {
     consultant_review: {required: true, minlength: 50, maxlength: 1000}
     },
     messages: {
     consultant_review: {
     required: 'Enter your review'
     }
     },
     submitHandler: function (form) {
     var product_rating = $('input#list_comment_rating').val();
     if (product_rating == "") {
     if ($("#list1_ad_rating").children("label.error").length) {
     $("#list1_ad_rating").children("label.error").remove();
     }
     $("#list1_ad_rating").append("<label  class=\"error\">Please rate this consultant</label>");
     } else {
     if ($("#list1_ad_rating").children("label.error").length) {
     $("#list1_ad_rating").children("label.error").remove();
     }
     form.submit();
     }
     return false;
     }
     });
     $('form[name="contactSellerFrm"]').validate({
     rules: {
     contact_message: {required: true, maxlength: 1000}
     },
     messages: {
     contact_message: {
     required: "Please enter your message"
     }
     }
     });
     $('form[name="loginForm"]').validate({
     rules: {
     login_email_address: {required: true, email: true, maxlength: 100},
     login_password: {required: true, maxlength: 50},
     },
     messages: {
     login_email_address: {
     required: "Please enter email address",
     email: "Please enter a valid email address"
     },
     login_password: {
     required: "Please enter password"
     }
     }
     });
     $('form[name="frmRegister"]').validate({
     rules: {
     signup_firstname: {required: true, maxlength: 50},
     signup_lastname: {maxlength: 50},
     signup_email_address: {required: true, email: true, maxlength: 100},
     signup_mobile_no: {required: true, number: true, minlength: 10, maxlength: 10},
     signup_state: {required: true},
     signup_city: {required: true},
     signup_password: {required: true, minlength: 4, maxlength: 20},
     signup_confirm_password: {required: true, minlength: 4, maxlength: 20, equalTo: "#signup_password"},
     signup_security_code: {required: true, number: true, minlength: 4, maxlength: 4},
     signup_terms_condition: {required: true}
     },
     messages: {
     signup_firstname: {
     required: "Please enter first name"
     },
     signup_lastname: {
     maxlength: "Please enter no more than 50 characters"
     },
     signup_mobile_no: {
     required: 'Please enter mobile number',
     minlength: 'Mobile number must be at least 10 characters',
     maxlength: "Please enter no more than 10 characters"
     },
     signup_email_address: {
     required: "Please enter email address",
     email: "Please enter a valid email address"
     },
     signup_state: {
     required: "Please select state"
     },
     signup_city: {
     required: "Please select city"
     },
     signup_password: {
     required: "Please enter password"
     },
     signup_confirm_password: {
     required: "Please re-enter your password",
     equalTo: "Please enter the same password as above"
     },
     signup_security_code: {
     required: 'Please enter security code',
     minlength: 'Mobile number must be at least 4 characters',
     maxlength: "Please enter no more than 4 characters"
     },
     signup_terms_condition: {
     required: 'Please accept terms condition'
     }
     },
     errorPlacement: function (error, element) {
     if (element.is(":checkbox")) {
     element.closest('.checkbox').after(error);
     } else {
     error.insertAfter(element);
     }
     }
     });
     $('form[name="frmRegisterConsultant"]').validate({
     rules: {
     signup_firstname: {required: true, maxlength: 50},
     signup_lastname: {maxlength: 50},
     signup_email_address: {required: true, email: true, maxlength: 100},
     signup_mobile_no: {required: true, number: true, minlength: 10, maxlength: 10},
     signup_company_name: {maxlength: 100},
     signup_dob: {required: true, date: true, validDate: true},
     signup_state: {required: true},
     signup_city: {required: true},
     signup_password: {required: true, minlength: 4, maxlength: 20},
     signup_confirm_password: {required: true, minlength: 4, maxlength: 20, equalTo: "#signup_password1"},
     signup_security_code: {required: true, number: true, minlength: 4, maxlength: 4},
     signup_terms_condition: {required: true}
     },
     messages: {
     signup_firstname: {
     required: "Please enter first name"
     },
     signup_lastname: {
     maxlength: "Please enter no more than 50 characters"
     },
     signup_mobile_no: {
     required: 'Please enter mobile number',
     minlength: 'Mobile number must be at least 10 characters',
     maxlength: "Please enter no more than 10 characters"
     },
     signup_email_address: {
     required: "Please enter email address",
     email: "Please enter a valid email address"
     },
     signup_dob: {
     required: "Please enter date of birth",
     date: "Please enter a date in the format mm/dd/yyyy",
     validDate: "Please enter a date in the format mm/dd/yyyy"
     },
     signup_state: {
     required: "Please select state"
     },
     signup_city: {
     required: "Please select city"
     },
     signup_password: {
     required: "Please enter password"
     },
     signup_confirm_password: {
     required: "Please re-enter your password",
     equalTo: "Please enter the same password as above"
     },
     signup_security_code: {
     required: 'Please enter security code',
     minlength: 'Mobile number must be at least 4 characters',
     maxlength: "Please enter no more than 4 characters"
     },
     signup_terms_condition: {
     required: 'Please accept terms condition'
     }
     },
     errorPlacement: function (error, element) {
     if (element.is(":checkbox")) {
     element.closest('.checkbox').after(error);
     } else {
     error.insertAfter(element);
     }
     }
     });
     $('form[name="uploadProfilePicture"]').validate({
     rules: {
     profile_picture: {required: true}
     },
     messages: {
     profile_picture: {
     required: "Please select your picture."
     }
     },
     errorPlacement: function (error, element) {
     element.closest('.col-md-2').after(error);
     }
     });
     $('form[name="updateProfileInfo"]').validate({
     rules: {
     profile_first_name: {required: true, maxlength: 50},
     profile_last_name: {maxlength: 50},
     profile_dob: {required: true, date: true, validDate: true},
     profile_state: {required: true},
     profile_city: {required: true},
     },
     messages: {
     profile_first_name: {required: "Please enter first name"},
     profile_last_name: {maxlength: "Please enter no more than 40 characters"},
     profile_dob: {
     required: "Please enter date of birth",
     date: "Please enter a date in the format mm/dd/yyyy",
     validDate: "Please enter a date in the format mm/dd/yyyy"
     },
     profile_state: {required: "Please select state"},
     profile_city: {required: "Please select city"}
     }
     });
     $('form[name="updateUserPassword"]').validate({
     rules: {
     update_current_password: {required: true, minlength: 4, maxlength: 20},
     update_new_password: {required: true, minlength: 4, maxlength: 20},
     update_confirmnew_password: {required: true, minlength: 4, maxlength: 20, equalTo: "#update_new_password"}
     },
     messages: {
     update_current_password: {
     required: "Please enter current password"
     },
     update_new_password: {
     required: "Please enter password"
     },
     update_confirmnew_password: {
     required: "Please re-enter your password",
     equalTo: "Please enter the same password as above"
     }
     }
     });
     $('form[name="updateEmailAddressFrm"]').validate({
     rules: {
     uodate_email_password: {required: true, minlength: 4, maxlength: 20},
     uodate_old_email: {required: true, email: true, maxlength: 100},
     uodate_new_email: {required: true, email: true, maxlength: 100}
     },
     messages: {
     uodate_email_password: {
     required: "Please enter current password"
     },
     uodate_old_email: {
     required: "Please enter old email address",
     email: "Please enter a valid email address"
     },
     uodate_new_email: {
     required: "Please new email address",
     email: "Please enter a valid email address"
     }
     }
     });
     $('form[name="updateMobileNoFrm"]').validate({
     rules: {
     update_mobile_password: {required: true, minlength: 4, maxlength: 20},
     update_new_mobile: {required: true, number: true, minlength: 10, maxlength: 10}
     },
     messages: {
     update_mobile_password: {
     required: "Please enter current password"
     },
     update_new_mobile: {
     required: 'Please enter mobile number',
     minlength: 'Mobile number must be at least 10 characters',
     maxlength: "Please enter no more than 10 characters"
     }
     }
     });
     $('form[name="frmConsultantSetting"]').validate({
     rules: {
     consultant_kyc_document: {required: true},
     consultant_firm_name: {required: true, maxlength: 100},
     consultant_website: {url: true, maxlength: 1000},
     consultant_email: {required: true, email: true, maxlength: 100},
     consultant_contact: {required: true, number: true, minlength: 10, maxlength: 10},
     "consultant_skill_set[]": {required: true},
     "consultant_qualification[]": {required: true},
     consultant_practiceas: {required: true},
     consultant_experience: {required: true},
     consultant_ca_number: {required: true, maxlength: 100},
     consultant_cs_number: {required: true, maxlength: 100},
     consultant_lawyer_number: {required: true, maxlength: 100},
     consultant_accountant_number: {required: true, maxlength: 100},
     consultant_description: {required: true, minlength: 20, maxlength: 5000}
     },
     messages: {
     seller_kyc_document: {
     required: "Please select kyc document"
     },
     consultant_firm_name: {
     required: "Please enter firm name"
     },
     consultant_email: {
     required: "Please enter email address",
     email: "Please enter a valid email address"
     },
     consultant_contact: {
     required: 'Please enter mobile number',
     minlength: 'Mobile number must be at least 10 characters',
     maxlength: "Please enter no more than 10 characters"
     },
     "consultant_skill_set[]": {
     required: "Please select skill set"
     },
     "consultant_qualification[]": {
     required: "Please select qualification"
     },
     consultant_practiceas: {
     required: "Please select practice as"
     },
     consultant_experience: {
     required: "Please select experience"
     },
     consultant_ca_number: {
     required: "Please enter membership number"
     },
     consultant_cs_number: {
     required: "Please enter membership number"
     },
     consultant_lawyer_number: {
     required: "Please enter membership number"
     },
     consultant_accountant_number: {
     required: "Please enter membership number"
     },
     consultant_description: {
     required: "Please enter profile description"
     }
     },
     errorPlacement: function (error, element) {
     if (element.is(":file")) {
     element.closest('.col-md-2').after(error);
     } else {
     error.insertAfter(element);
     }
     }
     });
     $('form[name="frmBankSettings"]').validate({
     rules: {
     consultant_bank_document: {required: true},
     consultant_bank_name: {required: true, maxlength: 100},
     consultant_account_type: {required: true},
     consultant_account_holder_name: {required: true, maxlength: 100},
     consultant_ifsc_code: {required: true, maxlength: 100},
     consultant_micr_code: {required: true, maxlength: 100}
     },
     messages: {
     consultant_bank_document: {
     required: "Please select document"
     },
     consultant_bank_name: {
     required: "Please enter bank name"
     },
     consultant_account_type: {
     required: "Please select account type"
     },
     consultant_account_holder_name: {
     required: "Please enter membership number"
     },
     consultant_ifsc_code: {
     required: "Please enter ifsc code"
     },
     consultant_micr_code: {
     required: "Please enter micr code"
     }
     },
     errorPlacement: function (error, element) {
     if (element.is(":file")) {
     element.closest('.col-md-2').after(error);
     } else {
     error.insertAfter(element);
     }
     }
     });
     $('form[name="frmAddACompany"]').validate({
     rules: {
     company_name: {required: true, maxlength: 100},
     company_address: {required: true, maxlength: 200},
     company_website: {url: true, maxlength: 1000},
     company_state: {required: true},
     company_city: {required: true},
     seller_email: {required: true, email: true, maxlength: 100},
     company_contact: {required: true, number: true, minlength: 10, maxlength: 10},
     company_type: {required: true},
     company_line_of_business: {required: true, maxlength: 200},
     company_neature_of_business: {required: true, maxlength: 200},
     company_description: {required: true, maxlength: 1000},
     company_pan_number: {required: function () {
     return $('#pan_number_checked').is(':checked');
     }, maxlength: 25},
     company_gst_number: {required: function () {
     return $('#gst_number_checked').is(':checked');
     }, maxlength: 25},
     company_tds_number: {required: function () {
     return $('#tds_number_checked').is(':checked');
     }, maxlength: 25},
     company_vat_number: {required: function () {
     return $('#vat_number_checked').is(':checked');
     }, maxlength: 25},
     company_tax_number: {required: function () {
     return $('#pan_number_checked').is(':checked');
     }, maxlength: 25}
     },
     messages: {
     seller_compant_name: {
     required: "Please enter company name"
     },
     seller_city: {
     required: "Please select state"
     },
     seller_city: {
     required: "Please select city"
     },
     seller_email: {
     required: "Please enter email address",
     email: "Please enter a valid email address"
     },
     seller_mobile_no: {
     required: 'Please enter mobile number',
     minlength: 'Mobile number must be at least 10 characters',
     maxlength: "Please enter no more than 10 characters"
     },
     seller_note: {
     required: "Please enter note"
     }
     }
     });
     $('form[name="frmCreateBlogUser"]').validate({
     ignore: [],
     debug: false,
     rules: {
     blog_category: {required: true},
     blog_title: {required: true, maxlength: 200},
     blog_metakeyword: {maxlength: 200},
     blog_metadescription: {maxlength: 200},
     blog_tags: {maxlength: 1000},
     blog_description: {required: function () {
     CKEDITOR.instances.editor.updateElement();
     }, minlength: 100, maxlength: 5000}
     },
     messages: {
     blog_category: {
     required: "Please select category."
     },
     blog_title: {
     required: "Please enter title."
     },
     blog_description: {
     required: "Please enter blog description."
     }
     },
     errorPlacement: function (error, element) {
     if (element.attr("name") == "blog_description") {
     element.closest('.form-group').after(error);
     } else {
     error.insertAfter(element);
     }
     }
     });
     $('form[name="frmConsultantReply"]').validate({
     ignore: [],
     debug: false,
     rules: {
     consultant_reply: {required: true, maxlength: 1000}
     },
     messages: {
     consultant_reply: {
     required: "Please enter message."
     }
     },
     errorPlacement: function (error, element) {
     if (element.attr("name") == "blog_description") {
     element.closest('.form-group').after(error);
     } else {
     error.insertAfter(element);
     }
     }
     });
     $('form[name="frmCreataAJob"]').validate({
     rules: {
     "job_services[]": {required: true},
     job_price: {required: true, number: true, maxlength: 100},
     job_title: {required: true, maxlength: 500},
     job_description: {required: true, maxlength: 5000}
     },
     messages: {
     "job_services[]": {
     required: "Please select services"
     },
     job_price: {
     required: 'Please enter price'
     },
     job_title: {
     required: "Please enter job title"
     },
     job_description: {
     required: "Please enter job description"
     }
     },
     errorPlacement: function (error, element) {
     if (element.is(":file")) {
     element.closest('.col-md-2').after(error);
     } else {
     error.insertAfter(element);
     }
     }
     });
     $('form[name="frmAcceptJob"]').validate({
     rules: {
     accept_responsibilities: {required: true, maxlength: 5000},
     accept_terms_conditions: {required: true, maxlength: 1000},
     accept_number_ofdays: {required: true},
     accept_jobterms_conditions: {required: true}
     },
     messages: {
     accept_responsibilities: {
     required: "Please enter job responsibilities."
     },
     accept_terms_conditions: {
     required: "Please enter terms & conditions."
     },
     accept_number_ofdays: {
     required: 'Please select expected number of days.'
     },
     accept_jobterms_conditions: {
     required: 'Please accept terms condition.'
     }
     },
     errorPlacement: function (error, element) {
     if (element.is(":checkbox")) {
     element.closest('.checkbox').after(error);
     } else {
     error.insertAfter(element);
     }
     }
     });
     $('form[name="frmRejectJob"]').validate({
     rules: {
     reject_reason: {required: true, maxlength: 1000}
     },
     messages: {
     reject_reason: {
     required: "Please enter reject reason."
     }
     }
     });
     $('form[name="frmChangeJobStatusComplate"]').validate({
     rules: {
     jobstatus_complate: {required: true}
     },
     messages: {
     jobstatus_complate: {
     required: "Please select yes or no."
     }
     },
     errorPlacement: function (error, element) {
     if (element.is(":radio")) {
     element.closest('.row').after(error);
     } else {
     error.insertAfter(element);
     }
     },
     submitHandler: function (form) {
     var job_status = $('input[type=radio][name=jobstatus_complate]').filter(':checked');
     var job_value = job_status.val();
     
     if (job_value == 1) {
     form.submit()
     } else {
     $('#changestatus').modal("hide");
     }
     return false;
     }
     });
     $('form[name="frmConfirmCompleteJob"]').validate({
     rules: {
     complete_job_review: {required: true, minlength: 50, maxlength: 1000}
     },
     messages: {
     complete_job_review: {
     required: 'Enter your review'
     }
     },
     submitHandler: function (form) {
     var product_rating = $('input#list_comment_rating').val();
     if (product_rating == "") {
     if ($("#list1_ad_rating").children("label.error").length) {
     $("#list1_ad_rating").children("label.error").remove();
     }
     $("#list1_ad_rating").append("<label  class=\"error\">Please rate this consultant</label>");
     } else {
     if ($("#list1_ad_rating").children("label.error").length) {
     $("#list1_ad_rating").children("label.error").remove();
     }
     form.submit();
     }
     return false;
     }
     });
     $('form[name="frmConsultantNegotiatePrice"]').validate({
     rules: {
     negotiate_price: {required: true, number: true, maxlength: 8},
     negotiate_description: {required: true, maxlength: 500}
     },
     messages: {
     negotiate_price: {
     required: 'Please enter price.'
     },
     negotiate_description: {
     required: "Please enter note."
     }
     }
     });
     $('form[name="frmUserUpdateJobPrice"]').validate({
     rules: {
     jobprice_new: {required: true, number: true, maxlength: 8},
     jobprice_note: {required: true, maxlength: 500}
     },
     messages: {
     jobprice_new: {
     required: 'Please enter price.'
     },
     jobprice_note: {
     required: "Please enter note."
     }
     }
     });
     $('form[name="frmUserReopenJob"]').validate({
     rules: {
     reopen_description: {required: true, maxlength: 1000}
     },
     messages: {
     reopen_description: {
     required: "Please enter details."
     }
     }
     });
     $('form[name="frmUserConsultantJobSearch"]').validate({
     rules: {
     user_search_jobid: {number: true, maxlength: 8},
     },
     submitHandler: function (form) {
     var job_id = $("#user_search_jobid").val();
     var job_status = $("#user_search_jobstatus").val();
     var data_page = $('#user_search_statustitle').attr("data-path");
     var dataString = "";
     if (job_id != "" && job_status == "")
     {
     dataString = "?jobid=" + job_id;
     }
     if (job_id == "" && job_status != "")
     {
     dataString = "?jobstatus=" + job_status;
     }
     if (job_id != "" && job_status != "")
     {
     dataString = "?jobid=" + job_id + "&jobstatus=" + job_status;
     }
     if (dataString != "") {
     var search_url = data_page + dataString;
     location.href = search_url;
     }
     //form.submit();
     return false;
     }
     });
     $('form[name="frmCreateADispute"]').validate({
     rules: {
     dispute_jobid: {required: true},
     dispute_reason: {required: true, maxlength: 1000}
     },
     messages: {
     dispute_jobid: {
     required: "Please select job id."
     },
     dispute_reason: {
     required: "Please enter dispute reason."
     }
     }
     });
     $('form[name="frmDisputeMessageReply"]').validate({
     rules: {dispute_message_reply: {required: true, maxlength: 1000}},
     messages: {dispute_message_reply: {required: "Please enter message."}}
     });
     $('form[name="frmResolvedDispute"]').validate({
     rules: {
     resolved_description: {required: true, maxlength: 5000},
     resolved_terms_condition: {required: true}
     },
     messages: {
     resolved_description: {
     required: "Please enter note"
     },
     resolved_terms_condition: {
     required: 'Please accept terms & conditions'
     }
     },
     errorPlacement: function (error, element) {
     if (element.is(":checkbox")) {
     element.closest('.checkbox').after(error);
     } else {
     error.insertAfter(element);
     }
     }
     });
     $('form[name="frmConsultantRequestWithdrow"]').validate({
     rules: {
     request_withdraw_amount: {required: true, number: true, maxlength: 25},
     request_withdraw_note: {required: true, maxlength: 500}
     },
     messages: {
     request_withdraw_note: {
     required: 'Please enter note.'
     }
     }
     });
     
     if ($('.datepicker').length) {
     $(".datepicker").datepicker({
     dateFormat: 'dd-mm-yy',
     showOtherMonths: true,
     //minDate: jsonStr.date_start,
     maxDate: new Date()
     });
     }
     
     
     
     
     if ($('#startup_city_search').length) {
     $("#startup_city_search").select2({
     placeholder: "Select City",
     minimumInputLength: 2,
     ajax: {// instead of writing the function to execute the request we use Select2's convenient helper
     url: "lib/plugins/listing/view/location_access.php",
     dataType: 'json',
     quietMillis: 250,
     data: function (term, page) {
     var data_country = $("#startup_country_search").val();
     if (data_country == "")
     {
     alert("Please Select Country");
     return false;
     } else {
     return {
     country: data_country,
     q: term, // search term
     };
     }
     },
     results: function (data, page) { // parse the results into the format expected by Select2.
     // since we are using custom formatting functions we do not need to alter the remote JSON data
     //alert(data[0].name);
     return {results: data};
     },
     cache: true
     }
     });
     // $("#startup_city_search").select2({placeholder: "Select State / City"});  
     }
     
     
     
     if ($(".accordion_user_company").length) {
     $(".accordion_user_company").smk_Accordion({
     closeAble: true, //boolean
     });
     }
     z
     if ($(".scrollbars").length) {
     $('.scrollbars').ClassyScroll();
     }
     if ($(".scrollbars2").length) {
     $('.scrollbars2').ClassyScroll();
     }
     **/
});


(function () {
	if($(".amp-package-order-now").length)
	{
        var order_package = $(".amp-package-order-now").attr("data-package");
        if (order_package != "") {
            var data_set = {data_type: 'package-order-now', order_package: order_package};
            $.ajax({url: $("body").attr('data-path') + "lib/plugins/package/view/package_actions.php", type: "POST", data: data_set, cache: false, dataType: "JSON", beforeSend: function () {
                    $(".amp-package-order-now").html("<i class=\"fa fa-spinner fa-spin fa-fw fa-3x\" aria-hidden=\"true\"></i>");
                }, success: function (jsonStr) {
                    if (jsonStr.message_status == "success")
                    {
                        location.href = jsonStr.message;
                    } else {
                        $(".amp-package-order-now").html(jsonStr.message);
                    }
                }});
        }
	}
})()